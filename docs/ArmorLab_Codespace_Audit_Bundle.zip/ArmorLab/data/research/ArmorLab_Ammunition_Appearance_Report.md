# ArmorLab Ammunition Appearance Atlas

**Purpose:** a visual identification and asset-reference guide for every ammunition entry in the earlier ArmorLab catalogue. This report describes how the ammunition is commonly presented in exterior photographs and cutaways, provides links to source pages and exact-designation image searches, and explains how to avoid inventing visual features in the simulator.

**Coverage:** 35 broad mechanism/family entries plus 109 named/designation entries (144 rows total). A named entry can refer to a variant family rather than one unique physical specimen.

**Important scope note:** This is a visual-reference atlas, not a complete ordnance identification manual, a materials datasheet, or evidence that a round's visual shape determines its function. Military ammunition appearance varies by mark, calibre, nation, manufacturing batch, training/inert status, and whether a photograph shows the full cartridge, projectile alone, a missile, a launch tube, or a cutaway. Some prototype programmes do not have reliable public canonical imagery. Such records are marked as uncertain.

## How to use the entries

- **Exterior appearance** describes typical visible silhouette only. It does not establish exact construction, composition, markings, or performance.
- **Cutaway description** explains broad features a labelled museum/manufacturer cutaway may reveal; it is not a construction drawing.
- **Visual cues** are clues rather than positive identification rules. Shape, paint, or tip colour alone is not enough to identify a live item.
- **ArmorLab asset guidance** is for neutral visual modelling and metadata; simulated physics should be driven by validated parameters, not the image description.
- **Image search links** are search aids, not authoritative sources. Verify the result caption, object number, designation and licence.

## High-value visual reference sources

- **S01 — [U.S. Army / JPEO Armaments & Ammunition — 2025 portfolio book (large-calibre ammunition)](https://jpeoaa.army.mil/Portals/94/Documents/JPEOAAPortfolioBook_2025.pdf)**: Government programme reference; includes official descriptions and product imagery for some modern 120 mm cartridges.
- **S02 — [U.S. Army — Weapon Systems Handbook 2020–2021](https://www.army.mil/e2/downloads/rv7/2020-2021_Weapon_Systems_Handbook.pdf)**: Government reference covering M829A4, XM1147 AMP, M1028 canister, M865 training and related ammunition families.
- **S03 — [U.S. Army acquisition — Weapon Systems Handbook 1997, Tank Main Gun Ammunition](https://asc.army.mil/docs/wsh2/1997-wsh.pdf)**: Historical programme description of M829-series APFSDS-T, M830 HEAT-T, M830A1 MPAT, and exploratory programmes STAFF/TERM-KE.
- **S04 — [Rheinmetall — 120 mm System House brochure](https://www.rheinmetall.com/Rheinmetall%20Group/brochure-download/Weapon-Ammmunition/B195e0423-Rheinmetall-120mm-system-house.pdf)**: Manufacturer brochure with a row of 120 mm rounds including DM73, DM63A1, DM88 practice, DM11 programmable HE-FRAG, Rh31 and DM98 practice.
- **S05 — [KNDS — 120 mm ammunition](https://knds.com/en/products/ammunition/120-mm)**: Manufacturer reference for modern 120 mm ammunition families; use exact product datasheets where available.
- **S06 — [National Army Museum — “Attack of the tanks”](https://www.nam.ac.uk/explore/attack-tanks)**: Museum overview of tank/anti-tank history and some historical anti-tank weapon imagery.
- **S07 — [Australian War Memorial — PIAT Mark 1 Projector](https://www.awm.gov.au/collection/C222205)**: Museum catalogue describing the PIAT and its HEAT, practice and drill ammunition colour conventions for the documented example.
- **S08 — [Smithsonian National Air and Space Museum — ENTAC anti-tank missile cutaway](https://airandspace.si.edu/collection-objects/missile-anti-tank-entac-cutaway/nasm_A19800253000)**: Museum object and cutaway description: airframe, nose/warhead region, motor section, wire guidance and fins.
- **S09 — [Lockheed Martin — Javelin Weapon System](https://hellfire.us/en-us/products/javelin.html)**: Manufacturer public product page with Javelin photographs and general system description.
- **S10 — [MBDA — Akeron MP](https://www.mbda-systems.com/products/battlefield/akeron-family/akeron-mp)**: Manufacturer page with images and published external size/platform context for the missile-in-canister system.
- **S11 — [Wikimedia Commons — Category: Anti-tank ammunition](https://commons.wikimedia.org/wiki/Category:Anti-tank_ammunition)**: Image index including tank ammunition, historical anti-tank ammunition and some projectile photographs. Check each image’s licence and caption.
- **S12 — [Wikimedia Commons — Category: Cutaways of ammunition](https://commons.wikimedia.org/wiki/Category:Cutaways_of_ammunition)**: Image index useful for comparing external silhouette with sectioned/cutaway views.
- **S13 — [Wikimedia Commons — Category: HEAT munitions](https://commons.wikimedia.org/wiki/Category:HEAT_munition)**: Illustrated HEAT-family references; images may depict different calibres, eras and non-identical designs.
- **S14 — [Wikimedia Commons — Leopard 1 APDS / HEAT / HESH ammunition display](https://commons.wikimedia.org/wiki/File:Tank_ammunition_APDS_-_HEAT_-_HESH_for_Leopard_1_-_Panzermuseum_Munster_2010.jpg)**: A museum display photograph useful as a side-by-side silhouette comparison of several ammunition families.
- **S15 — [U.S. Army Armor — M829 120 mm APFSDS-T cutaway/parts description](https://www.benning.army.mil/Armor/eARMOR/content/issues/1990/JAN_FEB/ArmorJanuaryFebruary1990web.pdf)**: Army publication with an exploded drawing and named major parts for the historical M829 cartridge.
- **S16 — [International ammunition history — British anti-tank ammunition overview](https://www.artilleryhistory.org/gunners_past_and_present/obituaries/nigel_web/anti-tank.htm)**: Historical secondary source for British anti-tank ammunition terminology and development; cross-check exact marks with museum/official records.
- **S17 — [Wikimedia Commons — Arjun tank ammunition photo](https://commons.wikimedia.org/wiki/File:Arjuntankammo.png)**: Photographic comparison captioned APFSDS, HESH, TB and PCB rounds; maker/user photo, so treat as visual illustration rather than a standards document.

Additional useful image indexes: [Anti-tank ammunition on Wikimedia Commons](https://commons.wikimedia.org/wiki/Category:Anti-tank_ammunition), [cutaways of ammunition](https://commons.wikimedia.org/wiki/Category:Cutaways_of_ammunition), and [HEAT munitions](https://commons.wikimedia.org/wiki/Category:HEAT_munition). Use each file page's caption/licensing rather than treating the whole category as a single source.

## Visual overview: how the big families differ

| Family | Common exterior look | What an exterior photo cannot prove |
|---|---|---|
| Solid AP / APC / APBC / APCBC | Full-calibre shell profile; nose shapes/caps vary | Core composition, internal cavity/fuze, exact cap stack |
| APCR / HVAP | Conventional full-calibre-looking body concealing a dense core | Core material and precise nested construction |
| APDS | Sub-calibre shot supported by a discardable sabot in the fired cartridge; compact compared with modern long rods | Exact flight-state parts and penetrator material |
| APFSDS | Long narrow finned dart; complete cartridge often hides most of the projectile in a sabot/case assembly | Tungsten vs depleted uranium, exact alloy and internal mass |
| HEAT / tandem HEAT | Shell or rocket/missile warhead with a nose/fuze region; often externally ordinary-looking | Shaped-charge liner, tandem layout, exact fuze architecture |
| HESH/HEP | Often blunter or flatter nose than kinetic penetrators | Filling type, wall construction and fuze from silhouette alone |
| HE / HE-FRAG | Shell or missile warhead with tapered nose and fuze | Whether fragments are preformed, scored or generated from body |
| HEDP / HEAA | Often a compact shell/rocket/grenade with a HEAT-like nose | The precise combination of effects and construction |
| Canister | Plain cylinder or cartridge with enclosed payload | Payload type/count and internal packing |
| Guided ATGM | Long cylindrical missile airframe, nose/seeker region and flight surfaces; frequently photographed inside a tube/canister | Guidance logic, warhead details, attack profile from shape alone |
| Training / drill | Similar parent-round profile, sometimes distinctive marking/colour | Whether it is fully inert, ballistic practice or instrumented |

---

## Part I — Ammunition mechanism families

### A01 — Solid armour-piercing shot (AP)

**Family:** Solid armour-piercing shot (AP)  
**Exterior appearance:** Solid armour-piercing shot (AP) is a family/mechanism label rather than a single catalogue specimen. An exposed projectile typically has a solid, pointed or ogival metal nose flowing into a cylindrical body and a flat or gently tapered base. There is no visually obvious discarding sabot and no broad soft squash-head. In a complete cartridge the projectile is seated ahead of a case; in separate-loading systems, the shot may be displayed separately from the propellant charge.

**What a cutaway may show:** A sectioned example generally reveals a solid projectile body rather than a large explosive cavity. Exact internal structure, alloy, heat treatment and any hidden cavity cannot be inferred from an ordinary exterior photograph.

**Recognition cues:** Look for the uninterrupted solid-shot profile and absence of a clearly separate sabot. A pointed nose alone does not prove that an object is AP.

**ArmorLab visual guidance:** Model one coherent projectile body with a material identity and a nose profile from a specific reference image. Do not add explosive filling, a sabot or fins unless the exact variant shows them.

**Caveats:** Historic shot geometry and nose treatments vary by gun, era and nation; displayed museum examples are not all identical. This entry describes a broad ammunition family, not one standardised physical object. Treat the description as a family-level visual guide and select a period/calibre-specific specimen before committing to an exact mesh.

**References:** [source record](https://www.nam.ac.uk/explore/attack-tanks); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22Solid+armour-piercing+shot+%28AP%29%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22Solid+armour-piercing+shot+%28AP%29%22+ammunition+photo+cutaway).

### A02 — APC (Armour-Piercing Capped)

**Family:** Armour-piercing capped (APC)  
**Exterior appearance:** APC (Armour-Piercing Capped) is a family/mechanism label rather than a single catalogue specimen. Usually a conventional metal shell silhouette with a rounded, blunt or truncated hard nose under a distinct cap. The cap may look like a separate shallow nose piece, but patina, paint and photographs can make its boundary hard to see. The body is generally a long cylinder with an ogival shoulder.

**What a cutaway may show:** A cutaway or close view can distinguish the penetration cap from the main body. Some APC rounds have an internal cavity/fuze; others have different fillings, so the type label alone does not establish every internal detail.

**Recognition cues:** A rounded/capped nose is the general family cue; do not assume it has a second aerodynamic windshield unless identified as APCBC or another double-cap form.

**ArmorLab visual guidance:** Separate nose-cap and body materials only when reference evidence supports that construction; keep the visible exterior cap boundary subtle and variant-specific.

**Caveats:** The external cap can be hard to identify from a single front-facing image; use period-specific photographs. This entry describes a broad ammunition family, not one standardised physical object. Treat the description as a family-level visual guide and select a period/calibre-specific specimen before committing to an exact mesh.

**References:** [source record](https://www.artilleryhistory.org/gunners_past_and_present/obituaries/nigel_web/anti-tank.htm); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22APC+%28Armour-Piercing+Capped%29%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22APC+%28Armour-Piercing+Capped%29%22+ammunition+photo+cutaway).

### A03 — APBC (Armour-Piercing Ballistic-Capped)

**Family:** Armour-piercing ballistic-capped (APBC)  
**Exterior appearance:** APBC (Armour-Piercing Ballistic-Capped) is a family/mechanism label rather than a single catalogue specimen. The outside nose is generally streamlined and tapered by a ballistic windshield/cap. The windshield gives the projectile a smoother, more elongated nose than many blunt capped shots. The main body remains shell-like rather than a modern long thin dart.

**What a cutaway may show:** A cross-section or exploded display is needed to separate the aerodynamic cap from the main projectile and establish whether any additional armour-piercing cap or explosive cavity exists.

**Recognition cues:** The smooth aerodynamic nose is the useful silhouette cue; the aerodynamic cap itself may not be obvious from an intact specimen.

**ArmorLab visual guidance:** Keep the external aerodynamic contour continuous. Only show a cap seam if the chosen round has one documented; do not convert it to a fin-stabilised dart.

**Caveats:** Historical nomenclature is not perfectly consistent across all national ammunition catalogues. This entry describes a broad ammunition family, not one standardised physical object. Treat the description as a family-level visual guide and select a period/calibre-specific specimen before committing to an exact mesh.

**References:** [source record](https://www.artilleryhistory.org/gunners_past_and_present/obituaries/nigel_web/anti-tank.htm); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22APBC+%28Armour-Piercing+Ballistic-Capped%29%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22APBC+%28Armour-Piercing+Ballistic-Capped%29%22+ammunition+photo+cutaway).

### A04 — APCBC (Armour-Piercing Capped Ballistic-Capped)

**Family:** Armour-piercing capped, ballistic-capped (APCBC)  
**Exterior appearance:** APCBC (Armour-Piercing Capped Ballistic-Capped) is a family/mechanism label rather than a single catalogue specimen. Usually an ogival shell with a relatively blunt or rounded nose treatment under a more tapered outer ballistic windshield. The projectile has a full-calibre cylindrical body and typically looks like a conventional tank/gun shell, not an arrow-like modern penetrator.

**What a cutaway may show:** Reference cutaways may show a harder penetration cap and a distinct outer aerodynamic cap. Some variants also contain an explosive cavity and base fuze, but that must be confirmed for the designation.

**Recognition cues:** The nose may look long and sleek even though the underlying penetrator is capped and full calibre. The letters APCBC do not guarantee a particular visible paint scheme.

**ArmorLab visual guidance:** Use a full-calibre projectile mesh with layered nose-cap regions only where the exact example supports them. Keep case/cartridge form separate from the projectile model.

**Caveats:** APCBC projectile-only photos and complete-cartridge photos can look substantially different; the round may be shown with its case or as a loose shell. This entry describes a broad ammunition family, not one standardised physical object. Treat the description as a family-level visual guide and select a period/calibre-specific specimen before committing to an exact mesh.

**References:** [source record](https://www.artilleryhistory.org/gunners_past_and_present/obituaries/nigel_web/anti-tank.htm); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22APCBC+%28Armour-Piercing+Capped+Ballistic-Capped%29%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22APCBC+%28Armour-Piercing+Capped+Ballistic-Capped%29%22+ammunition+photo+cutaway).

### A05 — APHE (Armour-Piercing High-Explosive)

**Family:** Armour-piercing high-explosive (APHE)  
**Exterior appearance:** APHE (Armour-Piercing High-Explosive) is a family/mechanism label rather than a single catalogue specimen. The exterior often resembles a conventional full-calibre armour-piercing shell: metal cylindrical body, tapered/ogival nose, and a base or nose fuze depending on model. The explosive filling is generally hidden, so an intact object may not look obviously different from a non-filling AP shell.

**What a cutaway may show:** A sectioned example reveals an internal cavity/filling and fuze arrangement. A base-fuzed example may show a fuze at the rear; not every APHE design uses the same layout.

**Recognition cues:** Do not identify APHE by nose shape alone; look for a documented designation, fuze or cutaway.

**ArmorLab visual guidance:** Show a shell-like exterior. Keep fuze, cavity and filling as internal components only if an evidenced cutaway exists; do not imply a detonating outcome from appearance alone.

**Caveats:** APHE, APHEBC and APHECBC designations cover multiple national variants with differing cap and fuze arrangements. This entry describes a broad ammunition family, not one standardised physical object. Treat the description as a family-level visual guide and select a period/calibre-specific specimen before committing to an exact mesh.

**References:** [source record](https://en.wikipedia.org/wiki/Armor-piercing_shell); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22APHE+%28Armour-Piercing+High-Explosive%29%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22APHE+%28Armour-Piercing+High-Explosive%29%22+ammunition+photo+cutaway).

### A06 — APHEBC / APHECBC

**Family:** Armour-piercing high-explosive (APHE)  
**Exterior appearance:** APHEBC / APHECBC is a family/mechanism label rather than a single catalogue specimen. The exterior often resembles a conventional full-calibre armour-piercing shell: metal cylindrical body, tapered/ogival nose, and a base or nose fuze depending on model. The explosive filling is generally hidden, so an intact object may not look obviously different from a non-filling AP shell.

**What a cutaway may show:** A sectioned example reveals an internal cavity/filling and fuze arrangement. A base-fuzed example may show a fuze at the rear; not every APHE design uses the same layout.

**Recognition cues:** Do not identify APHE by nose shape alone; look for a documented designation, fuze or cutaway.

**ArmorLab visual guidance:** Show a shell-like exterior. Keep fuze, cavity and filling as internal components only if an evidenced cutaway exists; do not imply a detonating outcome from appearance alone.

**Caveats:** APHE, APHEBC and APHECBC designations cover multiple national variants with differing cap and fuze arrangements. This entry describes a broad ammunition family, not one standardised physical object. Treat the description as a family-level visual guide and select a period/calibre-specific specimen before committing to an exact mesh.

**References:** [source record](https://en.wikipedia.org/wiki/Armor-piercing_shell); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22APHEBC++APHECBC%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22APHEBC++APHECBC%22+ammunition+photo+cutaway).

### A07 — APCR (Armour-Piercing Composite Rigid)

**Family:** Armour-piercing composite rigid (APCR)  
**Exterior appearance:** APCR (Armour-Piercing Composite Rigid) is a family/mechanism label rather than a single catalogue specimen. Typically a full-calibre projectile with a relatively compact body surrounding a denser, smaller core. To the eye, the projectile generally remains a short shell-like shape with a pointed or capped front; it is not the extremely long, slender dart associated with modern APFSDS.

**What a cutaway may show:** A cutaway may show the dense core nested inside a lighter body/sleeve. The core is not reliably identifiable in an intact projectile, and colour is not a safe indicator of core material.

**Recognition cues:** The key contrast is a sub-calibre dense core inside a full-calibre carrier/body, rather than a long rod carried in a discarding sabot.

**ArmorLab visual guidance:** Represent the core and surrounding body as separate material regions only with a relevant cutaway; use a compact full-calibre exterior, not an APFSDS silhouette.

**Caveats:** APCR and HVAP are related historical concepts, but national usage and construction differ. This entry describes a broad ammunition family, not one standardised physical object. Treat the description as a family-level visual guide and select a period/calibre-specific specimen before committing to an exact mesh.

**References:** [source record](https://www.artilleryhistory.org/gunners_past_and_present/obituaries/nigel_web/anti-tank.htm); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22APCR+%28Armour-Piercing+Composite+Rigid%29%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22APCR+%28Armour-Piercing+Composite+Rigid%29%22+ammunition+photo+cutaway).

### A08 — HVAP (High-Velocity Armour-Piercing)

**Family:** High-velocity armour-piercing (HVAP)  
**Exterior appearance:** HVAP (High-Velocity Armour-Piercing) is a family/mechanism label rather than a single catalogue specimen. An historical HVAP projectile generally has a full-calibre outer shell/body and compact pointed nose, concealing a smaller dense core. Complete cartridge examples can resemble other contemporary gun ammunition; the internal architecture is clearer in sectioned exhibits.

**What a cutaway may show:** Where a cutaway exists, the contrast between a dense small core and a lighter surrounding body is the main visual feature. Do not infer exact core material from colour in an image.

**Recognition cues:** Not a modern long-rod dart. The outer silhouette remains broadly a conventional shell profile.

**ArmorLab visual guidance:** Use a historically appropriate full-calibre carrier shape and a compact core if internal visualization is enabled; clearly distinguish it from APDS/APFSDS.

**Caveats:** HVAP is a U.S. term often compared with APCR, but it should not be treated as a universally identical design. This entry describes a broad ammunition family, not one standardised physical object. Treat the description as a family-level visual guide and select a period/calibre-specific specimen before committing to an exact mesh.

**References:** [source record](https://www.forecastinternational.com/archive/disp_pdf.cfm?DACH_RECNO=1609); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22HVAP+%28High-Velocity+Armour-Piercing%29%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22HVAP+%28High-Velocity+Armour-Piercing%29%22+ammunition+photo+cutaway).

### A09 — APDS (Armour-Piercing Discarding Sabot)

**Family:** Armour-piercing discarding sabot (APDS)  
**Exterior appearance:** APDS (Armour-Piercing Discarding Sabot) is a family/mechanism label rather than a single catalogue specimen. A complete cartridge often presents as a large gun cartridge with a smaller-calibre pointed projectile nested in a segmented or otherwise discardable sabot assembly. A display of the projectile alone may show the compact penetrator surrounded by petals/segments; a post-launch projectile is much narrower than the bore-calibre round.

**What a cutaway may show:** Cutaways or exploded displays can reveal the sub-calibre shot and surrounding sabot. Some designs have a pointed projectile-only nose and a short rear section; dimensions and petal shape vary by model.

**Recognition cues:** The sabot is the distinctive visual idea. Do not depict APDS as a long modern finned dart by default, and do not assume the spent sabot remains attached in flight.

**ArmorLab visual guidance:** For a complete cartridge view, show the case and sabot-supported projectile; for a flight/impact view, show only the projectile after discard unless modelling the short discard phase explicitly.

**Caveats:** Period APDS rounds vary substantially. Do not use a modern round’s long-rod silhouette for WWII APDS. This entry describes a broad ammunition family, not one standardised physical object. Treat the description as a family-level visual guide and select a period/calibre-specific specimen before committing to an exact mesh.

**References:** [source record](https://www.tankmuseum.ca/blog-post/modern-anti-tank-ammunition/); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22APDS+%28Armour-Piercing+Discarding+Sabot%29%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22APDS+%28Armour-Piercing+Discarding+Sabot%29%22+ammunition+photo+cutaway).

### A10 — APFS (Armour-Piercing Fin-Stabilised)

**Family:** Armour-piercing fin-stabilised (APFS)  
**Exterior appearance:** APFS (Armour-Piercing Fin-Stabilised) is a family/mechanism label rather than a single catalogue specimen. The projectile is elongated and has stabilising fins at the rear; unlike APFSDS, this label does not itself say the sabot discards. In some contexts the designation is an abbreviated or loosely used form, so a reliable model-specific photo is needed before selecting a precise silhouette.

**What a cutaway may show:** A profile or cutaway should establish whether the whole projectile remains full-calibre or uses another support arrangement. Fins and their arrangement are more reliable visual indicators than paint.

**Recognition cues:** Rear stabilising fins are the broad cue; the presence or absence of a discarding sabot must come from the actual model.

**ArmorLab visual guidance:** Create a generic fin-stabilised projectile only if the exact designation supports it; avoid adding a long rod and discarded petals by assumption.

**Caveats:** APFS by itself is less standardised in broad public summaries than APFSDS. This entry describes a broad ammunition family, not one standardised physical object. Treat the description as a family-level visual guide and select a period/calibre-specific specimen before committing to an exact mesh.

**References:** [source record](https://www.forecastinternational.com/archive/disp_pdf.cfm?DACH_RECNO=1609); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22APFS+%28Armour-Piercing+Fin-Stabilised%29%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22APFS+%28Armour-Piercing+Fin-Stabilised%29%22+ammunition+photo+cutaway).

### A11 — APFSDS (Armour-Piercing Fin-Stabilised Discarding Sabot)

**Family:** Armour-piercing fin-stabilised discarding sabot (APFSDS)  
**Exterior appearance:** APFSDS (Armour-Piercing Fin-Stabilised Discarding Sabot) is a family/mechanism label rather than a single catalogue specimen. In a complete tank cartridge the visible shape is a tall cylindrical cartridge body with a relatively narrow, pointed projectile package at the front; the penetrator itself is a long slender dart with small stabilising fins at the rear and is carried in a larger sabot during launch. A projectile-only display can look almost spear-like, while a complete cartridge can look like a full-bore shell/case.

**What a cutaway may show:** A cutaway or exploded drawing can show the long penetrator, fin assembly, segmented sabot and the cartridge/case arrangement. Western one-piece tank cartridges and two-piece-loading systems do not display the same outer form.

**Recognition cues:** Long, slender penetrator and rear fins are the principal cues. The penetrator’s tungsten or depleted-uranium composition generally cannot be identified visually.

**ArmorLab visual guidance:** Use a separate long-rod body and fin set, and a separate sabot when modelling the launch package. Do not hard-code impact results from the label or material name.

**Caveats:** The designation covers many generations and national forms; projectile-only, complete-round and cutaway pictures should not be mixed as if they show the same assembly. This entry describes a broad ammunition family, not one standardised physical object. Treat the description as a family-level visual guide and select a period/calibre-specific specimen before committing to an exact mesh.

**References:** [source record](https://www.tankmuseum.ca/blog-post/modern-anti-tank-ammunition/); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22APFSDS+%28Armour-Piercing+Fin-Stabilised+Discarding+Sabot%29%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22APFSDS+%28Armour-Piercing+Fin-Stabilised+Discarding+Sabot%29%22+ammunition+photo+cutaway).

### A12 — APFSDS-T

**Family:** APFSDS with tracer (APFSDS-T)  
**Exterior appearance:** APFSDS-T is a family/mechanism label rather than a single catalogue specimen. The overall silhouette is the APFSDS family: a complete large-calibre cartridge with a narrow forward projectile package, while the actual penetrator is a long slender fin-stabilised rod with a discardable sabot. The tracer is typically a rear/base feature and may not be visible in a standard exterior photo.

**What a cutaway may show:** The projectile/round cutaway may show the tracer element at the rear/base region in addition to the fins, sabot and cartridge assembly. It is not a visible luminous trail when the ammunition is stored or photographed.

**Recognition cues:** Treat the “T” as a tracer-related designation, not a different nose shape. Tracer presence is usually confirmed from documentation/cutaway rather than the exterior alone.

**ArmorLab visual guidance:** Base the shape on the APFSDS parent design; add a tracer component only when supported by an illustrated technical reference.

**Caveats:** Tracer arrangements differ by round and should not be assumed identical across all APFSDS-T designations. This entry describes a broad ammunition family, not one standardised physical object. Treat the description as a family-level visual guide and select a period/calibre-specific specimen before committing to an exact mesh.

**References:** [source record](https://www.forecastinternational.com/archive/disp_pdf.cfm?DACH_RECNO=1609); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22APFSDS-T%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22APFSDS-T%22+ammunition+photo+cutaway).

### A13 — APFSDS-TP / TPCSDS-TP

**Family:** APFSDS / discarding-sabot target-practice family  
**Exterior appearance:** APFSDS-TP / TPCSDS-TP is a family/mechanism label rather than a single catalogue specimen. Training variants commonly mimic the overall length and external profile of a tactical kinetic-energy cartridge but can substitute a different projectile shape, nose colour, tracking feature or non-tactical construction. In a photograph, bright bands/tips or a distinctive painted body may identify a particular nation’s practice round, but colours are not universal.

**What a cutaway may show:** A practice specimen may be inert or may contain a tracking/tracer or other instrumentation feature; training designation alone does not tell you which components it has.

**Recognition cues:** The shape is intended to represent a parent round, but visual markings and actual material construction may differ markedly.

**ArmorLab visual guidance:** Keep the relevant training designation and markings as asset metadata. Do not copy the tactical penetrator’s material values into the trainer automatically.

**Caveats:** TP, TPFSDS, TPCSDS and other training abbreviations vary between services and can describe different degrees of simulation. This entry describes a broad ammunition family, not one standardised physical object. Treat the description as a family-level visual guide and select a period/calibre-specific specimen before committing to an exact mesh.

**References:** [source record](https://jpeoaa.army.mil/Portals/94/MAS/Documents/MASHandbook_2025.pdf); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22APFSDS-TP++TPCSDS-TP%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22APFSDS-TP++TPCSDS-TP%22+ammunition+photo+cutaway).

### A14 — Tungsten-alloy long rod

**Family:** Armour-piercing fin-stabilised discarding sabot (APFSDS)  
**Exterior appearance:** Tungsten-alloy long rod is a family/mechanism label rather than a single catalogue specimen. In a complete tank cartridge the visible shape is a tall cylindrical cartridge body with a relatively narrow, pointed projectile package at the front; the penetrator itself is a long slender dart with small stabilising fins at the rear and is carried in a larger sabot during launch. A projectile-only display can look almost spear-like, while a complete cartridge can look like a full-bore shell/case.

**What a cutaway may show:** A cutaway or exploded drawing can show the long penetrator, fin assembly, segmented sabot and the cartridge/case arrangement. Western one-piece tank cartridges and two-piece-loading systems do not display the same outer form.

**Recognition cues:** Long, slender penetrator and rear fins are the principal cues. The penetrator’s tungsten or depleted-uranium composition generally cannot be identified visually.

**ArmorLab visual guidance:** Use a separate long-rod body and fin set, and a separate sabot when modelling the launch package. Do not hard-code impact results from the label or material name.

**Caveats:** The designation covers many generations and national forms; projectile-only, complete-round and cutaway pictures should not be mixed as if they show the same assembly. This entry describes a broad ammunition family, not one standardised physical object. Treat the description as a family-level visual guide and select a period/calibre-specific specimen before committing to an exact mesh.

**References:** [source record](https://knds.com/en/products/ammunition/120-mm); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22Tungsten-alloy+long+rod%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22Tungsten-alloy+long+rod%22+ammunition+photo+cutaway).

### A15 — Depleted-uranium long rod

**Family:** Armour-piercing fin-stabilised discarding sabot (APFSDS)  
**Exterior appearance:** Depleted-uranium long rod is a family/mechanism label rather than a single catalogue specimen. In a complete tank cartridge the visible shape is a tall cylindrical cartridge body with a relatively narrow, pointed projectile package at the front; the penetrator itself is a long slender dart with small stabilising fins at the rear and is carried in a larger sabot during launch. A projectile-only display can look almost spear-like, while a complete cartridge can look like a full-bore shell/case.

**What a cutaway may show:** A cutaway or exploded drawing can show the long penetrator, fin assembly, segmented sabot and the cartridge/case arrangement. Western one-piece tank cartridges and two-piece-loading systems do not display the same outer form.

**Recognition cues:** Long, slender penetrator and rear fins are the principal cues. The penetrator’s tungsten or depleted-uranium composition generally cannot be identified visually.

**ArmorLab visual guidance:** Use a separate long-rod body and fin set, and a separate sabot when modelling the launch package. Do not hard-code impact results from the label or material name.

**Caveats:** The designation covers many generations and national forms; projectile-only, complete-round and cutaway pictures should not be mixed as if they show the same assembly. This entry describes a broad ammunition family, not one standardised physical object. Treat the description as a family-level visual guide and select a period/calibre-specific specimen before committing to an exact mesh.

**References:** [source record](https://www.benning.army.mil/armor/eARMOR/content/issues/2000/JUL_AUG/ArmorJulyAugust2000web.pdf); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22Depleted-uranium+long+rod%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22Depleted-uranium+long+rod%22+ammunition+photo+cutaway).

### A16 — HEAT (High-Explosive Anti-Tank)

**Family:** High-explosive anti-tank (HEAT)  
**Exterior appearance:** HEAT (High-Explosive Anti-Tank) is a family/mechanism label rather than a single catalogue specimen. A conventional HEAT projectile usually has a cylindrical metal body with a rounded or ogival nose region and a fuze at or near the front; rocket or recoilless versions may be a large warhead mounted ahead of a narrower motor/fin section. From the outside it can resemble an ordinary shell or rocket, so the shaped-charge effect is not obvious.

**What a cutaway may show:** A sectioned specimen typically reveals a hollow conical/cup-shaped liner within the warhead, with explosive surrounding it and a fuze arrangement. A visible cone in a cutaway is a key recognition feature, but exact geometry is model-specific.

**Recognition cues:** The external body does not have to be sharply pointed. Nose probes, fuze caps, finned tails and paint differ by system/era.

**ArmorLab visual guidance:** For the visual library, show a plausible external casing plus an optional clearly labelled cutaway illustration; do not draw the internal liner on the exterior or treat the warhead as a kinetic long rod.

**Caveats:** A HEAT label says something about the effect mechanism, not one universal external shape. This entry describes a broad ammunition family, not one standardised physical object. Treat the description as a family-level visual guide and select a period/calibre-specific specimen before committing to an exact mesh.

**References:** [source record](https://www.tankmuseum.ca/blog-post/modern-anti-tank-ammunition/); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22HEAT+%28High-Explosive+Anti-Tank%29%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22HEAT+%28High-Explosive+Anti-Tank%29%22+ammunition+photo+cutaway).

### A17 — HEAT-MP / MPAT

**Family:** HEAT multipurpose / MPAT  
**Exterior appearance:** HEAT-MP / MPAT is a family/mechanism label rather than a single catalogue specimen. The outside generally resembles a conventional HEAT projectile: rounded or pointed nose, cylindrical body and a base/flight arrangement appropriate to the gun or launcher. Some multipurpose tank rounds have conspicuous nose fittings or sensor/fuze features, but there is no single shape shared by all MPAT designs.

**What a cutaway may show:** The internal view may show a shaped-charge warhead and additional fuze or sensor components. The exact presence of a proximity sensor, selectable mode or particular liner design must be checked against the named model’s datasheet.

**Recognition cues:** MP/MPAT signals multiple intended roles, not a unique external silhouette. A generic HEAT photo should not be labelled as a particular multipurpose round without evidence.

**ArmorLab visual guidance:** Represent the outer shell from the exact round photo; model programmable/proximity components only for variants with a source that documents them.

**Caveats:** HEAT-MP, MPAT and multipurpose HE are not synonyms for every manufacturer or calibre. This entry describes a broad ammunition family, not one standardised physical object. Treat the description as a family-level visual guide and select a period/calibre-specific specimen before committing to an exact mesh.

**References:** [source record](https://jpeoaa.army.mil/Portals/94/Documents/JPEOAAPortfolioBook_2025.pdf); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22HEAT-MP++MPAT%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22HEAT-MP++MPAT%22+ammunition+photo+cutaway).

### A18 — Tandem HEAT

**Family:** Tandem HEAT  
**Exterior appearance:** Tandem HEAT is a family/mechanism label rather than a single catalogue specimen. A tandem-warhead missile or rocket may have a long nose section or probe ahead of the main warhead body, but other designs keep the forward section integrated into a smooth nose. The full item often reads visually as an elongated missile/rocket with a nose assembly, cylindrical body and rear flight surfaces.

**What a cutaway may show:** A cutaway identifies two axially arranged charge sections within a shared warhead assembly. The small forward section may be concealed externally; it should not be inferred from an ordinary side photograph.

**Recognition cues:** Tandem is an internal warhead arrangement, not a dependable external shape classification. Probes and noses vary by weapon.

**ArmorLab visual guidance:** Use an exact named-weapon external reference for the silhouette. In educational cutaways, label the forward and main sections schematically without inventing dimensions.

**Caveats:** Not all tandem systems look alike, and a visible nose probe does not by itself prove a tandem warhead. This entry describes a broad ammunition family, not one standardised physical object. Treat the description as a family-level visual guide and select a period/calibre-specific specimen before committing to an exact mesh.

**References:** [source record](https://www.ausa.org/publications/ode-sagger-drill-addressing-modern-anti-tank-guided-missile-problem-set); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22Tandem+HEAT%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22Tandem+HEAT%22+ammunition+photo+cutaway).

### A19 — HESH / HEP (High-Explosive Squash Head / Plastic)

**Family:** High-explosive squash head / plastic (HESH/HEP)  
**Exterior appearance:** HESH / HEP (High-Explosive Squash Head / Plastic) is a family/mechanism label rather than a single catalogue specimen. Often a comparatively blunt, rounded or flattened nose on a shell-like body, with a nose arrangement intended for the filling to spread against the target. The profile can look squat or less sharply pointed than a kinetic penetrator. Some examples, particularly complete cartridges, can still look like ordinary large-calibre shells.

**What a cutaway may show:** A cutaway shows a thin-walled warhead containing a malleable explosive filling and a base fuze in typical historical designs. The exterior alone rarely reveals the internal filling.

**Recognition cues:** Blunt/flattened nose is a useful family clue, but do not use silhouette alone to positively identify HESH.

**ArmorLab visual guidance:** Choose a named HESH/HEP reference and reproduce the outer casing geometry. Keep the material filling and base-fuze detail in a cutaway view, not as exposed external geometry.

**Caveats:** HESH and HEP labels are used across different national systems; nose and fuze arrangement varies. This entry describes a broad ammunition family, not one standardised physical object. Treat the description as a family-level visual guide and select a period/calibre-specific specimen before committing to an exact mesh.

**References:** [source record](https://www.tankmuseum.ca/blog-post/modern-anti-tank-ammunition/); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22HESH++HEP+%28High-Explosive+Squash+Head++Plastic%29%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22HESH++HEP+%28High-Explosive+Squash+Head++Plastic%29%22+ammunition+photo+cutaway).

### A20 — EFP / explosively formed penetrator

**Family:** Explosively formed penetrator (EFP) warhead  
**Exterior appearance:** EFP / explosively formed penetrator is a family/mechanism label rather than a single catalogue specimen. The complete munition is usually a cylindrical or streamlined warhead body rather than an exposed spear-shaped penetrator. The metallic liner is hidden inside the warhead; the intact external form often cannot be distinguished from other missile/munition bodies by sight alone.

**What a cutaway may show:** A non-functional explanatory cutaway shows a shallow concave liner and surrounding warhead volume. The term refers to the formed projectile produced at functioning, not a permanently protruding dart on the stored munition.

**Recognition cues:** The internal liner form and documented designation matter more than the exterior silhouette. Some concept systems have little public imagery.

**ArmorLab visual guidance:** Use a neutral, source-accurate exterior silhouette; keep any cutaway diagram labelled as conceptual/illustrative and avoid inventing an exact internal layout when unavailable.

**Caveats:** Different EFP systems and multi-projectile warheads have distinct layouts; public images may be schematic. This entry describes a broad ammunition family, not one standardised physical object. Treat the description as a family-level visual guide and select a period/calibre-specific specimen before committing to an exact mesh.

**References:** [source record](https://asc.army.mil/docs/wsh2/1997-wsh.pdf); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22EFP++explosively+formed+penetrator%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22EFP++explosively+formed+penetrator%22+ammunition+photo+cutaway).

### A21 — HE (High Explosive)

**Family:** High explosive (HE)  
**Exterior appearance:** HE (High Explosive) is a family/mechanism label rather than a single catalogue specimen. Usually a conventional shell body with rounded/ogival nose, cylindrical midsection and a fuze at the nose or base. The wall/body may be thick and robust; external form varies with calibre and whether the cartridge is complete, separate-loaded or a projectile on its own.

**What a cutaway may show:** A section typically reveals an explosive cavity and fuze arrangement. Some modern HE rounds have multiple-mode/programming components; that is not visible on every exterior model.

**Recognition cues:** A nose fuze is common but not universal. HE external silhouette alone is not sufficient to identify the filler or exact effect.

**ArmorLab visual guidance:** Start with a documented shell profile and distinguish projectile from complete cartridge. Use generic internal fill only in clearly labelled educational cutaway mode.

**Caveats:** “HE” describes the broad role, not a single shell shape or fuze configuration. This entry describes a broad ammunition family, not one standardised physical object. Treat the description as a family-level visual guide and select a period/calibre-specific specimen before committing to an exact mesh.

**References:** [source record](https://www.forecastinternational.com/archive/disp_pdf.cfm?DACH_RECNO=1609); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22HE+%28High+Explosive%29%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22HE+%28High+Explosive%29%22+ammunition+photo+cutaway).

### A22 — HE-FRAG / HEI / fragmentation

**Family:** High-explosive fragmentation / HE-FRAG  
**Exterior appearance:** HE-FRAG / HEI / fragmentation is a family/mechanism label rather than a single catalogue specimen. Often similar to a conventional HE shell or missile warhead: a cylindrical metal body with a tapered nose/fuze. Fragmentation features can be internal and not visible from the outside; certain designs have external grooves, but many do not.

**What a cutaway may show:** A cross-section may show a thicker casing, preformed fragment elements or an internal fragmentation liner. Do not assume every HE-FRAG shell has visible square scoring or a separate fragmentation sleeve.

**Recognition cues:** The visible body can resemble general HE; designation and cutaway are needed to identify fragmentation construction.

**ArmorLab visual guidance:** Use realistic shell material and mass distribution in the appearance model; represent fragments as a post-event simulation only if the underlying solver actually computes them.

**Caveats:** HEI includes incendiary-related effects in some classes; don’t merge every HEI and HE-FRAG construction into one exact model. This entry describes a broad ammunition family, not one standardised physical object. Treat the description as a family-level visual guide and select a period/calibre-specific specimen before committing to an exact mesh.

**References:** [source record](https://www.forecastinternational.com/archive/disp_pdf.cfm?DACH_RECNO=1609); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22HE-FRAG++HEI++fragmentation%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22HE-FRAG++HEI++fragmentation%22+ammunition+photo+cutaway).

### A23 — HEDP / HEAA

**Family:** High-explosive dual-purpose / anti-armour (HEDP/HEAA)  
**Exterior appearance:** HEDP / HEAA is a family/mechanism label rather than a single catalogue specimen. Frequently a rocket/grenade projectile with a rounded or ogival nose and cylindrical body, sometimes carried in a larger launcher tube. It resembles a HEAT-family warhead externally, but a visual match should not be inferred solely from that similarity.

**What a cutaway may show:** A cutaway may show both a shaped-charge-style liner region and a body designed for fragmentation/blast effects; precise construction differs by round.

**Recognition cues:** The launcher tube and the ammunition projectile are often photographed together. Separate them in the catalogue and label which object a picture depicts.

**ArmorLab visual guidance:** Use an exact family reference and model the projectile itself separately from launcher tube, grenade cup or rocket motor if the design has those parts.

**Caveats:** HEDP and HEAA are family labels; they do not imply identical warhead geometry. This entry describes a broad ammunition family, not one standardised physical object. Treat the description as a family-level visual guide and select a period/calibre-specific specimen before committing to an exact mesh.

**References:** [source record](https://www.defence.gov.au/about/locations-property/unexploded-ordnance-australia/types-unexploded-ordnance); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22HEDP++HEAA%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22HEDP++HEAA%22+ammunition+photo+cutaway).

### A24 — Programmable multi-purpose round

**Family:** Programmable multipurpose round  
**Exterior appearance:** Programmable multi-purpose round is a family/mechanism label rather than a single catalogue specimen. Usually retains the overall form of a conventional gun cartridge or projectile. Depending on the system, the nose may have a fuze/sensor housing, visible bands or a data/setting interface, but much of the programmable function is electronic and invisible externally.

**What a cutaway may show:** Official product cutaways and programme descriptions are the best way to see fuze electronics, mode-setting hardware and internal payload layout. Do not add a fantasy antenna or exposed electronics merely to signify “smart”.

**Recognition cues:** Programmability is a functional property. A plain-looking cartridge may be programmable; visible markings alone may not identify the available firing modes.

**ArmorLab visual guidance:** Base the external mesh on the exact named cartridge. Store programmed mode as simulation metadata rather than changing the exterior model without evidence.

**Caveats:** Different systems programme by muzzle interface, inductive setting, fuze interface or other methods; there is no universal visual cue. This entry describes a broad ammunition family, not one standardised physical object. Treat the description as a family-level visual guide and select a period/calibre-specific specimen before committing to an exact mesh.

**References:** [source record](https://www.army.mil/article/251668/soldiers_make_history_firing_experimental_tank_round_15_years_in_the_making); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22Programmable+multi-purpose+round%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22Programmable+multi-purpose+round%22+ammunition+photo+cutaway).

### A25 — STAFF / top-attack EFP concept

**Family:** STAFF / top-attack EFP development concept  
**Exterior appearance:** STAFF / top-attack EFP concept is a family/mechanism label rather than a single catalogue specimen. Public material identifies this as a developmental gun-launched smart/top-attack concept, not a common standard round with a universally documented exterior. Any image should be treated as a programme illustration, demonstration article or model-specific artifact—not as a canonical service cartridge.

**What a cutaway may show:** The name is associated in public programme descriptions with a sensor-activated top-attack/formed-projectile concept. Detailed internal layout and external appearance should only be described from an attributable original programme document.

**Recognition cues:** Do not mistake a generic tank round illustration for a confirmed XM943 STAFF photograph.

**ArmorLab visual guidance:** Use a clearly labelled conceptual asset or neutral generic cartridge silhouette unless a reliable source image of the specific version is found.

**Caveats:** Development concepts can change between demonstrators and programme phases; public descriptions may not include a confirmed production design. This entry describes a broad ammunition family, not one standardised physical object. Treat the description as a family-level visual guide and select a period/calibre-specific specimen before committing to an exact mesh.

**References:** [source record](https://asc.army.mil/docs/wsh2/1997-wsh.pdf); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22STAFF++top-attack+EFP+concept%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22STAFF++top-attack+EFP+concept%22+ammunition+photo+cutaway).

### A26 — TERM-KE / guided kinetic-energy concept

**Family:** TERM-KE guided kinetic-energy development concept  
**Exterior appearance:** TERM-KE / guided kinetic-energy concept is a family/mechanism label rather than a single catalogue specimen. Public sources identify TERM-KE as an experimental guided kinetic-energy tank-munition programme. A stable, publicly verified external silhouette for all versions is not established by the available catalogue sources.

**What a cutaway may show:** No generic cutaway should be invented from the name. Use only an authenticated programme drawing/photograph if available; otherwise describe internal layout as unknown.

**Recognition cues:** The programme label is more reliable than any unverified internet image that claims to show the exact round.

**ArmorLab visual guidance:** Use a clearly marked concept placeholder with low visual confidence, or omit the mesh until a verified reference is found.

**Caveats:** Prototype/development status and terminology must be retained; do not depict this as a standard fielded round without reliable evidence. This entry describes a broad ammunition family, not one standardised physical object. Treat the description as a family-level visual guide and select a period/calibre-specific specimen before committing to an exact mesh.

**References:** [source record](https://asc.army.mil/docs/wsh2/1997-wsh.pdf); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22TERM-KE++guided+kinetic-energy+concept%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22TERM-KE++guided+kinetic-energy+concept%22+ammunition+photo+cutaway).

### A27 — Gun-launched anti-tank guided missile

**Family:** Gun-launched anti-tank guided missile  
**Exterior appearance:** Gun-launched anti-tank guided missile is a family/mechanism label rather than a single catalogue specimen. A gun-launched missile may share the tank gun’s cartridge envelope when loaded, while the missile itself is a slim cylindrical airframe with a nose section, body seams and deployable/fixed flight surfaces according to the model. In split-loading systems, the missile and propellant charge may be separate items.

**What a cutaway may show:** A cutaway can reveal a nose/seeker or fuze section, warhead section, propulsion section and control surfaces, but these are model-specific. Do not assume all gun-launched missiles use the same guidance or tail-fin design.

**Recognition cues:** It is a guided missile, not just an ordinary shell with a different tip. The visible object may be the missile, cartridge or complete loading unit.

**ArmorLab visual guidance:** Model missile and cartridge/launcher interfaces as separate objects when the system uses separate components. Add fins and sensor housings only from the named system reference.

**Caveats:** 9M112, 9M119-family and later missiles differ; grouped designations in the catalogue cover variants. This entry describes a broad ammunition family, not one standardised physical object. Treat the description as a family-level visual guide and select a period/calibre-specific specimen before committing to an exact mesh.

**References:** [source record](https://www.ausa.org/publications/ode-sagger-drill-addressing-modern-anti-tank-guided-missile-problem-set); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22Gun-launched+anti-tank+guided+missile%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22Gun-launched+anti-tank+guided+missile%22+ammunition+photo+cutaway).

### A28 — Top-attack ATGM

**Family:** Top-attack anti-tank guided missile  
**Exterior appearance:** Top-attack ATGM is a family/mechanism label rather than a single catalogue specimen. Typically an elongated missile or sealed launch container. The missile has a nose section that may contain a seeker or fuze, a cylindrical midbody, and stabilising/control surfaces toward the rear or midbody. Some portable systems are best photographed as a complete launch tube rather than as the exposed missile.

**What a cutaway may show:** Warhead and guidance details require a system-specific cutaway. The chosen top-attack mode generally is not something you can determine from the external shape alone.

**Recognition cues:** The missile body is the object; the launch unit, sight, tripod or canister can be much larger. Do not accidentally catalogue the whole launcher as the projectile.

**ArmorLab visual guidance:** Separate the missile, transport/launch tube and sighting unit in visual assets. Keep flight profile/mode as simulation state, not a visual effect hard-coded to a silhouette.

**Caveats:** Top-attack is an attack profile and is not synonymous with one specific warhead construction. This entry describes a broad ammunition family, not one standardised physical object. Treat the description as a family-level visual guide and select a period/calibre-specific specimen before committing to an exact mesh.

**References:** [source record](https://www.ausa.org/publications/ode-sagger-drill-addressing-modern-anti-tank-guided-missile-problem-set); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22Top-attack+ATGM%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22Top-attack+ATGM%22+ammunition+photo+cutaway).

### A29 — Direct-attack ATGM

**Family:** Direct-attack anti-tank guided missile  
**Exterior appearance:** Direct-attack ATGM is a family/mechanism label rather than a single catalogue specimen. Generally a long cylindrical missile with a rounded/ogival nose, small wings or fins, body bands/seams and a tail/motor section. A full system photograph may show the launch container, guidance unit, tripod or vehicle launcher as well as the missile.

**What a cutaway may show:** A cutaway can show seeker/fuze, warhead, motor and control sections. Public museum displays such as the ENTAC cutaway provide an example of how these assemblies can be presented, but one missile’s interior is not a template for another.

**Recognition cues:** The exact external profile, fin arrangement and nose materials are family-specific. Paint and stencilling are often display- or operator-dependent.

**ArmorLab visual guidance:** Select an exact missile silhouette and distinguish in-flight missile from its sealed canister. Add control surfaces only where supported by photographs.

**Caveats:** The catalogue uses “ATGM” across several generations, guidance types and warhead families; appearance must follow the selected designation. This entry describes a broad ammunition family, not one standardised physical object. Treat the description as a family-level visual guide and select a period/calibre-specific specimen before committing to an exact mesh.

**References:** [source record](https://www.ausa.org/publications/ode-sagger-drill-addressing-modern-anti-tank-guided-missile-problem-set); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22Direct-attack+ATGM%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22Direct-attack+ATGM%22+ammunition+photo+cutaway).

### A30 — Man-portable anti-armour rocket / recoilless projectile

**Family:** Man-portable anti-armour rocket / recoilless projectile  
**Exterior appearance:** Man-portable anti-armour rocket / recoilless projectile is a family/mechanism label rather than a single catalogue specimen. The projectile/rocket often consists of a large warhead section with rounded or ogival nose, a narrower cylindrical rear body and tail stabilisers/fins or an attached motor/boom. Some weapons are issued as a complete disposable launcher tube, so photos may show the entire launcher instead of a separable round.

**What a cutaway may show:** A cutaway can reveal a warhead section and motor/stabilisation parts; the exact arrangement differs across rocket, recoilless and rifle-grenade systems. An external tube must not be mistaken for the projectile itself.

**Recognition cues:** The relative size of the warhead and narrower tail is a broad visual clue, but there are important exceptions.

**ArmorLab visual guidance:** Create separate assets for projectile, launcher/launch tube, and any disposable container. Use the correct configuration for the specific named system.

**Caveats:** This category intentionally spans distinct launch methods; it should not be a single shared physical template. This entry describes a broad ammunition family, not one standardised physical object. Treat the description as a family-level visual guide and select a period/calibre-specific specimen before committing to an exact mesh.

**References:** [source record](https://www.defence.gov.au/about/locations-property/unexploded-ordnance-australia/types-unexploded-ordnance); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22Man-portable+anti-armour+rocket++recoilless+projectile%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22Man-portable+anti-armour+rocket++recoilless+projectile%22+ammunition+photo+cutaway).

### A31 — Canister / anti-personnel tank round

**Family:** Canister / area-effect tank round  
**Exterior appearance:** Canister / anti-personnel tank round is a family/mechanism label rather than a single catalogue specimen. The complete tank cartridge typically looks like a conventional cylindrical cartridge, with a closed projectile canister at the front rather than the exposed needle-like penetrator of an APFSDS. The exterior may be almost plain, making its contents hard to infer from a photo.

**What a cutaway may show:** A cutaway typically shows a canister body packed with multiple small projectiles or other payload elements; a round such as the M1028 is often described by the analogy of a large shotgun-like payload.

**Recognition cues:** A canister round is not visually identified by a unique nose tip in every example; official product sheets and cutaways help confirm the type.

**ArmorLab visual guidance:** Use a closed cylindrical canister shell and do not add a long rod, shaped-charge cone or conventional HE cavity unless the named round supports it.

**Caveats:** Exact payload forms and fuzes vary; avoid presenting the generic analogy as a complete construction drawing. This entry describes a broad ammunition family, not one standardised physical object. Treat the description as a family-level visual guide and select a period/calibre-specific specimen before committing to an exact mesh.

**References:** [source record](https://jpeoaa.army.mil/Portals/94/Documents/JPEOAAPortfolioBook_2025.pdf); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22Canister++anti-personnel+tank+round%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22Canister++anti-personnel+tank+round%22+ammunition+photo+cutaway).

### A32 — Obstacle-reduction round

**Family:** Obstacle-reduction / special-purpose round  
**Exterior appearance:** Obstacle-reduction round is a family/mechanism label rather than a single catalogue specimen. Often appears as a normal full-calibre tank cartridge with an ogival projectile or broad multipurpose nose. It may be difficult to distinguish from other special-purpose rounds in a line-up without markings or an official caption.

**What a cutaway may show:** The internal payload and fuze/casing features are model-specific. For M908, rely on U.S. Army programme documentation rather than guessing from a generic nose shape.

**Recognition cues:** The role is not reliably readable from an isolated photograph. The projectile should not automatically be drawn as a larger explosive round than related cartridges.

**ArmorLab visual guidance:** Use the exact product photo where one exists; show the effect through the actual modeled material/physics only when implemented, not by a premade crater animation.

**Caveats:** “Obstacle reduction” covers specialised effects and is not itself a single projectile architecture. This entry describes a broad ammunition family, not one standardised physical object. Treat the description as a family-level visual guide and select a period/calibre-specific specimen before committing to an exact mesh.

**References:** [source record](https://www.army.mil/article/251668/soldiers_make_history_firing_experimental_tank_round_15_years_in_the_making); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22Obstacle-reduction+round%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22Obstacle-reduction+round%22+ammunition+photo+cutaway).

### A33 — Smoke / obscurant / white-phosphorus round

**Family:** Smoke / obscurant / white-phosphorus round  
**Exterior appearance:** Smoke / obscurant / white-phosphorus round is a family/mechanism label rather than a single catalogue specimen. Often resembles a conventional shell, rocket or grenade body with a nose/body fuze and a payload section; the smoke or obscurant is hidden while the item is intact. Different delivery systems may be cylindrical tank rounds, mortar/artillery shells, rockets or missiles.

**What a cutaway may show:** A section view shows the smoke/obscurant payload and deployment/delay components appropriate to the model. A white-phosphorus designation must not be assumed for generic smoke rounds; many obscurant compositions exist.

**Recognition cues:** The external silhouette alone cannot reliably identify the smoke chemistry. Markings and designation are more informative than paint in a random photo.

**ArmorLab visual guidance:** Separate the visual exterior from any smoke effect. Use a generic smoke event only if the physics/effect system models it; do not infer chemical composition from appearance.

**Caveats:** This family intentionally groups distinct smoke/obscuration payload types and delivery systems; each is not interchangeable. This entry describes a broad ammunition family, not one standardised physical object. Treat the description as a family-level visual guide and select a period/calibre-specific specimen before committing to an exact mesh.

**References:** [source record](https://www.forecastinternational.com/archive/disp_pdf.cfm?DACH_RECNO=1609); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22Smoke++obscurant++white-phosphorus+round%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22Smoke++obscurant++white-phosphorus+round%22+ammunition+photo+cutaway).

### A34 — Illumination round

**Family:** Illumination round  
**Exterior appearance:** Illumination round is a family/mechanism label rather than a single catalogue specimen. The intact cartridge typically looks like a shell or cylindrical payload container. There may be a nose or base fuze, but the visible exterior can be indistinguishable from other payload rounds without a label.

**What a cutaway may show:** A cutaway often reveals a flare payload and deployment/parachute components. The internal arrangement varies with calibre, delivery method and era.

**Recognition cues:** The parachute/flare is generally part of the deployed payload, not something exposed on the intact round.

**ArmorLab visual guidance:** Model the intact shell and a separate deployment event; if only the impact solver is in scope, list illumination as a visual/reference category rather than a penetration projectile.

**Caveats:** Illumination is a role; it does not imply a unique outer shape. This entry describes a broad ammunition family, not one standardised physical object. Treat the description as a family-level visual guide and select a period/calibre-specific specimen before committing to an exact mesh.

**References:** [source record](https://www.mod.go.jp/j/approach/hyouka/yosan_shikko/2018/04.pdf); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22Illumination+round%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22Illumination+round%22+ammunition+photo+cutaway).

### A35 — Training / drill round

**Family:** Training / drill / practice round  
**Exterior appearance:** Training / drill round is a family/mechanism label rather than a single catalogue specimen. Training ammunition often mimics the tactical round’s overall profile but may have a solid inert nose, different mass-distribution features, tracking/tracer hardware or conspicuous identification colours. It can also be a dummy/drill cartridge with no live functional payload. Color conventions are specific to the service, date and item.

**What a cutaway may show:** A cutaway shows how the trainer omits or replaces tactical components; however “practice” can still mean several different constructions, including target-practice projectiles that approximate external ballistics.

**Recognition cues:** Look for a designation and official colour/marking standard. Never use one generic blue/black/orange texture rule for all countries and periods.

**ArmorLab visual guidance:** Treat `training_status`, `inert_status`, and `ballistic_similarity` as separate metadata. Build the exact visual profile of the named trainer and do not give it tactical material/fuze behaviour by default.

**Caveats:** Training, drill, target-practice, TPFSDS, TPMP and inert are not exact synonyms. This entry describes a broad ammunition family, not one standardised physical object. Treat the description as a family-level visual guide and select a period/calibre-specific specimen before committing to an exact mesh.

**References:** [source record](https://www.jpeoaa.army.mil/Portals/94/MAS/Documents/MASHandbook_2025.pdf); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22Training++drill+round%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22Training++drill+round%22+ammunition+photo+cutaway).


## Part II — Named ammunition and designation entries

### R001 — 2-pdr AP shot

**Family:** Solid armour-piercing shot (AP)  
**Exterior appearance:** 2-pdr AP shot is catalogued here as AP solid shot. An exposed projectile typically has a solid, pointed or ogival metal nose flowing into a cylindrical body and a flat or gently tapered base. There is no visually obvious discarding sabot and no broad soft squash-head. In a complete cartridge the projectile is seated ahead of a case; in separate-loading systems, the shot may be displayed separately from the propellant charge.

**What a cutaway may show:** A sectioned example generally reveals a solid projectile body rather than a large explosive cavity. Exact internal structure, alloy, heat treatment and any hidden cavity cannot be inferred from an ordinary exterior photograph.

**Recognition cues:** Look for the uninterrupted solid-shot profile and absence of a clearly separate sabot. A pointed nose alone does not prove that an object is AP.

**ArmorLab visual guidance:** Model one coherent projectile body with a material identity and a nose profile from a specific reference image. Do not add explosive filling, a sabot or fins unless the exact variant shows them.

**Caveats:** Historic shot geometry and nose treatments vary by gun, era and nation; displayed museum examples are not all identical. Catalogue note: Early solid shot example; historical family rather than modern tank round. Listed platform/compatibility: British 2-pounder gun. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://www.artilleryhistory.org/gunners_past_and_present/obituaries/nigel_web/anti-tank.htm); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%222-pdr+AP+shot%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%222-pdr+AP+shot%22+ammunition+photo+cutaway).

### R002 — 6-pdr APCBC

**Family:** Armour-piercing capped, ballistic-capped (APCBC)  
**Exterior appearance:** 6-pdr APCBC is catalogued here as APCBC. Usually an ogival shell with a relatively blunt or rounded nose treatment under a more tapered outer ballistic windshield. The projectile has a full-calibre cylindrical body and typically looks like a conventional tank/gun shell, not an arrow-like modern penetrator.

**What a cutaway may show:** Reference cutaways may show a harder penetration cap and a distinct outer aerodynamic cap. Some variants also contain an explosive cavity and base fuze, but that must be confirmed for the designation.

**Recognition cues:** The nose may look long and sleek even though the underlying penetrator is capped and full calibre. The letters APCBC do not guarantee a particular visible paint scheme.

**ArmorLab visual guidance:** Use a full-calibre projectile mesh with layered nose-cap regions only where the exact example supports them. Keep case/cartridge form separate from the projectile model.

**Caveats:** APCBC projectile-only photos and complete-cartridge photos can look substantially different; the round may be shown with its case or as a loose shell. Catalogue note: Common British WW2 capped/ballistic-capped family designation. Listed platform/compatibility: QF 6-pounder. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://www.artilleryhistory.org/gunners_past_and_present/obituaries/nigel_web/anti-tank.htm); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%226-pdr+APCBC%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%226-pdr+APCBC%22+ammunition+photo+cutaway).

### R003 — 17-pdr APDS

**Family:** Armour-piercing discarding sabot (APDS)  
**Exterior appearance:** 17-pdr APDS is catalogued here as APDS. A complete cartridge often presents as a large gun cartridge with a smaller-calibre pointed projectile nested in a segmented or otherwise discardable sabot assembly. A display of the projectile alone may show the compact penetrator surrounded by petals/segments; a post-launch projectile is much narrower than the bore-calibre round.

**What a cutaway may show:** Cutaways or exploded displays can reveal the sub-calibre shot and surrounding sabot. Some designs have a pointed projectile-only nose and a short rear section; dimensions and petal shape vary by model.

**Recognition cues:** The sabot is the distinctive visual idea. Do not depict APDS as a long modern finned dart by default, and do not assume the spent sabot remains attached in flight.

**ArmorLab visual guidance:** For a complete cartridge view, show the case and sabot-supported projectile; for a flight/impact view, show only the projectile after discard unless modelling the short discard phase explicitly.

**Caveats:** Period APDS rounds vary substantially. Do not use a modern round’s long-rod silhouette for WWII APDS. Catalogue note: Important early service use of discarding-sabot shot. Listed platform/compatibility: QF 17-pounder / Firefly family. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://www.artilleryhistory.org/gunners_past_and_present/obituaries/nigel_web/anti-tank.htm); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%2217-pdr+APDS%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%2217-pdr+APDS%22+ammunition+photo+cutaway).

### R004 — 20-pdr APDS

**Family:** Armour-piercing discarding sabot (APDS)  
**Exterior appearance:** 20-pdr APDS is catalogued here as APDS. A complete cartridge often presents as a large gun cartridge with a smaller-calibre pointed projectile nested in a segmented or otherwise discardable sabot assembly. A display of the projectile alone may show the compact penetrator surrounded by petals/segments; a post-launch projectile is much narrower than the bore-calibre round.

**What a cutaway may show:** Cutaways or exploded displays can reveal the sub-calibre shot and surrounding sabot. Some designs have a pointed projectile-only nose and a short rear section; dimensions and petal shape vary by model.

**Recognition cues:** The sabot is the distinctive visual idea. Do not depict APDS as a long modern finned dart by default, and do not assume the spent sabot remains attached in flight.

**ArmorLab visual guidance:** For a complete cartridge view, show the case and sabot-supported projectile; for a flight/impact view, show only the projectile after discard unless modelling the short discard phase explicitly.

**Caveats:** Period APDS rounds vary substantially. Do not use a modern round’s long-rod silhouette for WWII APDS. Catalogue note: Representative postwar APDS round family. Listed platform/compatibility: Centurion 20-pounder gun. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://www.tankmuseum.ca/blog-post/modern-anti-tank-ammunition/); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%2220-pdr+APDS%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%2220-pdr+APDS%22+ammunition+photo+cutaway).

### R005 — L15-series APDS

**Family:** Armour-piercing discarding sabot (APDS)  
**Exterior appearance:** L15-series APDS is catalogued here as APDS. A complete cartridge often presents as a large gun cartridge with a smaller-calibre pointed projectile nested in a segmented or otherwise discardable sabot assembly. A display of the projectile alone may show the compact penetrator surrounded by petals/segments; a post-launch projectile is much narrower than the bore-calibre round.

**What a cutaway may show:** Cutaways or exploded displays can reveal the sub-calibre shot and surrounding sabot. Some designs have a pointed projectile-only nose and a short rear section; dimensions and petal shape vary by model.

**Recognition cues:** The sabot is the distinctive visual idea. Do not depict APDS as a long modern finned dart by default, and do not assume the spent sabot remains attached in flight.

**ArmorLab visual guidance:** For a complete cartridge view, show the case and sabot-supported projectile; for a flight/impact view, show only the projectile after discard unless modelling the short discard phase explicitly.

**Caveats:** Period APDS rounds vary substantially. Do not use a modern round’s long-rod silhouette for WWII APDS. Catalogue note: Designation family used in British tank-ammunition history; exact marks should be checked by gun. Listed platform/compatibility: 105 mm tank guns / specific gun variants. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://en.wikipedia.org/wiki/Armour-piercing_discarding_sabot); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22L15-series+APDS%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22L15-series+APDS%22+ammunition+photo+cutaway).

### R006 — L31 HESH

**Family:** High-explosive squash head / plastic (HESH/HEP)  
**Exterior appearance:** L31 HESH is catalogued here as HESH/HEP. Often a comparatively blunt, rounded or flattened nose on a shell-like body, with a nose arrangement intended for the filling to spread against the target. The profile can look squat or less sharply pointed than a kinetic penetrator. Some examples, particularly complete cartridges, can still look like ordinary large-calibre shells.

**What a cutaway may show:** A cutaway shows a thin-walled warhead containing a malleable explosive filling and a base fuze in typical historical designs. The exterior alone rarely reveals the internal filling.

**Recognition cues:** Blunt/flattened nose is a useful family clue, but do not use silhouette alone to positively identify HESH.

**ArmorLab visual guidance:** Choose a named HESH/HEP reference and reproduce the outer casing geometry. Keep the material filling and base-fuze detail in a cutaway view, not as exposed external geometry.

**Caveats:** HESH and HEP labels are used across different national systems; nose and fuze arrangement varies. Catalogue note: Representative British HESH family; exact mark/gun compatibility varies. Listed platform/compatibility: British 120 mm rifled tank guns. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://www.tankmuseum.ca/blog-post/modern-anti-tank-ammunition/); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22L31+HESH%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22L31+HESH%22+ammunition+photo+cutaway).

### R007 — L23A1 APFSDS

**Family:** Armour-piercing fin-stabilised discarding sabot (APFSDS)  
**Exterior appearance:** L23A1 APFSDS is catalogued here as APFSDS. In a complete tank cartridge the visible shape is a tall cylindrical cartridge body with a relatively narrow, pointed projectile package at the front; the penetrator itself is a long slender dart with small stabilising fins at the rear and is carried in a larger sabot during launch. A projectile-only display can look almost spear-like, while a complete cartridge can look like a full-bore shell/case.

**What a cutaway may show:** A cutaway or exploded drawing can show the long penetrator, fin assembly, segmented sabot and the cartridge/case arrangement. Western one-piece tank cartridges and two-piece-loading systems do not display the same outer form.

**Recognition cues:** Long, slender penetrator and rear fins are the principal cues. The penetrator’s tungsten or depleted-uranium composition generally cannot be identified visually.

**ArmorLab visual guidance:** Use a separate long-rod body and fin set, and a separate sabot when modelling the launch package. Do not hard-code impact results from the label or material name.

**Caveats:** The designation covers many generations and national forms; projectile-only, complete-round and cutaway pictures should not be mixed as if they show the same assembly. Catalogue note: British kinetic-energy family; keep projectile model separate from gun/barrel compatibility. Listed platform/compatibility: 120 mm Challenger 2 L30 rifled gun. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://en.wikipedia.org/wiki/Challenger_2); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22L23A1+APFSDS%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22L23A1+APFSDS%22+ammunition+photo+cutaway).

### R008 — L26A1 CHARM 1

**Family:** Armour-piercing fin-stabilised discarding sabot (APFSDS)  
**Exterior appearance:** L26A1 CHARM 1 is catalogued here as APFSDS. In a complete tank cartridge the visible shape is a tall cylindrical cartridge body with a relatively narrow, pointed projectile package at the front; the penetrator itself is a long slender dart with small stabilising fins at the rear and is carried in a larger sabot during launch. A projectile-only display can look almost spear-like, while a complete cartridge can look like a full-bore shell/case.

**What a cutaway may show:** A cutaway or exploded drawing can show the long penetrator, fin assembly, segmented sabot and the cartridge/case arrangement. Western one-piece tank cartridges and two-piece-loading systems do not display the same outer form.

**Recognition cues:** Long, slender penetrator and rear fins are the principal cues. The penetrator’s tungsten or depleted-uranium composition generally cannot be identified visually.

**ArmorLab visual guidance:** Use a separate long-rod body and fin set, and a separate sabot when modelling the launch package. Do not hard-code impact results from the label or material name.

**Caveats:** The designation covers many generations and national forms; projectile-only, complete-round and cutaway pictures should not be mixed as if they show the same assembly. Catalogue note: Publicly reported CHARM-family designation; materials/ballistics not fully enumerated here. The penetrator metal/alloy cannot be positively identified from ordinary exterior colour or shape. Avoid rendering material-specific colour as if it were a reliable visual property; record composition only where a traceable source confirms it. Listed platform/compatibility: 120 mm Challenger 2 L30 rifled gun. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://en.wikipedia.org/wiki/Challenger_2); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22L26A1+CHARM+1%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22L26A1+CHARM+1%22+ammunition+photo+cutaway).

### R009 — L27A1 CHARM 3

**Family:** Armour-piercing fin-stabilised discarding sabot (APFSDS)  
**Exterior appearance:** L27A1 CHARM 3 is catalogued here as APFSDS. In a complete tank cartridge the visible shape is a tall cylindrical cartridge body with a relatively narrow, pointed projectile package at the front; the penetrator itself is a long slender dart with small stabilising fins at the rear and is carried in a larger sabot during launch. A projectile-only display can look almost spear-like, while a complete cartridge can look like a full-bore shell/case.

**What a cutaway may show:** A cutaway or exploded drawing can show the long penetrator, fin assembly, segmented sabot and the cartridge/case arrangement. Western one-piece tank cartridges and two-piece-loading systems do not display the same outer form.

**Recognition cues:** Long, slender penetrator and rear fins are the principal cues. The penetrator’s tungsten or depleted-uranium composition generally cannot be identified visually.

**ArmorLab visual guidance:** Use a separate long-rod body and fin set, and a separate sabot when modelling the launch package. Do not hard-code impact results from the label or material name.

**Caveats:** The designation covers many generations and national forms; projectile-only, complete-round and cutaway pictures should not be mixed as if they show the same assembly. Catalogue note: Public sources associate with a depleted-uranium long-rod penetrator; exact data restricted/limited. The penetrator metal/alloy cannot be positively identified from ordinary exterior colour or shape. Avoid rendering material-specific colour as if it were a reliable visual property; record composition only where a traceable source confirms it. Listed platform/compatibility: 120 mm Challenger 2 L30 rifled gun. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://www.frontiersin.org/journals/political-science/articles/10.3389/fpos.2024.1387183/full); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22L27A1+CHARM+3%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22L27A1+CHARM+3%22+ammunition+photo+cutaway).

### R010 — L29A1 C3TR

**Family:** Training / drill / practice round  
**Exterior appearance:** L29A1 C3TR is catalogued here as Target-practice / training. Training ammunition often mimics the tactical round’s overall profile but may have a solid inert nose, different mass-distribution features, tracking/tracer hardware or conspicuous identification colours. It can also be a dummy/drill cartridge with no live functional payload. Color conventions are specific to the service, date and item.

**What a cutaway may show:** A cutaway shows how the trainer omits or replaces tactical components; however “practice” can still mean several different constructions, including target-practice projectiles that approximate external ballistics.

**Recognition cues:** Look for a designation and official colour/marking standard. Never use one generic blue/black/orange texture rule for all countries and periods.

**ArmorLab visual guidance:** Treat `training_status`, `inert_status`, and `ballistic_similarity` as separate metadata. Build the exact visual profile of the named trainer and do not give it tactical material/fuze behaviour by default.

**Caveats:** Training, drill, target-practice, TPFSDS, TPMP and inert are not exact synonyms. Catalogue note: Training designation cited in public secondary literature; confirm specific service context before use. Training colour and marking rules are nation-, era- and designation-specific. Do not rely on a generic blue/black/orange material to identify every practice or inert round; use the documented item caption. Listed platform/compatibility: British 120 mm tank gun. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://www.frontiersin.org/journals/political-science/articles/10.3389/fpos.2024.1387183/full); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22L29A1+C3TR%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22L29A1+C3TR%22+ammunition+photo+cutaway).

### R011 — M61 APC

**Family:** Armour-piercing capped (APC)  
**Exterior appearance:** M61 APC is catalogued here as APC. Usually a conventional metal shell silhouette with a rounded, blunt or truncated hard nose under a distinct cap. The cap may look like a separate shallow nose piece, but patina, paint and photographs can make its boundary hard to see. The body is generally a long cylinder with an ogival shoulder.

**What a cutaway may show:** A cutaway or close view can distinguish the penetration cap from the main body. Some APC rounds have an internal cavity/fuze; others have different fillings, so the type label alone does not establish every internal detail.

**Recognition cues:** A rounded/capped nose is the general family cue; do not assume it has a second aerodynamic windshield unless identified as APCBC or another double-cap form.

**ArmorLab visual guidance:** Separate nose-cap and body materials only when reference evidence supports that construction; keep the visible exterior cap boundary subtle and variant-specific.

**Caveats:** The external cap can be hard to identify from a single front-facing image; use period-specific photographs. Catalogue note: Representative US capped AP family; exact designation depends on calibre. Listed platform/compatibility: US 76 mm / 90 mm ammunition families (variant-dependent). Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://en.wikipedia.org/wiki/Armour-piercing_capped_shell); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22M61+APC%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22M61+APC%22+ammunition+photo+cutaway).

### R012 — M62 APCBC

**Family:** Armour-piercing capped, ballistic-capped (APCBC)  
**Exterior appearance:** M62 APCBC is catalogued here as APCBC. Usually an ogival shell with a relatively blunt or rounded nose treatment under a more tapered outer ballistic windshield. The projectile has a full-calibre cylindrical body and typically looks like a conventional tank/gun shell, not an arrow-like modern penetrator.

**What a cutaway may show:** Reference cutaways may show a harder penetration cap and a distinct outer aerodynamic cap. Some variants also contain an explosive cavity and base fuze, but that must be confirmed for the designation.

**Recognition cues:** The nose may look long and sleek even though the underlying penetrator is capped and full calibre. The letters APCBC do not guarantee a particular visible paint scheme.

**ArmorLab visual guidance:** Use a full-calibre projectile mesh with layered nose-cap regions only where the exact example supports them. Keep case/cartridge form separate from the projectile model.

**Caveats:** APCBC projectile-only photos and complete-cartridge photos can look substantially different; the round may be shown with its case or as a loose shell. Catalogue note: APCBC family appears in several US calibre contexts; not one universal projectile. Listed platform/compatibility: US tank-gun ammunition family (variant-dependent). Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://en.wikipedia.org/wiki/Armour-piercing_capped_shell); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22M62+APCBC%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22M62+APCBC%22+ammunition+photo+cutaway).

### R013 — M93 HVAP

**Family:** High-velocity armour-piercing (HVAP)  
**Exterior appearance:** M93 HVAP is catalogued here as HVAP/APCR family. An historical HVAP projectile generally has a full-calibre outer shell/body and compact pointed nose, concealing a smaller dense core. Complete cartridge examples can resemble other contemporary gun ammunition; the internal architecture is clearer in sectioned exhibits.

**What a cutaway may show:** Where a cutaway exists, the contrast between a dense small core and a lighter surrounding body is the main visual feature. Do not infer exact core material from colour in an image.

**Recognition cues:** Not a modern long-rod dart. The outer silhouette remains broadly a conventional shell profile.

**ArmorLab visual guidance:** Use a historically appropriate full-calibre carrier shape and a compact core if internal visualization is enabled; clearly distinguish it from APDS/APFSDS.

**Caveats:** HVAP is a U.S. term often compared with APCR, but it should not be treated as a universally identical design. Catalogue note: Historical high-velocity sub-calibre family designation. Listed platform/compatibility: US tank/anti-tank gun ammunition. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://en.wikipedia.org/wiki/High-velocity_armour-piercing); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22M93+HVAP%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22M93+HVAP%22+ammunition+photo+cutaway).

### R014 — M392 APDS

**Family:** Armour-piercing discarding sabot (APDS)  
**Exterior appearance:** M392 APDS is catalogued here as APDS. A complete cartridge often presents as a large gun cartridge with a smaller-calibre pointed projectile nested in a segmented or otherwise discardable sabot assembly. A display of the projectile alone may show the compact penetrator surrounded by petals/segments; a post-launch projectile is much narrower than the bore-calibre round.

**What a cutaway may show:** Cutaways or exploded displays can reveal the sub-calibre shot and surrounding sabot. Some designs have a pointed projectile-only nose and a short rear section; dimensions and petal shape vary by model.

**Recognition cues:** The sabot is the distinctive visual idea. Do not depict APDS as a long modern finned dart by default, and do not assume the spent sabot remains attached in flight.

**ArmorLab visual guidance:** For a complete cartridge view, show the case and sabot-supported projectile; for a flight/impact view, show only the projectile after discard unless modelling the short discard phase explicitly.

**Caveats:** Period APDS rounds vary substantially. Do not use a modern round’s long-rod silhouette for WWII APDS. Catalogue note: Representative early APDS family used in NATO 105 mm contexts; individual gun compatibility varies. Listed platform/compatibility: 105 mm tank-gun ammunition family. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://en.wikipedia.org/wiki/Armour-piercing_discarding_sabot); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22M392+APDS%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22M392+APDS%22+ammunition+photo+cutaway).

### R015 — M456 HEAT-T

**Family:** High-explosive anti-tank (HEAT)  
**Exterior appearance:** M456 HEAT-T is catalogued here as HEAT. A conventional HEAT projectile usually has a cylindrical metal body with a rounded or ogival nose region and a fuze at or near the front; rocket or recoilless versions may be a large warhead mounted ahead of a narrower motor/fin section. From the outside it can resemble an ordinary shell or rocket, so the shaped-charge effect is not obvious.

**What a cutaway may show:** A sectioned specimen typically reveals a hollow conical/cup-shaped liner within the warhead, with explosive surrounding it and a fuze arrangement. A visible cone in a cutaway is a key recognition feature, but exact geometry is model-specific.

**Recognition cues:** The external body does not have to be sharply pointed. Nose probes, fuze caps, finned tails and paint differ by system/era.

**ArmorLab visual guidance:** For the visual library, show a plausible external casing plus an optional clearly labelled cutaway illustration; do not draw the internal liner on the exterior or treat the warhead as a kinetic long rod.

**Caveats:** A HEAT label says something about the effect mechanism, not one universal external shape. Catalogue note: US HEAT family; exact cartridge details depend on mark. Listed platform/compatibility: 105 mm tank guns. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://en.wikipedia.org/wiki/M456_(ammunition)); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22M456+HEAT-T%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22M456+HEAT-T%22+ammunition+photo+cutaway).

### R016 — M735 APFSDS

**Family:** Armour-piercing fin-stabilised discarding sabot (APFSDS)  
**Exterior appearance:** M735 APFSDS is catalogued here as APFSDS. In a complete tank cartridge the visible shape is a tall cylindrical cartridge body with a relatively narrow, pointed projectile package at the front; the penetrator itself is a long slender dart with small stabilising fins at the rear and is carried in a larger sabot during launch. A projectile-only display can look almost spear-like, while a complete cartridge can look like a full-bore shell/case.

**What a cutaway may show:** A cutaway or exploded drawing can show the long penetrator, fin assembly, segmented sabot and the cartridge/case arrangement. Western one-piece tank cartridges and two-piece-loading systems do not display the same outer form.

**Recognition cues:** Long, slender penetrator and rear fins are the principal cues. The penetrator’s tungsten or depleted-uranium composition generally cannot be identified visually.

**ArmorLab visual guidance:** Use a separate long-rod body and fin set, and a separate sabot when modelling the launch package. Do not hard-code impact results from the label or material name.

**Caveats:** The designation covers many generations and national forms; projectile-only, complete-round and cutaway pictures should not be mixed as if they show the same assembly. Catalogue note: Representative US 105 mm APFSDS round. The penetrator metal/alloy cannot be positively identified from ordinary exterior colour or shape. Avoid rendering material-specific colour as if it were a reliable visual property; record composition only where a traceable source confirms it. Listed platform/compatibility: 105 mm M68 family. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://en.wikipedia.org/wiki/M735_(ammunition)); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22M735+APFSDS%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22M735+APFSDS%22+ammunition+photo+cutaway).

### R017 — M774 APFSDS

**Family:** Armour-piercing fin-stabilised discarding sabot (APFSDS)  
**Exterior appearance:** M774 APFSDS is catalogued here as APFSDS. In a complete tank cartridge the visible shape is a tall cylindrical cartridge body with a relatively narrow, pointed projectile package at the front; the penetrator itself is a long slender dart with small stabilising fins at the rear and is carried in a larger sabot during launch. A projectile-only display can look almost spear-like, while a complete cartridge can look like a full-bore shell/case.

**What a cutaway may show:** A cutaway or exploded drawing can show the long penetrator, fin assembly, segmented sabot and the cartridge/case arrangement. Western one-piece tank cartridges and two-piece-loading systems do not display the same outer form.

**Recognition cues:** Long, slender penetrator and rear fins are the principal cues. The penetrator’s tungsten or depleted-uranium composition generally cannot be identified visually.

**ArmorLab visual guidance:** Use a separate long-rod body and fin set, and a separate sabot when modelling the launch package. Do not hard-code impact results from the label or material name.

**Caveats:** The designation covers many generations and national forms; projectile-only, complete-round and cutaway pictures should not be mixed as if they show the same assembly. Catalogue note: US 105 mm kinetic-energy round; no performance claims included. The penetrator metal/alloy cannot be positively identified from ordinary exterior colour or shape. Avoid rendering material-specific colour as if it were a reliable visual property; record composition only where a traceable source confirms it. Listed platform/compatibility: 105 mm M68 family. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://en.wikipedia.org/wiki/M774_(ammunition)); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22M774+APFSDS%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22M774+APFSDS%22+ammunition+photo+cutaway).

### R018 — M833 APFSDS

**Family:** Armour-piercing fin-stabilised discarding sabot (APFSDS)  
**Exterior appearance:** M833 APFSDS is catalogued here as APFSDS. In a complete tank cartridge the visible shape is a tall cylindrical cartridge body with a relatively narrow, pointed projectile package at the front; the penetrator itself is a long slender dart with small stabilising fins at the rear and is carried in a larger sabot during launch. A projectile-only display can look almost spear-like, while a complete cartridge can look like a full-bore shell/case.

**What a cutaway may show:** A cutaway or exploded drawing can show the long penetrator, fin assembly, segmented sabot and the cartridge/case arrangement. Western one-piece tank cartridges and two-piece-loading systems do not display the same outer form.

**Recognition cues:** Long, slender penetrator and rear fins are the principal cues. The penetrator’s tungsten or depleted-uranium composition generally cannot be identified visually.

**ArmorLab visual guidance:** Use a separate long-rod body and fin set, and a separate sabot when modelling the launch package. Do not hard-code impact results from the label or material name.

**Caveats:** The designation covers many generations and national forms; projectile-only, complete-round and cutaway pictures should not be mixed as if they show the same assembly. Catalogue note: US 105 mm APFSDS family. The penetrator metal/alloy cannot be positively identified from ordinary exterior colour or shape. Avoid rendering material-specific colour as if it were a reliable visual property; record composition only where a traceable source confirms it. Listed platform/compatibility: 105 mm M68 family. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://en.wikipedia.org/wiki/M833_(ammunition)); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22M833+APFSDS%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22M833+APFSDS%22+ammunition+photo+cutaway).

### R019 — M900 APFSDS

**Family:** Armour-piercing fin-stabilised discarding sabot (APFSDS)  
**Exterior appearance:** M900 APFSDS is catalogued here as APFSDS. In a complete tank cartridge the visible shape is a tall cylindrical cartridge body with a relatively narrow, pointed projectile package at the front; the penetrator itself is a long slender dart with small stabilising fins at the rear and is carried in a larger sabot during launch. A projectile-only display can look almost spear-like, while a complete cartridge can look like a full-bore shell/case.

**What a cutaway may show:** A cutaway or exploded drawing can show the long penetrator, fin assembly, segmented sabot and the cartridge/case arrangement. Western one-piece tank cartridges and two-piece-loading systems do not display the same outer form.

**Recognition cues:** Long, slender penetrator and rear fins are the principal cues. The penetrator’s tungsten or depleted-uranium composition generally cannot be identified visually.

**ArmorLab visual guidance:** Use a separate long-rod body and fin set, and a separate sabot when modelling the launch package. Do not hard-code impact results from the label or material name.

**Caveats:** The designation covers many generations and national forms; projectile-only, complete-round and cutaway pictures should not be mixed as if they show the same assembly. Catalogue note: Later 105 mm kinetic-energy round family. The penetrator metal/alloy cannot be positively identified from ordinary exterior colour or shape. Avoid rendering material-specific colour as if it were a reliable visual property; record composition only where a traceable source confirms it. Listed platform/compatibility: 105 mm M68 family. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://en.wikipedia.org/wiki/M900_(ammunition)); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22M900+APFSDS%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22M900+APFSDS%22+ammunition+photo+cutaway).

### R020 — M829

**Family:** APFSDS with tracer (APFSDS-T)  
**Exterior appearance:** M829 is catalogued here as APFSDS-T. The overall silhouette is the APFSDS family: a complete large-calibre cartridge with a narrow forward projectile package, while the actual penetrator is a long slender fin-stabilised rod with a discardable sabot. The tracer is typically a rear/base feature and may not be visible in a standard exterior photo.

**What a cutaway may show:** The projectile/round cutaway may show the tracer element at the rear/base region in addition to the fins, sabot and cartridge assembly. It is not a visible luminous trail when the ammunition is stored or photographed.

**Recognition cues:** Treat the “T” as a tracer-related designation, not a different nose shape. Tracer presence is usually confirmed from documentation/cutaway rather than the exterior alone.

**ArmorLab visual guidance:** Base the shape on the APFSDS parent design; add a tracer component only when supported by an illustrated technical reference.

**Caveats:** Tracer arrangements differ by round and should not be assumed identical across all APFSDS-T designations. Catalogue note: First M829-series reference; publicly described as a kinetic-energy sabot round. For a Western 120 mm example, distinguish the complete cartridge from the projectile-only training/display object. Some designs use a combustible case with a metal base; a photograph can show a large pale/neutral casing and a separate forward projectile profile. Do not assume one universal case colour. The penetrator metal/alloy cannot be positively identified from ordinary exterior colour or shape. Avoid rendering material-specific colour as if it were a reliable visual property; record composition only where a traceable source confirms it. Listed platform/compatibility: 120 mm M256 gun on Abrams. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://asc.army.mil/docs/wsh2/1997-wsh.pdf); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22M829%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22M829%22+ammunition+photo+cutaway).

### R021 — M829A1

**Family:** APFSDS with tracer (APFSDS-T)  
**Exterior appearance:** M829A1 is catalogued here as APFSDS-T. The overall silhouette is the APFSDS family: a complete large-calibre cartridge with a narrow forward projectile package, while the actual penetrator is a long slender fin-stabilised rod with a discardable sabot. The tracer is typically a rear/base feature and may not be visible in a standard exterior photo.

**What a cutaway may show:** The projectile/round cutaway may show the tracer element at the rear/base region in addition to the fins, sabot and cartridge assembly. It is not a visible luminous trail when the ammunition is stored or photographed.

**Recognition cues:** Treat the “T” as a tracer-related designation, not a different nose shape. Tracer presence is usually confirmed from documentation/cutaway rather than the exterior alone.

**ArmorLab visual guidance:** Base the shape on the APFSDS parent design; add a tracer component only when supported by an illustrated technical reference.

**Caveats:** Tracer arrangements differ by round and should not be assumed identical across all APFSDS-T designations. Catalogue note: M829 family development variant; precise performance not listed. For a Western 120 mm example, distinguish the complete cartridge from the projectile-only training/display object. Some designs use a combustible case with a metal base; a photograph can show a large pale/neutral casing and a separate forward projectile profile. Do not assume one universal case colour. The penetrator metal/alloy cannot be positively identified from ordinary exterior colour or shape. Avoid rendering material-specific colour as if it were a reliable visual property; record composition only where a traceable source confirms it. Listed platform/compatibility: 120 mm M256 gun on Abrams. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://asc.army.mil/docs/wsh2/1997-wsh.pdf); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22M829A1%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22M829A1%22+ammunition+photo+cutaway).

### R022 — M829A2

**Family:** APFSDS with tracer (APFSDS-T)  
**Exterior appearance:** M829A2 is catalogued here as APFSDS-T. The overall silhouette is the APFSDS family: a complete large-calibre cartridge with a narrow forward projectile package, while the actual penetrator is a long slender fin-stabilised rod with a discardable sabot. The tracer is typically a rear/base feature and may not be visible in a standard exterior photo.

**What a cutaway may show:** The projectile/round cutaway may show the tracer element at the rear/base region in addition to the fins, sabot and cartridge assembly. It is not a visible luminous trail when the ammunition is stored or photographed.

**Recognition cues:** Treat the “T” as a tracer-related designation, not a different nose shape. Tracer presence is usually confirmed from documentation/cutaway rather than the exterior alone.

**ArmorLab visual guidance:** Base the shape on the APFSDS parent design; add a tracer component only when supported by an illustrated technical reference.

**Caveats:** Tracer arrangements differ by round and should not be assumed identical across all APFSDS-T designations. Catalogue note: M829 family development variant. For a Western 120 mm example, distinguish the complete cartridge from the projectile-only training/display object. Some designs use a combustible case with a metal base; a photograph can show a large pale/neutral casing and a separate forward projectile profile. Do not assume one universal case colour. The penetrator metal/alloy cannot be positively identified from ordinary exterior colour or shape. Avoid rendering material-specific colour as if it were a reliable visual property; record composition only where a traceable source confirms it. Listed platform/compatibility: 120 mm M256 gun on Abrams. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://asc.army.mil/docs/wsh2/1997-wsh.pdf); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22M829A2%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22M829A2%22+ammunition+photo+cutaway).

### R023 — M829A3

**Family:** APFSDS with tracer (APFSDS-T)  
**Exterior appearance:** M829A3 is catalogued here as APFSDS-T. The overall silhouette is the APFSDS family: a complete large-calibre cartridge with a narrow forward projectile package, while the actual penetrator is a long slender fin-stabilised rod with a discardable sabot. The tracer is typically a rear/base feature and may not be visible in a standard exterior photo.

**What a cutaway may show:** The projectile/round cutaway may show the tracer element at the rear/base region in addition to the fins, sabot and cartridge assembly. It is not a visible luminous trail when the ammunition is stored or photographed.

**Recognition cues:** Treat the “T” as a tracer-related designation, not a different nose shape. Tracer presence is usually confirmed from documentation/cutaway rather than the exterior alone.

**ArmorLab visual guidance:** Base the shape on the APFSDS parent design; add a tracer component only when supported by an illustrated technical reference.

**Caveats:** Tracer arrangements differ by round and should not be assumed identical across all APFSDS-T designations. Catalogue note: M829 family variant; public sources describe evolving protection-threat requirements. For a Western 120 mm example, distinguish the complete cartridge from the projectile-only training/display object. Some designs use a combustible case with a metal base; a photograph can show a large pale/neutral casing and a separate forward projectile profile. Do not assume one universal case colour. The penetrator metal/alloy cannot be positively identified from ordinary exterior colour or shape. Avoid rendering material-specific colour as if it were a reliable visual property; record composition only where a traceable source confirms it. Listed platform/compatibility: 120 mm M256 gun on Abrams. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://www.benning.army.mil/armor/eARMOR/content/issues/2014/JAN_FEB/Brown.html); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22M829A3%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22M829A3%22+ammunition+photo+cutaway).

### R024 — M829A4

**Family:** APFSDS with tracer (APFSDS-T)  
**Exterior appearance:** M829A4 is catalogued here as APFSDS-T. The overall silhouette is the APFSDS family: a complete large-calibre cartridge with a narrow forward projectile package, while the actual penetrator is a long slender fin-stabilised rod with a discardable sabot. The tracer is typically a rear/base feature and may not be visible in a standard exterior photo.

**What a cutaway may show:** The projectile/round cutaway may show the tracer element at the rear/base region in addition to the fins, sabot and cartridge assembly. It is not a visible luminous trail when the ammunition is stored or photographed.

**Recognition cues:** Treat the “T” as a tracer-related designation, not a different nose shape. Tracer presence is usually confirmed from documentation/cutaway rather than the exterior alone.

**ArmorLab visual guidance:** Base the shape on the APFSDS parent design; add a tracer component only when supported by an illustrated technical reference.

**Caveats:** Tracer arrangements differ by round and should not be assumed identical across all APFSDS-T designations. Catalogue note: Official public handbook lists M829A4 as a kinetic-energy round; detailed performance omitted. For a Western 120 mm example, distinguish the complete cartridge from the projectile-only training/display object. Some designs use a combustible case with a metal base; a photograph can show a large pale/neutral casing and a separate forward projectile profile. Do not assume one universal case colour. The penetrator metal/alloy cannot be positively identified from ordinary exterior colour or shape. Avoid rendering material-specific colour as if it were a reliable visual property; record composition only where a traceable source confirms it. Listed platform/compatibility: 120 mm M256 gun on Abrams. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://jpeoaa.army.mil/Portals/94/MAS/Documents/MASHandbook_2025.pdf); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22M829A4%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22M829A4%22+ammunition+photo+cutaway).

### R025 — M830 HEAT-MP-T

**Family:** HEAT multipurpose / MPAT  
**Exterior appearance:** M830 HEAT-MP-T is catalogued here as HEAT-MP-T. The outside generally resembles a conventional HEAT projectile: rounded or pointed nose, cylindrical body and a base/flight arrangement appropriate to the gun or launcher. Some multipurpose tank rounds have conspicuous nose fittings or sensor/fuze features, but there is no single shape shared by all MPAT designs.

**What a cutaway may show:** The internal view may show a shaped-charge warhead and additional fuze or sensor components. The exact presence of a proximity sensor, selectable mode or particular liner design must be checked against the named model’s datasheet.

**Recognition cues:** MP/MPAT signals multiple intended roles, not a unique external silhouette. A generic HEAT photo should not be labelled as a particular multipurpose round without evidence.

**ArmorLab visual guidance:** Represent the outer shell from the exact round photo; model programmable/proximity components only for variants with a source that documents them.

**Caveats:** HEAT-MP, MPAT and multipurpose HE are not synonyms for every manufacturer or calibre. Catalogue note: Multipurpose chemical-energy round in official US handbook. For a Western 120 mm example, distinguish the complete cartridge from the projectile-only training/display object. Some designs use a combustible case with a metal base; a photograph can show a large pale/neutral casing and a separate forward projectile profile. Do not assume one universal case colour. Listed platform/compatibility: 120 mm M256 gun on Abrams. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://jpeoaa.army.mil/Portals/94/MAS/Documents/MASHandbook_2025.pdf); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22M830+HEAT-MP-T%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22M830+HEAT-MP-T%22+ammunition+photo+cutaway).

### R026 — M830A1 HEAT-MP-T / MPAT

**Family:** HEAT multipurpose / MPAT  
**Exterior appearance:** M830A1 HEAT-MP-T / MPAT is catalogued here as Multipurpose anti-tank. The outside generally resembles a conventional HEAT projectile: rounded or pointed nose, cylindrical body and a base/flight arrangement appropriate to the gun or launcher. Some multipurpose tank rounds have conspicuous nose fittings or sensor/fuze features, but there is no single shape shared by all MPAT designs.

**What a cutaway may show:** The internal view may show a shaped-charge warhead and additional fuze or sensor components. The exact presence of a proximity sensor, selectable mode or particular liner design must be checked against the named model’s datasheet.

**Recognition cues:** MP/MPAT signals multiple intended roles, not a unique external silhouette. A generic HEAT photo should not be labelled as a particular multipurpose round without evidence.

**ArmorLab visual guidance:** Represent the outer shell from the exact round photo; model programmable/proximity components only for variants with a source that documents them.

**Caveats:** HEAT-MP, MPAT and multipurpose HE are not synonyms for every manufacturer or calibre. Catalogue note: Official portfolio notes multipurpose capability; exact fuze modes depend on round configuration. For a Western 120 mm example, distinguish the complete cartridge from the projectile-only training/display object. Some designs use a combustible case with a metal base; a photograph can show a large pale/neutral casing and a separate forward projectile profile. Do not assume one universal case colour. Listed platform/compatibility: 120 mm M256 gun on Abrams. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://jpeoaa.army.mil/Portals/94/Documents/JPEOAAPortfolioBook_2025.pdf); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22M830A1+HEAT-MP-T++MPAT%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22M830A1+HEAT-MP-T++MPAT%22+ammunition+photo+cutaway).

### R027 — M908 obstacle-reduction round

**Family:** Obstacle-reduction / special-purpose round  
**Exterior appearance:** M908 obstacle-reduction round is catalogued here as Obstacle reduction / multipurpose. Often appears as a normal full-calibre tank cartridge with an ogival projectile or broad multipurpose nose. It may be difficult to distinguish from other special-purpose rounds in a line-up without markings or an official caption.

**What a cutaway may show:** The internal payload and fuze/casing features are model-specific. For M908, rely on U.S. Army programme documentation rather than guessing from a generic nose shape.

**Recognition cues:** The role is not reliably readable from an isolated photograph. The projectile should not automatically be drawn as a larger explosive round than related cartridges.

**ArmorLab visual guidance:** Use the exact product photo where one exists; show the effect through the actual modeled material/physics only when implemented, not by a premade crater animation.

**Caveats:** “Obstacle reduction” covers specialised effects and is not itself a single projectile architecture. Catalogue note: Public US AMP programme announcement identifies it among rounds intended to be replaced by XM1147. For a Western 120 mm example, distinguish the complete cartridge from the projectile-only training/display object. Some designs use a combustible case with a metal base; a photograph can show a large pale/neutral casing and a separate forward projectile profile. Do not assume one universal case colour. Listed platform/compatibility: 120 mm Abrams gun. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://www.army.mil/article/251668/soldiers_make_history_firing_experimental_tank_round_15_years_in_the_making); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22M908+obstacle-reduction+round%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22M908+obstacle-reduction+round%22+ammunition+photo+cutaway).

### R028 — M1028 Canister

**Family:** Canister / area-effect tank round  
**Exterior appearance:** M1028 Canister is catalogued here as Canister. The complete tank cartridge typically looks like a conventional cylindrical cartridge, with a closed projectile canister at the front rather than the exposed needle-like penetrator of an APFSDS. The exterior may be almost plain, making its contents hard to infer from a photo.

**What a cutaway may show:** A cutaway typically shows a canister body packed with multiple small projectiles or other payload elements; a round such as the M1028 is often described by the analogy of a large shotgun-like payload.

**Recognition cues:** A canister round is not visually identified by a unique nose tip in every example; official product sheets and cutaways help confirm the type.

**ArmorLab visual guidance:** Use a closed cylindrical canister shell and do not add a long rod, shaped-charge cone or conventional HE cavity unless the named round supports it.

**Caveats:** Exact payload forms and fuzes vary; avoid presenting the generic analogy as a complete construction drawing. Catalogue note: Anti-personnel close-range canister, not a tank-penetrator model. For a Western 120 mm example, distinguish the complete cartridge from the projectile-only training/display object. Some designs use a combustible case with a metal base; a photograph can show a large pale/neutral casing and a separate forward projectile profile. Do not assume one universal case colour. Listed platform/compatibility: 120 mm Abrams gun. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://www.army.mil/article/251668/soldiers_make_history_firing_experimental_tank_round_15_years_in_the_making); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22M1028+Canister%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22M1028+Canister%22+ammunition+photo+cutaway).

### R029 — M865 TPCSDS-T

**Family:** Training / drill / practice round  
**Exterior appearance:** M865 TPCSDS-T is catalogued here as Target-practice APDS-like. Training ammunition often mimics the tactical round’s overall profile but may have a solid inert nose, different mass-distribution features, tracking/tracer hardware or conspicuous identification colours. It can also be a dummy/drill cartridge with no live functional payload. Color conventions are specific to the service, date and item.

**What a cutaway may show:** A cutaway shows how the trainer omits or replaces tactical components; however “practice” can still mean several different constructions, including target-practice projectiles that approximate external ballistics.

**Recognition cues:** Look for a designation and official colour/marking standard. Never use one generic blue/black/orange texture rule for all countries and periods.

**ArmorLab visual guidance:** Treat `training_status`, `inert_status`, and `ballistic_similarity` as separate metadata. Build the exact visual profile of the named trainer and do not give it tactical material/fuze behaviour by default.

**Caveats:** Training, drill, target-practice, TPFSDS, TPMP and inert are not exact synonyms. Catalogue note: Training round; should not inherit live penetrator's terminal model automatically. For a Western 120 mm example, distinguish the complete cartridge from the projectile-only training/display object. Some designs use a combustible case with a metal base; a photograph can show a large pale/neutral casing and a separate forward projectile profile. Do not assume one universal case colour. Training colour and marking rules are nation-, era- and designation-specific. Do not rely on a generic blue/black/orange material to identify every practice or inert round; use the documented item caption. Listed platform/compatibility: 120 mm Abrams gun. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://www.forecastinternational.com/archive/disp_pdf.cfm?DACH_RECNO=1609); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22M865+TPCSDS-T%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22M865+TPCSDS-T%22+ammunition+photo+cutaway).

### R030 — M1002 TPMP

**Family:** Training / drill / practice round  
**Exterior appearance:** M1002 TPMP is catalogued here as Target-practice multipurpose. Training ammunition often mimics the tactical round’s overall profile but may have a solid inert nose, different mass-distribution features, tracking/tracer hardware or conspicuous identification colours. It can also be a dummy/drill cartridge with no live functional payload. Color conventions are specific to the service, date and item.

**What a cutaway may show:** A cutaway shows how the trainer omits or replaces tactical components; however “practice” can still mean several different constructions, including target-practice projectiles that approximate external ballistics.

**Recognition cues:** Look for a designation and official colour/marking standard. Never use one generic blue/black/orange texture rule for all countries and periods.

**ArmorLab visual guidance:** Treat `training_status`, `inert_status`, and `ballistic_similarity` as separate metadata. Build the exact visual profile of the named trainer and do not give it tactical material/fuze behaviour by default.

**Caveats:** Training, drill, target-practice, TPFSDS, TPMP and inert are not exact synonyms. Catalogue note: Training ammunition family in public acronyms/handbooks. For a Western 120 mm example, distinguish the complete cartridge from the projectile-only training/display object. Some designs use a combustible case with a metal base; a photograph can show a large pale/neutral casing and a separate forward projectile profile. Do not assume one universal case colour. Training colour and marking rules are nation-, era- and designation-specific. Do not rely on a generic blue/black/orange material to identify every practice or inert round; use the documented item caption. Listed platform/compatibility: 120 mm Abrams gun. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://www.forecastinternational.com/archive/disp_pdf.cfm?DACH_RECNO=1609); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22M1002+TPMP%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22M1002+TPMP%22+ammunition+photo+cutaway).

### R031 — XM943 STAFF

**Family:** STAFF / top-attack EFP development concept  
**Exterior appearance:** XM943 STAFF is catalogued here as Smart top-attack/EFP concept. Public material identifies this as a developmental gun-launched smart/top-attack concept, not a common standard round with a universally documented exterior. Any image should be treated as a programme illustration, demonstration article or model-specific artifact—not as a canonical service cartridge.

**What a cutaway may show:** The name is associated in public programme descriptions with a sensor-activated top-attack/formed-projectile concept. Detailed internal layout and external appearance should only be described from an attributable original programme document.

**Recognition cues:** Do not mistake a generic tank round illustration for a confirmed XM943 STAFF photograph.

**ArmorLab visual guidance:** Use a clearly labelled conceptual asset or neutral generic cartridge silhouette unless a reliable source image of the specific version is found.

**Caveats:** Development concepts can change between demonstrators and programme phases; public descriptions may not include a confirmed production design. Catalogue note: Historical public programme for a Smart Target Activated Fire-and-Forget concept; do not label as current service. Publicly available imagery/specification appears limited or ambiguous in the sources indexed here. Do not invent a canonical production shape. Use a clearly labelled concept representation or omit the model until an attributable reference is found. Listed platform/compatibility: 120 mm Abrams gun. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://asc.army.mil/docs/wsh2/1997-wsh.pdf); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22XM943+STAFF%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22XM943+STAFF%22+ammunition+photo+cutaway).

### R032 — XM1007 TERM-KE

**Family:** TERM-KE guided kinetic-energy development concept  
**Exterior appearance:** XM1007 TERM-KE is catalogued here as Guided kinetic-energy concept. Public sources identify TERM-KE as an experimental guided kinetic-energy tank-munition programme. A stable, publicly verified external silhouette for all versions is not established by the available catalogue sources.

**What a cutaway may show:** No generic cutaway should be invented from the name. Use only an authenticated programme drawing/photograph if available; otherwise describe internal layout as unknown.

**Recognition cues:** The programme label is more reliable than any unverified internet image that claims to show the exact round.

**ArmorLab visual guidance:** Use a clearly marked concept placeholder with low visual confidence, or omit the mesh until a verified reference is found.

**Caveats:** Prototype/development status and terminology must be retained; do not depict this as a standard fielded round without reliable evidence. Catalogue note: Historical Tank Extended Range Munition concept; dated programme status. Publicly available imagery/specification appears limited or ambiguous in the sources indexed here. Do not invent a canonical production shape. Use a clearly labelled concept representation or omit the model until an attributable reference is found. Listed platform/compatibility: 120 mm Abrams gun. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://asc.army.mil/docs/wsh2/1997-wsh.pdf); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22XM1007+TERM-KE%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22XM1007+TERM-KE%22+ammunition+photo+cutaway).

### R033 — XM1147 AMP

**Family:** Programmable multipurpose round  
**Exterior appearance:** XM1147 AMP is catalogued here as Advanced multi-purpose programmable. Usually retains the overall form of a conventional gun cartridge or projectile. Depending on the system, the nose may have a fuze/sensor housing, visible bands or a data/setting interface, but much of the programmable function is electronic and invisible externally.

**What a cutaway may show:** Official product cutaways and programme descriptions are the best way to see fuze electronics, mode-setting hardware and internal payload layout. Do not add a fantasy antenna or exposed electronics merely to signify “smart”.

**Recognition cues:** Programmability is a functional property. A plain-looking cartridge may be programmable; visible markings alone may not identify the available firing modes.

**ArmorLab visual guidance:** Base the external mesh on the exact named cartridge. Store programmed mode as simulation metadata rather than changing the exterior model without evidence.

**Caveats:** Different systems programme by muzzle interface, inductive setting, fuze interface or other methods; there is no universal visual cue. Catalogue note: US Army describes as intended to replace M830A1, M830, M1028 and M908 roles. For a Western 120 mm example, distinguish the complete cartridge from the projectile-only training/display object. Some designs use a combustible case with a metal base; a photograph can show a large pale/neutral casing and a separate forward projectile profile. Do not assume one universal case colour. Listed platform/compatibility: 120 mm Abrams gun. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://www.army.mil/article/251668/soldiers_make_history_firing_experimental_tank_round_15_years_in_the_making); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22XM1147+AMP%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22XM1147+AMP%22+ammunition+photo+cutaway).

### R034 — DM12 HEAT-FS

**Family:** High-explosive anti-tank (HEAT)  
**Exterior appearance:** DM12 HEAT-FS is catalogued here as HEAT. A conventional HEAT projectile usually has a cylindrical metal body with a rounded or ogival nose region and a fuze at or near the front; rocket or recoilless versions may be a large warhead mounted ahead of a narrower motor/fin section. From the outside it can resemble an ordinary shell or rocket, so the shaped-charge effect is not obvious.

**What a cutaway may show:** A sectioned specimen typically reveals a hollow conical/cup-shaped liner within the warhead, with explosive surrounding it and a fuze arrangement. A visible cone in a cutaway is a key recognition feature, but exact geometry is model-specific.

**Recognition cues:** The external body does not have to be sharply pointed. Nose probes, fuze caps, finned tails and paint differ by system/era.

**ArmorLab visual guidance:** For the visual library, show a plausible external casing plus an optional clearly labelled cutaway illustration; do not draw the internal liner on the exterior or treat the warhead as a kinetic long rod.

**Caveats:** A HEAT label says something about the effect mechanism, not one universal external shape. Catalogue note: Well-known German 120 mm HEAT family designation. Listed platform/compatibility: Leopard 2 / 120 mm family (compatibility varies). Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://en.wikipedia.org/wiki/DM12); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22DM12+HEAT-FS%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22DM12+HEAT-FS%22+ammunition+photo+cutaway).

### R035 — DM13 APDS-T

**Family:** Armour-piercing discarding sabot (APDS)  
**Exterior appearance:** DM13 APDS-T is catalogued here as APDS-T. A complete cartridge often presents as a large gun cartridge with a smaller-calibre pointed projectile nested in a segmented or otherwise discardable sabot assembly. A display of the projectile alone may show the compact penetrator surrounded by petals/segments; a post-launch projectile is much narrower than the bore-calibre round.

**What a cutaway may show:** Cutaways or exploded displays can reveal the sub-calibre shot and surrounding sabot. Some designs have a pointed projectile-only nose and a short rear section; dimensions and petal shape vary by model.

**Recognition cues:** The sabot is the distinctive visual idea. Do not depict APDS as a long modern finned dart by default, and do not assume the spent sabot remains attached in flight.

**ArmorLab visual guidance:** For a complete cartridge view, show the case and sabot-supported projectile; for a flight/impact view, show only the projectile after discard unless modelling the short discard phase explicitly.

**Caveats:** Period APDS rounds vary substantially. Do not use a modern round’s long-rod silhouette for WWII APDS. Catalogue note: Representative 105 mm APDS-T designation. Listed platform/compatibility: 105 mm Leopard 1 family. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://en.wikipedia.org/wiki/Leopard_1); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22DM13+APDS-T%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22DM13+APDS-T%22+ammunition+photo+cutaway).

### R036 — DM23 APFSDS

**Family:** Armour-piercing fin-stabilised discarding sabot (APFSDS)  
**Exterior appearance:** DM23 APFSDS is catalogued here as APFSDS. In a complete tank cartridge the visible shape is a tall cylindrical cartridge body with a relatively narrow, pointed projectile package at the front; the penetrator itself is a long slender dart with small stabilising fins at the rear and is carried in a larger sabot during launch. A projectile-only display can look almost spear-like, while a complete cartridge can look like a full-bore shell/case.

**What a cutaway may show:** A cutaway or exploded drawing can show the long penetrator, fin assembly, segmented sabot and the cartridge/case arrangement. Western one-piece tank cartridges and two-piece-loading systems do not display the same outer form.

**Recognition cues:** Long, slender penetrator and rear fins are the principal cues. The penetrator’s tungsten or depleted-uranium composition generally cannot be identified visually.

**ArmorLab visual guidance:** Use a separate long-rod body and fin set, and a separate sabot when modelling the launch package. Do not hard-code impact results from the label or material name.

**Caveats:** The designation covers many generations and national forms; projectile-only, complete-round and cutaway pictures should not be mixed as if they show the same assembly. Catalogue note: Round designation used in German/NATO kinetic-energy history; exact sub-variant by calibre must be distinguished. Listed platform/compatibility: 120 mm and/or calibre-dependent family designations. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://en.wikipedia.org/wiki/Armour-piercing_fin-stabilized_discarding_sabot); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22DM23+APFSDS%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22DM23+APFSDS%22+ammunition+photo+cutaway).

### R037 — DM33 APFSDS

**Family:** Armour-piercing fin-stabilised discarding sabot (APFSDS)  
**Exterior appearance:** DM33 APFSDS is catalogued here as APFSDS. In a complete tank cartridge the visible shape is a tall cylindrical cartridge body with a relatively narrow, pointed projectile package at the front; the penetrator itself is a long slender dart with small stabilising fins at the rear and is carried in a larger sabot during launch. A projectile-only display can look almost spear-like, while a complete cartridge can look like a full-bore shell/case.

**What a cutaway may show:** A cutaway or exploded drawing can show the long penetrator, fin assembly, segmented sabot and the cartridge/case arrangement. Western one-piece tank cartridges and two-piece-loading systems do not display the same outer form.

**Recognition cues:** Long, slender penetrator and rear fins are the principal cues. The penetrator’s tungsten or depleted-uranium composition generally cannot be identified visually.

**ArmorLab visual guidance:** Use a separate long-rod body and fin set, and a separate sabot when modelling the launch package. Do not hard-code impact results from the label or material name.

**Caveats:** The designation covers many generations and national forms; projectile-only, complete-round and cutaway pictures should not be mixed as if they show the same assembly. Catalogue note: Widely documented German kinetic-energy round family. Listed platform/compatibility: 120 mm smoothbore NATO MBTs. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://en.wikipedia.org/wiki/DM33); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22DM33+APFSDS%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22DM33+APFSDS%22+ammunition+photo+cutaway).

### R038 — DM43 APFSDS

**Family:** Armour-piercing fin-stabilised discarding sabot (APFSDS)  
**Exterior appearance:** DM43 APFSDS is catalogued here as APFSDS. In a complete tank cartridge the visible shape is a tall cylindrical cartridge body with a relatively narrow, pointed projectile package at the front; the penetrator itself is a long slender dart with small stabilising fins at the rear and is carried in a larger sabot during launch. A projectile-only display can look almost spear-like, while a complete cartridge can look like a full-bore shell/case.

**What a cutaway may show:** A cutaway or exploded drawing can show the long penetrator, fin assembly, segmented sabot and the cartridge/case arrangement. Western one-piece tank cartridges and two-piece-loading systems do not display the same outer form.

**Recognition cues:** Long, slender penetrator and rear fins are the principal cues. The penetrator’s tungsten or depleted-uranium composition generally cannot be identified visually.

**ArmorLab visual guidance:** Use a separate long-rod body and fin set, and a separate sabot when modelling the launch package. Do not hard-code impact results from the label or material name.

**Caveats:** The designation covers many generations and national forms; projectile-only, complete-round and cutaway pictures should not be mixed as if they show the same assembly. Catalogue note: Joint/related European round designation in public sources; verify national mark. Listed platform/compatibility: 120 mm NATO tank guns. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://en.wikipedia.org/wiki/Armour-piercing_fin-stabilized_discarding_sabot); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22DM43+APFSDS%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22DM43+APFSDS%22+ammunition+photo+cutaway).

### R039 — DM53 APFSDS

**Family:** Armour-piercing fin-stabilised discarding sabot (APFSDS)  
**Exterior appearance:** DM53 APFSDS is catalogued here as APFSDS. In a complete tank cartridge the visible shape is a tall cylindrical cartridge body with a relatively narrow, pointed projectile package at the front; the penetrator itself is a long slender dart with small stabilising fins at the rear and is carried in a larger sabot during launch. A projectile-only display can look almost spear-like, while a complete cartridge can look like a full-bore shell/case.

**What a cutaway may show:** A cutaway or exploded drawing can show the long penetrator, fin assembly, segmented sabot and the cartridge/case arrangement. Western one-piece tank cartridges and two-piece-loading systems do not display the same outer form.

**Recognition cues:** Long, slender penetrator and rear fins are the principal cues. The penetrator’s tungsten or depleted-uranium composition generally cannot be identified visually.

**ArmorLab visual guidance:** Use a separate long-rod body and fin set, and a separate sabot when modelling the launch package. Do not hard-code impact results from the label or material name.

**Caveats:** The designation covers many generations and national forms; projectile-only, complete-round and cutaway pictures should not be mixed as if they show the same assembly. Catalogue note: Public sources identify a modern German kinetic-energy round; no penetration values included. The penetrator metal/alloy cannot be positively identified from ordinary exterior colour or shape. Avoid rendering material-specific colour as if it were a reliable visual property; record composition only where a traceable source confirms it. Listed platform/compatibility: 120 mm Leopard 2 family. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://en.wikipedia.org/wiki/DM53); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22DM53+APFSDS%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22DM53+APFSDS%22+ammunition+photo+cutaway).

### R040 — DM63 APFSDS

**Family:** Armour-piercing fin-stabilised discarding sabot (APFSDS)  
**Exterior appearance:** DM63 APFSDS is catalogued here as APFSDS. In a complete tank cartridge the visible shape is a tall cylindrical cartridge body with a relatively narrow, pointed projectile package at the front; the penetrator itself is a long slender dart with small stabilising fins at the rear and is carried in a larger sabot during launch. A projectile-only display can look almost spear-like, while a complete cartridge can look like a full-bore shell/case.

**What a cutaway may show:** A cutaway or exploded drawing can show the long penetrator, fin assembly, segmented sabot and the cartridge/case arrangement. Western one-piece tank cartridges and two-piece-loading systems do not display the same outer form.

**Recognition cues:** Long, slender penetrator and rear fins are the principal cues. The penetrator’s tungsten or depleted-uranium composition generally cannot be identified visually.

**ArmorLab visual guidance:** Use a separate long-rod body and fin set, and a separate sabot when modelling the launch package. Do not hard-code impact results from the label or material name.

**Caveats:** The designation covers many generations and national forms; projectile-only, complete-round and cutaway pictures should not be mixed as if they show the same assembly. Catalogue note: Temperature-insensitive propellant family publicly documented by industry and open references. For a Western 120 mm example, distinguish the complete cartridge from the projectile-only training/display object. Some designs use a combustible case with a metal base; a photograph can show a large pale/neutral casing and a separate forward projectile profile. Do not assume one universal case colour. The penetrator metal/alloy cannot be positively identified from ordinary exterior colour or shape. Avoid rendering material-specific colour as if it were a reliable visual property; record composition only where a traceable source confirms it. Listed platform/compatibility: 120 mm Leopard 2 family. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://www.rheinmetall.com/en/products/weapon-ammunition); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22DM63+APFSDS%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22DM63+APFSDS%22+ammunition+photo+cutaway).

### R041 — DM73 APFSDS

**Family:** Armour-piercing fin-stabilised discarding sabot (APFSDS)  
**Exterior appearance:** DM73 APFSDS is catalogued here as APFSDS. In a complete tank cartridge the visible shape is a tall cylindrical cartridge body with a relatively narrow, pointed projectile package at the front; the penetrator itself is a long slender dart with small stabilising fins at the rear and is carried in a larger sabot during launch. A projectile-only display can look almost spear-like, while a complete cartridge can look like a full-bore shell/case.

**What a cutaway may show:** A cutaway or exploded drawing can show the long penetrator, fin assembly, segmented sabot and the cartridge/case arrangement. Western one-piece tank cartridges and two-piece-loading systems do not display the same outer form.

**Recognition cues:** Long, slender penetrator and rear fins are the principal cues. The penetrator’s tungsten or depleted-uranium composition generally cannot be identified visually.

**ArmorLab visual guidance:** Use a separate long-rod body and fin set, and a separate sabot when modelling the launch package. Do not hard-code impact results from the label or material name.

**Caveats:** The designation covers many generations and national forms; projectile-only, complete-round and cutaway pictures should not be mixed as if they show the same assembly. Catalogue note: Modern round designation appears in public industry material; exact fleet compatibility varies. For a Western 120 mm example, distinguish the complete cartridge from the projectile-only training/display object. Some designs use a combustible case with a metal base; a photograph can show a large pale/neutral casing and a separate forward projectile profile. Do not assume one universal case colour. The penetrator metal/alloy cannot be positively identified from ordinary exterior colour or shape. Avoid rendering material-specific colour as if it were a reliable visual property; record composition only where a traceable source confirms it. Listed platform/compatibility: 120 mm L55A1 family. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://www.rheinmetall.com/en/products/weapon-ammunition); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22DM73+APFSDS%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22DM73+APFSDS%22+ammunition+photo+cutaway).

### R042 — DM11 programmable HE

**Family:** Programmable multipurpose round  
**Exterior appearance:** DM11 programmable HE is catalogued here as Programmable multi-purpose HE. Usually retains the overall form of a conventional gun cartridge or projectile. Depending on the system, the nose may have a fuze/sensor housing, visible bands or a data/setting interface, but much of the programmable function is electronic and invisible externally.

**What a cutaway may show:** Official product cutaways and programme descriptions are the best way to see fuze electronics, mode-setting hardware and internal payload layout. Do not add a fantasy antenna or exposed electronics merely to signify “smart”.

**Recognition cues:** Programmability is a functional property. A plain-looking cartridge may be programmable; visible markings alone may not identify the available firing modes.

**ArmorLab visual guidance:** Base the external mesh on the exact named cartridge. Store programmed mode as simulation metadata rather than changing the exterior model without evidence.

**Caveats:** Different systems programme by muzzle interface, inductive setting, fuze interface or other methods; there is no universal visual cue. Catalogue note: Programmable multi-role round family; not a dedicated kinetic penetrator. For a Western 120 mm example, distinguish the complete cartridge from the projectile-only training/display object. Some designs use a combustible case with a metal base; a photograph can show a large pale/neutral casing and a separate forward projectile profile. Do not assume one universal case colour. Listed platform/compatibility: 120 mm smoothbore gun family. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://www.rheinmetall.com/en/products/weapon-ammunition); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22DM11+programmable+HE%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22DM11+programmable+HE%22+ammunition+photo+cutaway).

### R043 — OFL 105 F1

**Family:** APFSDS with tracer (APFSDS-T)  
**Exterior appearance:** OFL 105 F1 is catalogued here as APFSDS-T. The overall silhouette is the APFSDS family: a complete large-calibre cartridge with a narrow forward projectile package, while the actual penetrator is a long slender fin-stabilised rod with a discardable sabot. The tracer is typically a rear/base feature and may not be visible in a standard exterior photo.

**What a cutaway may show:** The projectile/round cutaway may show the tracer element at the rear/base region in addition to the fins, sabot and cartridge assembly. It is not a visible luminous trail when the ammunition is stored or photographed.

**Recognition cues:** Treat the “T” as a tracer-related designation, not a different nose shape. Tracer presence is usually confirmed from documentation/cutaway rather than the exterior alone.

**ArmorLab visual guidance:** Base the shape on the APFSDS parent design; add a tracer component only when supported by an illustrated technical reference.

**Caveats:** Tracer arrangements differ by round and should not be assumed identical across all APFSDS-T designations. Catalogue note: French 105 mm kinetic-energy round family; exact penetrator material by mark should be checked. Listed platform/compatibility: French 105 mm gun family. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://en.wikipedia.org/wiki/Armour-piercing_fin-stabilized_discarding_sabot); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22OFL+105+F1%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22OFL+105+F1%22+ammunition+photo+cutaway).

### R044 — OFL 120 F1

**Family:** Armour-piercing fin-stabilised discarding sabot (APFSDS)  
**Exterior appearance:** OFL 120 F1 is catalogued here as APFSDS. In a complete tank cartridge the visible shape is a tall cylindrical cartridge body with a relatively narrow, pointed projectile package at the front; the penetrator itself is a long slender dart with small stabilising fins at the rear and is carried in a larger sabot during launch. A projectile-only display can look almost spear-like, while a complete cartridge can look like a full-bore shell/case.

**What a cutaway may show:** A cutaway or exploded drawing can show the long penetrator, fin assembly, segmented sabot and the cartridge/case arrangement. Western one-piece tank cartridges and two-piece-loading systems do not display the same outer form.

**Recognition cues:** Long, slender penetrator and rear fins are the principal cues. The penetrator’s tungsten or depleted-uranium composition generally cannot be identified visually.

**ArmorLab visual guidance:** Use a separate long-rod body and fin set, and a separate sabot when modelling the launch package. Do not hard-code impact results from the label or material name.

**Caveats:** The designation covers many generations and national forms; projectile-only, complete-round and cutaway pictures should not be mixed as if they show the same assembly. Catalogue note: French 120 mm kinetic-energy round family. Listed platform/compatibility: Leclerc 120 mm gun family. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://en.wikipedia.org/wiki/Leclerc); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22OFL+120+F1%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22OFL+120+F1%22+ammunition+photo+cutaway).

### R045 — OFL 120 F2

**Family:** Armour-piercing fin-stabilised discarding sabot (APFSDS)  
**Exterior appearance:** OFL 120 F2 is catalogued here as APFSDS. In a complete tank cartridge the visible shape is a tall cylindrical cartridge body with a relatively narrow, pointed projectile package at the front; the penetrator itself is a long slender dart with small stabilising fins at the rear and is carried in a larger sabot during launch. A projectile-only display can look almost spear-like, while a complete cartridge can look like a full-bore shell/case.

**What a cutaway may show:** A cutaway or exploded drawing can show the long penetrator, fin assembly, segmented sabot and the cartridge/case arrangement. Western one-piece tank cartridges and two-piece-loading systems do not display the same outer form.

**Recognition cues:** Long, slender penetrator and rear fins are the principal cues. The penetrator’s tungsten or depleted-uranium composition generally cannot be identified visually.

**ArmorLab visual guidance:** Use a separate long-rod body and fin set, and a separate sabot when modelling the launch package. Do not hard-code impact results from the label or material name.

**Caveats:** The designation covers many generations and national forms; projectile-only, complete-round and cutaway pictures should not be mixed as if they show the same assembly. Catalogue note: Public designation; national variant details are not fully enumerated here. Listed platform/compatibility: French 120 mm smoothbore guns. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://en.wikipedia.org/wiki/Armour-piercing_fin-stabilized_discarding_sabot); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22OFL+120+F2%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22OFL+120+F2%22+ammunition+photo+cutaway).

### R046 — SHARD 120 mm

**Family:** Armour-piercing fin-stabilised discarding sabot (APFSDS)  
**Exterior appearance:** SHARD 120 mm is catalogued here as APFSDS. In a complete tank cartridge the visible shape is a tall cylindrical cartridge body with a relatively narrow, pointed projectile package at the front; the penetrator itself is a long slender dart with small stabilising fins at the rear and is carried in a larger sabot during launch. A projectile-only display can look almost spear-like, while a complete cartridge can look like a full-bore shell/case.

**What a cutaway may show:** A cutaway or exploded drawing can show the long penetrator, fin assembly, segmented sabot and the cartridge/case arrangement. Western one-piece tank cartridges and two-piece-loading systems do not display the same outer form.

**Recognition cues:** Long, slender penetrator and rear fins are the principal cues. The penetrator’s tungsten or depleted-uranium composition generally cannot be identified visually.

**ArmorLab visual guidance:** Use a separate long-rod body and fin set, and a separate sabot when modelling the launch package. Do not hard-code impact results from the label or material name.

**Caveats:** The designation covers many generations and national forms; projectile-only, complete-round and cutaway pictures should not be mixed as if they show the same assembly. Catalogue note: Manufacturer lists tungsten-alloy projectile material; exact test comparators are not model parameters. Listed platform/compatibility: Leclerc and Leopard 2 qualified, per KNDS. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://knds.com/en/products/ammunition/120-mm); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22SHARD+120+mm%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22SHARD+120+mm%22+ammunition+photo+cutaway).

### R047 — 120 mm HE F1

**Family:** High explosive (HE)  
**Exterior appearance:** 120 mm HE F1 is catalogued here as HE. Usually a conventional shell body with rounded/ogival nose, cylindrical midsection and a fuze at the nose or base. The wall/body may be thick and robust; external form varies with calibre and whether the cartridge is complete, separate-loaded or a projectile on its own.

**What a cutaway may show:** A section typically reveals an explosive cavity and fuze arrangement. Some modern HE rounds have multiple-mode/programming components; that is not visible on every exterior model.

**Recognition cues:** A nose fuze is common but not universal. HE external silhouette alone is not sufficient to identify the filler or exact effect.

**ArmorLab visual guidance:** Start with a documented shell profile and distinguish projectile from complete cartridge. Use generic internal fill only in clearly labelled educational cutaway mode.

**Caveats:** “HE” describes the broad role, not a single shell shape or fuze configuration. Catalogue note: Manufacturer lists as part of its 120 mm family. Listed platform/compatibility: NATO 120 mm smoothbore MBTs. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://knds.com/en/products/ammunition/120-mm); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22120+mm+HE+F1%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22120+mm+HE+F1%22+ammunition+photo+cutaway).

### R048 — 120 mm CAN

**Family:** Canister / area-effect tank round  
**Exterior appearance:** 120 mm CAN is catalogued here as Canister. The complete tank cartridge typically looks like a conventional cylindrical cartridge, with a closed projectile canister at the front rather than the exposed needle-like penetrator of an APFSDS. The exterior may be almost plain, making its contents hard to infer from a photo.

**What a cutaway may show:** A cutaway typically shows a canister body packed with multiple small projectiles or other payload elements; a round such as the M1028 is often described by the analogy of a large shotgun-like payload.

**Recognition cues:** A canister round is not visually identified by a unique nose tip in every example; official product sheets and cutaways help confirm the type.

**ArmorLab visual guidance:** Use a closed cylindrical canister shell and do not add a long rod, shaped-charge cone or conventional HE cavity unless the named round supports it.

**Caveats:** Exact payload forms and fuzes vary; avoid presenting the generic analogy as a complete construction drawing. Catalogue note: Manufacturer lists a canister family; not an anti-armour penetrator. Listed platform/compatibility: NATO 120 mm smoothbore MBTs. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://backend.knds.com/uploads/catalogue_munitions_85ae594873.pdf); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22120+mm+CAN%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22120+mm+CAN%22+ammunition+photo+cutaway).

### R049 — 120 mm HEAT-TP F1A

**Family:** Training / drill / practice round  
**Exterior appearance:** 120 mm HEAT-TP F1A is catalogued here as Training HEAT-type. Training ammunition often mimics the tactical round’s overall profile but may have a solid inert nose, different mass-distribution features, tracking/tracer hardware or conspicuous identification colours. It can also be a dummy/drill cartridge with no live functional payload. Color conventions are specific to the service, date and item.

**What a cutaway may show:** A cutaway shows how the trainer omits or replaces tactical components; however “practice” can still mean several different constructions, including target-practice projectiles that approximate external ballistics.

**Recognition cues:** Look for a designation and official colour/marking standard. Never use one generic blue/black/orange texture rule for all countries and periods.

**ArmorLab visual guidance:** Treat `training_status`, `inert_status`, and `ballistic_similarity` as separate metadata. Build the exact visual profile of the named trainer and do not give it tactical material/fuze behaviour by default.

**Caveats:** Training, drill, target-practice, TPFSDS, TPMP and inert are not exact synonyms. Catalogue note: Inert training round described in manufacturer catalogue. Training colour and marking rules are nation-, era- and designation-specific. Do not rely on a generic blue/black/orange material to identify every practice or inert round; use the documented item caption. Listed platform/compatibility: NATO smoothbore MBTs. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://backend.knds.com/uploads/catalogue_munitions_85ae594873.pdf); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22120+mm+HEAT-TP+F1A%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22120+mm+HEAT-TP+F1A%22+ammunition+photo+cutaway).

### R050 — 3BM15

**Family:** Armour-piercing fin-stabilised discarding sabot (APFSDS)  
**Exterior appearance:** 3BM15 is catalogued here as APFSDS. In a complete tank cartridge the visible shape is a tall cylindrical cartridge body with a relatively narrow, pointed projectile package at the front; the penetrator itself is a long slender dart with small stabilising fins at the rear and is carried in a larger sabot during launch. A projectile-only display can look almost spear-like, while a complete cartridge can look like a full-bore shell/case.

**What a cutaway may show:** A cutaway or exploded drawing can show the long penetrator, fin assembly, segmented sabot and the cartridge/case arrangement. Western one-piece tank cartridges and two-piece-loading systems do not display the same outer form.

**Recognition cues:** Long, slender penetrator and rear fins are the principal cues. The penetrator’s tungsten or depleted-uranium composition generally cannot be identified visually.

**ArmorLab visual guidance:** Use a separate long-rod body and fin set, and a separate sabot when modelling the launch package. Do not hard-code impact results from the label or material name.

**Caveats:** The designation covers many generations and national forms; projectile-only, complete-round and cutaway pictures should not be mixed as if they show the same assembly. Catalogue note: Soviet kinetic-energy designation family; details can vary by source. For these Soviet/Russian/Chinese 125 mm-family entries, the catalogue designation may refer to the projectile/shot rather than a Western-style single-piece cartridge. Many 125 mm systems use separate-loading components; a photo may show the projectile by itself or a distinct propellant charge. Do not automatically give it a Western one-piece brass case. Listed platform/compatibility: 125 mm Soviet tank gun family. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://en.wikipedia.org/wiki/125_mm_smoothbore_ammunition); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%223BM15%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%223BM15%22+ammunition+photo+cutaway).

### R051 — 3BM22

**Family:** Armour-piercing fin-stabilised discarding sabot (APFSDS)  
**Exterior appearance:** 3BM22 is catalogued here as APFSDS. In a complete tank cartridge the visible shape is a tall cylindrical cartridge body with a relatively narrow, pointed projectile package at the front; the penetrator itself is a long slender dart with small stabilising fins at the rear and is carried in a larger sabot during launch. A projectile-only display can look almost spear-like, while a complete cartridge can look like a full-bore shell/case.

**What a cutaway may show:** A cutaway or exploded drawing can show the long penetrator, fin assembly, segmented sabot and the cartridge/case arrangement. Western one-piece tank cartridges and two-piece-loading systems do not display the same outer form.

**Recognition cues:** Long, slender penetrator and rear fins are the principal cues. The penetrator’s tungsten or depleted-uranium composition generally cannot be identified visually.

**ArmorLab visual guidance:** Use a separate long-rod body and fin set, and a separate sabot when modelling the launch package. Do not hard-code impact results from the label or material name.

**Caveats:** The designation covers many generations and national forms; projectile-only, complete-round and cutaway pictures should not be mixed as if they show the same assembly. Catalogue note: Soviet kinetic-energy round designation. For these Soviet/Russian/Chinese 125 mm-family entries, the catalogue designation may refer to the projectile/shot rather than a Western-style single-piece cartridge. Many 125 mm systems use separate-loading components; a photo may show the projectile by itself or a distinct propellant charge. Do not automatically give it a Western one-piece brass case. Listed platform/compatibility: 125 mm Soviet tank gun family. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://en.wikipedia.org/wiki/125_mm_smoothbore_ammunition); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%223BM22%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%223BM22%22+ammunition+photo+cutaway).

### R052 — 3BM26

**Family:** Armour-piercing fin-stabilised discarding sabot (APFSDS)  
**Exterior appearance:** 3BM26 is catalogued here as APFSDS. In a complete tank cartridge the visible shape is a tall cylindrical cartridge body with a relatively narrow, pointed projectile package at the front; the penetrator itself is a long slender dart with small stabilising fins at the rear and is carried in a larger sabot during launch. A projectile-only display can look almost spear-like, while a complete cartridge can look like a full-bore shell/case.

**What a cutaway may show:** A cutaway or exploded drawing can show the long penetrator, fin assembly, segmented sabot and the cartridge/case arrangement. Western one-piece tank cartridges and two-piece-loading systems do not display the same outer form.

**Recognition cues:** Long, slender penetrator and rear fins are the principal cues. The penetrator’s tungsten or depleted-uranium composition generally cannot be identified visually.

**ArmorLab visual guidance:** Use a separate long-rod body and fin set, and a separate sabot when modelling the launch package. Do not hard-code impact results from the label or material name.

**Caveats:** The designation covers many generations and national forms; projectile-only, complete-round and cutaway pictures should not be mixed as if they show the same assembly. Catalogue note: Soviet kinetic-energy round designation. For these Soviet/Russian/Chinese 125 mm-family entries, the catalogue designation may refer to the projectile/shot rather than a Western-style single-piece cartridge. Many 125 mm systems use separate-loading components; a photo may show the projectile by itself or a distinct propellant charge. Do not automatically give it a Western one-piece brass case. Listed platform/compatibility: 125 mm Soviet tank gun family. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://en.wikipedia.org/wiki/125_mm_smoothbore_ammunition); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%223BM26%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%223BM26%22+ammunition+photo+cutaway).

### R053 — 3BM29 Nadezhda

**Family:** Armour-piercing fin-stabilised discarding sabot (APFSDS)  
**Exterior appearance:** 3BM29 Nadezhda is catalogued here as APFSDS. In a complete tank cartridge the visible shape is a tall cylindrical cartridge body with a relatively narrow, pointed projectile package at the front; the penetrator itself is a long slender dart with small stabilising fins at the rear and is carried in a larger sabot during launch. A projectile-only display can look almost spear-like, while a complete cartridge can look like a full-bore shell/case.

**What a cutaway may show:** A cutaway or exploded drawing can show the long penetrator, fin assembly, segmented sabot and the cartridge/case arrangement. Western one-piece tank cartridges and two-piece-loading systems do not display the same outer form.

**Recognition cues:** Long, slender penetrator and rear fins are the principal cues. The penetrator’s tungsten or depleted-uranium composition generally cannot be identified visually.

**ArmorLab visual guidance:** Use a separate long-rod body and fin set, and a separate sabot when modelling the launch package. Do not hard-code impact results from the label or material name.

**Caveats:** The designation covers many generations and national forms; projectile-only, complete-round and cutaway pictures should not be mixed as if they show the same assembly. Catalogue note: Open sources associate this name with Soviet kinetic-energy ammunition; verify exact sub-variant before quantitative use. For these Soviet/Russian/Chinese 125 mm-family entries, the catalogue designation may refer to the projectile/shot rather than a Western-style single-piece cartridge. Many 125 mm systems use separate-loading components; a photo may show the projectile by itself or a distinct propellant charge. Do not automatically give it a Western one-piece brass case. Listed platform/compatibility: 125 mm Soviet tank gun family. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://en.wikipedia.org/wiki/125_mm_smoothbore_ammunition); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%223BM29+Nadezhda%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%223BM29+Nadezhda%22+ammunition+photo+cutaway).

### R054 — 3BM32 Vant

**Family:** Armour-piercing fin-stabilised discarding sabot (APFSDS)  
**Exterior appearance:** 3BM32 Vant is catalogued here as APFSDS. In a complete tank cartridge the visible shape is a tall cylindrical cartridge body with a relatively narrow, pointed projectile package at the front; the penetrator itself is a long slender dart with small stabilising fins at the rear and is carried in a larger sabot during launch. A projectile-only display can look almost spear-like, while a complete cartridge can look like a full-bore shell/case.

**What a cutaway may show:** A cutaway or exploded drawing can show the long penetrator, fin assembly, segmented sabot and the cartridge/case arrangement. Western one-piece tank cartridges and two-piece-loading systems do not display the same outer form.

**Recognition cues:** Long, slender penetrator and rear fins are the principal cues. The penetrator’s tungsten or depleted-uranium composition generally cannot be identified visually.

**ArmorLab visual guidance:** Use a separate long-rod body and fin set, and a separate sabot when modelling the launch package. Do not hard-code impact results from the label or material name.

**Caveats:** The designation covers many generations and national forms; projectile-only, complete-round and cutaway pictures should not be mixed as if they show the same assembly. Catalogue note: Open sources commonly identify as a uranium-alloy penetrator family; exact detail omitted. For these Soviet/Russian/Chinese 125 mm-family entries, the catalogue designation may refer to the projectile/shot rather than a Western-style single-piece cartridge. Many 125 mm systems use separate-loading components; a photo may show the projectile by itself or a distinct propellant charge. Do not automatically give it a Western one-piece brass case. The penetrator metal/alloy cannot be positively identified from ordinary exterior colour or shape. Avoid rendering material-specific colour as if it were a reliable visual property; record composition only where a traceable source confirms it. Listed platform/compatibility: 125 mm Soviet tank gun family. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://www.frontiersin.org/journals/political-science/articles/10.3389/fpos.2024.1387183/full); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%223BM32+Vant%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%223BM32+Vant%22+ammunition+photo+cutaway).

### R055 — 3BM42 Mango

**Family:** Armour-piercing fin-stabilised discarding sabot (APFSDS)  
**Exterior appearance:** 3BM42 Mango is catalogued here as APFSDS. In a complete tank cartridge the visible shape is a tall cylindrical cartridge body with a relatively narrow, pointed projectile package at the front; the penetrator itself is a long slender dart with small stabilising fins at the rear and is carried in a larger sabot during launch. A projectile-only display can look almost spear-like, while a complete cartridge can look like a full-bore shell/case.

**What a cutaway may show:** A cutaway or exploded drawing can show the long penetrator, fin assembly, segmented sabot and the cartridge/case arrangement. Western one-piece tank cartridges and two-piece-loading systems do not display the same outer form.

**Recognition cues:** Long, slender penetrator and rear fins are the principal cues. The penetrator’s tungsten or depleted-uranium composition generally cannot be identified visually.

**ArmorLab visual guidance:** Use a separate long-rod body and fin set, and a separate sabot when modelling the launch package. Do not hard-code impact results from the label or material name.

**Caveats:** The designation covers many generations and national forms; projectile-only, complete-round and cutaway pictures should not be mixed as if they show the same assembly. Catalogue note: Well-known Russian kinetic-energy round designation; no penetration claims included. For these Soviet/Russian/Chinese 125 mm-family entries, the catalogue designation may refer to the projectile/shot rather than a Western-style single-piece cartridge. Many 125 mm systems use separate-loading components; a photo may show the projectile by itself or a distinct propellant charge. Do not automatically give it a Western one-piece brass case. Listed platform/compatibility: 125 mm Soviet/Russian tank gun family. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://en.wikipedia.org/wiki/125_mm_smoothbore_ammunition); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%223BM42+Mango%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%223BM42+Mango%22+ammunition+photo+cutaway).

### R056 — 3BM46 Svinets-1

**Family:** Armour-piercing fin-stabilised discarding sabot (APFSDS)  
**Exterior appearance:** 3BM46 Svinets-1 is catalogued here as APFSDS. In a complete tank cartridge the visible shape is a tall cylindrical cartridge body with a relatively narrow, pointed projectile package at the front; the penetrator itself is a long slender dart with small stabilising fins at the rear and is carried in a larger sabot during launch. A projectile-only display can look almost spear-like, while a complete cartridge can look like a full-bore shell/case.

**What a cutaway may show:** A cutaway or exploded drawing can show the long penetrator, fin assembly, segmented sabot and the cartridge/case arrangement. Western one-piece tank cartridges and two-piece-loading systems do not display the same outer form.

**Recognition cues:** Long, slender penetrator and rear fins are the principal cues. The penetrator’s tungsten or depleted-uranium composition generally cannot be identified visually.

**ArmorLab visual guidance:** Use a separate long-rod body and fin set, and a separate sabot when modelling the launch package. Do not hard-code impact results from the label or material name.

**Caveats:** The designation covers many generations and national forms; projectile-only, complete-round and cutaway pictures should not be mixed as if they show the same assembly. Catalogue note: Name/designation used in public references; variants and material descriptions differ among sources. For these Soviet/Russian/Chinese 125 mm-family entries, the catalogue designation may refer to the projectile/shot rather than a Western-style single-piece cartridge. Many 125 mm systems use separate-loading components; a photo may show the projectile by itself or a distinct propellant charge. Do not automatically give it a Western one-piece brass case. The penetrator metal/alloy cannot be positively identified from ordinary exterior colour or shape. Avoid rendering material-specific colour as if it were a reliable visual property; record composition only where a traceable source confirms it. Listed platform/compatibility: 125 mm tank gun family. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://www.frontiersin.org/journals/political-science/articles/10.3389/fpos.2024.1387183/full); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%223BM46+Svinets-1%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%223BM46+Svinets-1%22+ammunition+photo+cutaway).

### R057 — 3BM59 Svinets-2

**Family:** Armour-piercing fin-stabilised discarding sabot (APFSDS)  
**Exterior appearance:** 3BM59 Svinets-2 is catalogued here as APFSDS. In a complete tank cartridge the visible shape is a tall cylindrical cartridge body with a relatively narrow, pointed projectile package at the front; the penetrator itself is a long slender dart with small stabilising fins at the rear and is carried in a larger sabot during launch. A projectile-only display can look almost spear-like, while a complete cartridge can look like a full-bore shell/case.

**What a cutaway may show:** A cutaway or exploded drawing can show the long penetrator, fin assembly, segmented sabot and the cartridge/case arrangement. Western one-piece tank cartridges and two-piece-loading systems do not display the same outer form.

**Recognition cues:** Long, slender penetrator and rear fins are the principal cues. The penetrator’s tungsten or depleted-uranium composition generally cannot be identified visually.

**ArmorLab visual guidance:** Use a separate long-rod body and fin set, and a separate sabot when modelling the launch package. Do not hard-code impact results from the label or material name.

**Caveats:** The designation covers many generations and national forms; projectile-only, complete-round and cutaway pictures should not be mixed as if they show the same assembly. Catalogue note: Modern Russian round family; exact construction/issue details are not fully public. For these Soviet/Russian/Chinese 125 mm-family entries, the catalogue designation may refer to the projectile/shot rather than a Western-style single-piece cartridge. Many 125 mm systems use separate-loading components; a photo may show the projectile by itself or a distinct propellant charge. Do not automatically give it a Western one-piece brass case. The penetrator metal/alloy cannot be positively identified from ordinary exterior colour or shape. Avoid rendering material-specific colour as if it were a reliable visual property; record composition only where a traceable source confirms it. Listed platform/compatibility: 125 mm tank gun family. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://www.frontiersin.org/journals/political-science/articles/10.3389/fpos.2024.1387183/full); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%223BM59+Svinets-2%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%223BM59+Svinets-2%22+ammunition+photo+cutaway).

### R058 — 3BM60 Svinets-2 (designation usage varies by source)

**Family:** Armour-piercing fin-stabilised discarding sabot (APFSDS)  
**Exterior appearance:** 3BM60 Svinets-2 (designation usage varies by source) is catalogued here as APFSDS. In a complete tank cartridge the visible shape is a tall cylindrical cartridge body with a relatively narrow, pointed projectile package at the front; the penetrator itself is a long slender dart with small stabilising fins at the rear and is carried in a larger sabot during launch. A projectile-only display can look almost spear-like, while a complete cartridge can look like a full-bore shell/case.

**What a cutaway may show:** A cutaway or exploded drawing can show the long penetrator, fin assembly, segmented sabot and the cartridge/case arrangement. Western one-piece tank cartridges and two-piece-loading systems do not display the same outer form.

**Recognition cues:** Long, slender penetrator and rear fins are the principal cues. The penetrator’s tungsten or depleted-uranium composition generally cannot be identified visually.

**ArmorLab visual guidance:** Use a separate long-rod body and fin set, and a separate sabot when modelling the launch package. Do not hard-code impact results from the label or material name.

**Caveats:** The designation covers many generations and national forms; projectile-only, complete-round and cutaway pictures should not be mixed as if they show the same assembly. Catalogue note: Secondary literature sometimes differs on the numbering/name mapping; verify before using precise parameters. For these Soviet/Russian/Chinese 125 mm-family entries, the catalogue designation may refer to the projectile/shot rather than a Western-style single-piece cartridge. Many 125 mm systems use separate-loading components; a photo may show the projectile by itself or a distinct propellant charge. Do not automatically give it a Western one-piece brass case. The penetrator metal/alloy cannot be positively identified from ordinary exterior colour or shape. Avoid rendering material-specific colour as if it were a reliable visual property; record composition only where a traceable source confirms it. Listed platform/compatibility: 125 mm tank gun family. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://en.wikipedia.org/wiki/125_mm_smoothbore_ammunition); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%223BM60+Svinets-2+%28designation+usage+varies+by+source%29%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%223BM60+Svinets-2+%28designation+usage+varies+by+source%29%22+ammunition+photo+cutaway).

### R059 — 3BK14M shaped-charge round

**Family:** High-explosive anti-tank (HEAT)  
**Exterior appearance:** 3BK14M shaped-charge round is catalogued here as HEAT. A conventional HEAT projectile usually has a cylindrical metal body with a rounded or ogival nose region and a fuze at or near the front; rocket or recoilless versions may be a large warhead mounted ahead of a narrower motor/fin section. From the outside it can resemble an ordinary shell or rocket, so the shaped-charge effect is not obvious.

**What a cutaway may show:** A sectioned specimen typically reveals a hollow conical/cup-shaped liner within the warhead, with explosive surrounding it and a fuze arrangement. A visible cone in a cutaway is a key recognition feature, but exact geometry is model-specific.

**Recognition cues:** The external body does not have to be sharply pointed. Nose probes, fuze caps, finned tails and paint differ by system/era.

**ArmorLab visual guidance:** For the visual library, show a plausible external casing plus an optional clearly labelled cutaway illustration; do not draw the internal liner on the exterior or treat the warhead as a kinetic long rod.

**Caveats:** A HEAT label says something about the effect mechanism, not one universal external shape. Catalogue note: Representative Soviet/Russian shaped-charge round designation. For these Soviet/Russian/Chinese 125 mm-family entries, the catalogue designation may refer to the projectile/shot rather than a Western-style single-piece cartridge. Many 125 mm systems use separate-loading components; a photo may show the projectile by itself or a distinct propellant charge. Do not automatically give it a Western one-piece brass case. Listed platform/compatibility: 125 mm Soviet tank gun family. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://en.wikipedia.org/wiki/125_mm_smoothbore_ammunition); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%223BK14M+shaped-charge+round%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%223BK14M+shaped-charge+round%22+ammunition+photo+cutaway).

### R060 — 3BK18M shaped-charge round

**Family:** High-explosive anti-tank (HEAT)  
**Exterior appearance:** 3BK18M shaped-charge round is catalogued here as HEAT. A conventional HEAT projectile usually has a cylindrical metal body with a rounded or ogival nose region and a fuze at or near the front; rocket or recoilless versions may be a large warhead mounted ahead of a narrower motor/fin section. From the outside it can resemble an ordinary shell or rocket, so the shaped-charge effect is not obvious.

**What a cutaway may show:** A sectioned specimen typically reveals a hollow conical/cup-shaped liner within the warhead, with explosive surrounding it and a fuze arrangement. A visible cone in a cutaway is a key recognition feature, but exact geometry is model-specific.

**Recognition cues:** The external body does not have to be sharply pointed. Nose probes, fuze caps, finned tails and paint differ by system/era.

**ArmorLab visual guidance:** For the visual library, show a plausible external casing plus an optional clearly labelled cutaway illustration; do not draw the internal liner on the exterior or treat the warhead as a kinetic long rod.

**Caveats:** A HEAT label says something about the effect mechanism, not one universal external shape. Catalogue note: Representative shaped-charge ammunition family. For these Soviet/Russian/Chinese 125 mm-family entries, the catalogue designation may refer to the projectile/shot rather than a Western-style single-piece cartridge. Many 125 mm systems use separate-loading components; a photo may show the projectile by itself or a distinct propellant charge. Do not automatically give it a Western one-piece brass case. Listed platform/compatibility: 125 mm Soviet tank gun family. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://en.wikipedia.org/wiki/125_mm_smoothbore_ammunition); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%223BK18M+shaped-charge+round%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%223BK18M+shaped-charge+round%22+ammunition+photo+cutaway).

### R061 — 3BK21B shaped-charge round

**Family:** High-explosive anti-tank (HEAT)  
**Exterior appearance:** 3BK21B shaped-charge round is catalogued here as HEAT. A conventional HEAT projectile usually has a cylindrical metal body with a rounded or ogival nose region and a fuze at or near the front; rocket or recoilless versions may be a large warhead mounted ahead of a narrower motor/fin section. From the outside it can resemble an ordinary shell or rocket, so the shaped-charge effect is not obvious.

**What a cutaway may show:** A sectioned specimen typically reveals a hollow conical/cup-shaped liner within the warhead, with explosive surrounding it and a fuze arrangement. A visible cone in a cutaway is a key recognition feature, but exact geometry is model-specific.

**Recognition cues:** The external body does not have to be sharply pointed. Nose probes, fuze caps, finned tails and paint differ by system/era.

**ArmorLab visual guidance:** For the visual library, show a plausible external casing plus an optional clearly labelled cutaway illustration; do not draw the internal liner on the exterior or treat the warhead as a kinetic long rod.

**Caveats:** A HEAT label says something about the effect mechanism, not one universal external shape. Catalogue note: Designation appears in open literature; treat exact architecture as uncertain absent primary sources. For these Soviet/Russian/Chinese 125 mm-family entries, the catalogue designation may refer to the projectile/shot rather than a Western-style single-piece cartridge. Many 125 mm systems use separate-loading components; a photo may show the projectile by itself or a distinct propellant charge. Do not automatically give it a Western one-piece brass case. Listed platform/compatibility: 125 mm Soviet tank gun family. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://en.wikipedia.org/wiki/125_mm_smoothbore_ammunition); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%223BK21B+shaped-charge+round%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%223BK21B+shaped-charge+round%22+ammunition+photo+cutaway).

### R062 — 3OF26

**Family:** High-explosive fragmentation / HE-FRAG  
**Exterior appearance:** 3OF26 is catalogued here as HE-FRAG. Often similar to a conventional HE shell or missile warhead: a cylindrical metal body with a tapered nose/fuze. Fragmentation features can be internal and not visible from the outside; certain designs have external grooves, but many do not.

**What a cutaway may show:** A cross-section may show a thicker casing, preformed fragment elements or an internal fragmentation liner. Do not assume every HE-FRAG shell has visible square scoring or a separate fragmentation sleeve.

**Recognition cues:** The visible body can resemble general HE; designation and cutaway are needed to identify fragmentation construction.

**ArmorLab visual guidance:** Use realistic shell material and mass distribution in the appearance model; represent fragments as a post-event simulation only if the underlying solver actually computes them.

**Caveats:** HEI includes incendiary-related effects in some classes; don’t merge every HEI and HE-FRAG construction into one exact model. Catalogue note: High-explosive fragmentation projectile for general-purpose use, not an AP round. For these Soviet/Russian/Chinese 125 mm-family entries, the catalogue designation may refer to the projectile/shot rather than a Western-style single-piece cartridge. Many 125 mm systems use separate-loading components; a photo may show the projectile by itself or a distinct propellant charge. Do not automatically give it a Western one-piece brass case. Listed platform/compatibility: 125 mm Soviet tank gun family. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://en.wikipedia.org/wiki/125_mm_smoothbore_ammunition); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%223OF26%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%223OF26%22+ammunition+photo+cutaway).

### R063 — 9M112 Kobra

**Family:** Gun-launched anti-tank guided missile  
**Exterior appearance:** 9M112 Kobra is catalogued here as Gun-launched ATGM. A gun-launched missile may share the tank gun’s cartridge envelope when loaded, while the missile itself is a slim cylindrical airframe with a nose section, body seams and deployable/fixed flight surfaces according to the model. In split-loading systems, the missile and propellant charge may be separate items.

**What a cutaway may show:** A cutaway can reveal a nose/seeker or fuze section, warhead section, propulsion section and control surfaces, but these are model-specific. Do not assume all gun-launched missiles use the same guidance or tail-fin design.

**Recognition cues:** It is a guided missile, not just an ordinary shell with a different tip. The visible object may be the missile, cartridge or complete loading unit.

**ArmorLab visual guidance:** Model missile and cartridge/launcher interfaces as separate objects when the system uses separate components. Add fins and sensor housings only from the named system reference.

**Caveats:** 9M112, 9M119-family and later missiles differ; grouped designations in the catalogue cover variants. Catalogue note: Guided missile fired from compatible tank gun systems. Listed platform/compatibility: Selected Soviet 125 mm tank guns. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://www.ausa.org/publications/ode-sagger-drill-addressing-modern-anti-tank-guided-missile-problem-set); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%229M112+Kobra%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%229M112+Kobra%22+ammunition+photo+cutaway).

### R064 — 9M119 Refleks / Svir family

**Family:** Gun-launched anti-tank guided missile  
**Exterior appearance:** 9M119 Refleks / Svir family is catalogued here as Gun-launched ATGM. A gun-launched missile may share the tank gun’s cartridge envelope when loaded, while the missile itself is a slim cylindrical airframe with a nose section, body seams and deployable/fixed flight surfaces according to the model. In split-loading systems, the missile and propellant charge may be separate items.

**What a cutaway may show:** A cutaway can reveal a nose/seeker or fuze section, warhead section, propulsion section and control surfaces, but these are model-specific. Do not assume all gun-launched missiles use the same guidance or tail-fin design.

**Recognition cues:** It is a guided missile, not just an ordinary shell with a different tip. The visible object may be the missile, cartridge or complete loading unit.

**ArmorLab visual guidance:** Model missile and cartridge/launcher interfaces as separate objects when the system uses separate components. Add fins and sensor housings only from the named system reference.

**Caveats:** 9M112, 9M119-family and later missiles differ; grouped designations in the catalogue cover variants. Catalogue note: Gun-launched guided missile family; exact launcher/variant compatibility differs. Listed platform/compatibility: Compatible 125 mm Soviet/Russian tank guns. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://www.ausa.org/publications/ode-sagger-drill-addressing-modern-anti-tank-guided-missile-problem-set); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%229M119+Refleks++Svir+family%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%229M119+Refleks++Svir+family%22+ammunition+photo+cutaway).

### R065 — 9M119M Invar

**Family:** Gun-launched anti-tank guided missile  
**Exterior appearance:** 9M119M Invar is catalogued here as Gun-launched ATGM. A gun-launched missile may share the tank gun’s cartridge envelope when loaded, while the missile itself is a slim cylindrical airframe with a nose section, body seams and deployable/fixed flight surfaces according to the model. In split-loading systems, the missile and propellant charge may be separate items.

**What a cutaway may show:** A cutaway can reveal a nose/seeker or fuze section, warhead section, propulsion section and control surfaces, but these are model-specific. Do not assume all gun-launched missiles use the same guidance or tail-fin design.

**Recognition cues:** It is a guided missile, not just an ordinary shell with a different tip. The visible object may be the missile, cartridge or complete loading unit.

**ArmorLab visual guidance:** Model missile and cartridge/launcher interfaces as separate objects when the system uses separate components. Add fins and sensor housings only from the named system reference.

**Caveats:** 9M112, 9M119-family and later missiles differ; grouped designations in the catalogue cover variants. Catalogue note: Publicly described missile family; do not use tank-shell physics unchanged. Listed platform/compatibility: Compatible Russian tank guns. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://www.ausa.org/publications/ode-sagger-drill-addressing-modern-anti-tank-guided-missile-problem-set); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%229M119M+Invar%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%229M119M+Invar%22+ammunition+photo+cutaway).

### R066 — JM33 APFSDS

**Family:** Armour-piercing fin-stabilised discarding sabot (APFSDS)  
**Exterior appearance:** JM33 APFSDS is catalogued here as APFSDS. In a complete tank cartridge the visible shape is a tall cylindrical cartridge body with a relatively narrow, pointed projectile package at the front; the penetrator itself is a long slender dart with small stabilising fins at the rear and is carried in a larger sabot during launch. A projectile-only display can look almost spear-like, while a complete cartridge can look like a full-bore shell/case.

**What a cutaway may show:** A cutaway or exploded drawing can show the long penetrator, fin assembly, segmented sabot and the cartridge/case arrangement. Western one-piece tank cartridges and two-piece-loading systems do not display the same outer form.

**Recognition cues:** Long, slender penetrator and rear fins are the principal cues. The penetrator’s tungsten or depleted-uranium composition generally cannot be identified visually.

**ArmorLab visual guidance:** Use a separate long-rod body and fin set, and a separate sabot when modelling the launch package. Do not hard-code impact results from the label or material name.

**Caveats:** The designation covers many generations and national forms; projectile-only, complete-round and cutaway pictures should not be mixed as if they show the same assembly. Catalogue note: Japanese round designation is referenced in open sources; verify exact user-specific configuration. Listed platform/compatibility: Type 90 / Japanese 120 mm family, public references. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://www.mod.go.jp/j/approach/hyouka/yosan_shikko/2018/04.pdf); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22JM33+APFSDS%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22JM33+APFSDS%22+ammunition+photo+cutaway).

### R067 — Type 10 APFSDS round

**Family:** Armour-piercing fin-stabilised discarding sabot (APFSDS)  
**Exterior appearance:** Type 10 APFSDS round is catalogued here as APFSDS. In a complete tank cartridge the visible shape is a tall cylindrical cartridge body with a relatively narrow, pointed projectile package at the front; the penetrator itself is a long slender dart with small stabilising fins at the rear and is carried in a larger sabot during launch. A projectile-only display can look almost spear-like, while a complete cartridge can look like a full-bore shell/case.

**What a cutaway may show:** A cutaway or exploded drawing can show the long penetrator, fin assembly, segmented sabot and the cartridge/case arrangement. Western one-piece tank cartridges and two-piece-loading systems do not display the same outer form.

**Recognition cues:** Long, slender penetrator and rear fins are the principal cues. The penetrator’s tungsten or depleted-uranium composition generally cannot be identified visually.

**ArmorLab visual guidance:** Use a separate long-rod body and fin set, and a separate sabot when modelling the launch package. Do not hard-code impact results from the label or material name.

**Caveats:** The designation covers many generations and national forms; projectile-only, complete-round and cutaway pictures should not be mixed as if they show the same assembly. Catalogue note: Japanese MOD public material lists this round for the Type 10. Listed platform/compatibility: Type 10 MBT 120 mm gun. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://www.mod.go.jp/j/approach/hyouka/yosan_shikko/2018/04.pdf); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22Type+10+APFSDS+round%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22Type+10+APFSDS+round%22+ammunition+photo+cutaway).

### R068 — JM12A1 HEAT-MP

**Family:** HEAT multipurpose / MPAT  
**Exterior appearance:** JM12A1 HEAT-MP is catalogued here as HEAT-MP. The outside generally resembles a conventional HEAT projectile: rounded or pointed nose, cylindrical body and a base/flight arrangement appropriate to the gun or launcher. Some multipurpose tank rounds have conspicuous nose fittings or sensor/fuze features, but there is no single shape shared by all MPAT designs.

**What a cutaway may show:** The internal view may show a shaped-charge warhead and additional fuze or sensor components. The exact presence of a proximity sensor, selectable mode or particular liner design must be checked against the named model’s datasheet.

**Recognition cues:** MP/MPAT signals multiple intended roles, not a unique external silhouette. A generic HEAT photo should not be labelled as a particular multipurpose round without evidence.

**ArmorLab visual guidance:** Represent the outer shell from the exact round photo; model programmable/proximity components only for variants with a source that documents them.

**Caveats:** HEAT-MP, MPAT and multipurpose HE are not synonyms for every manufacturer or calibre. Catalogue note: Japanese MOD publicly lists this ammunition class/designation. Listed platform/compatibility: Japanese tank-gun family. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://www.mod.go.jp/j/approach/hyouka/yosan_shikko/2018/04.pdf); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22JM12A1+HEAT-MP%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22JM12A1+HEAT-MP%22+ammunition+photo+cutaway).

### R069 — Type-00 training shell

**Family:** Training / drill / practice round  
**Exterior appearance:** Type-00 training shell is catalogued here as Training. Training ammunition often mimics the tactical round’s overall profile but may have a solid inert nose, different mass-distribution features, tracking/tracer hardware or conspicuous identification colours. It can also be a dummy/drill cartridge with no live functional payload. Color conventions are specific to the service, date and item.

**What a cutaway may show:** A cutaway shows how the trainer omits or replaces tactical components; however “practice” can still mean several different constructions, including target-practice projectiles that approximate external ballistics.

**Recognition cues:** Look for a designation and official colour/marking standard. Never use one generic blue/black/orange texture rule for all countries and periods.

**ArmorLab visual guidance:** Treat `training_status`, `inert_status`, and `ballistic_similarity` as separate metadata. Build the exact visual profile of the named trainer and do not give it tactical material/fuze behaviour by default.

**Caveats:** Training, drill, target-practice, TPFSDS, TPMP and inert are not exact synonyms. Catalogue note: Japanese MOD reference lists a Type-00 training shell; its training design should not be modelled as a live round. Training colour and marking rules are nation-, era- and designation-specific. Do not rely on a generic blue/black/orange material to identify every practice or inert round; use the documented item caption. Listed platform/compatibility: Japanese tank-gun family. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://www.mod.go.jp/j/approach/hyouka/yosan_shikko/2018/04.pdf); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22Type-00+training+shell%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22Type-00+training+shell%22+ammunition+photo+cutaway).

### R070 — M111 Hetz

**Family:** Armour-piercing fin-stabilised discarding sabot (APFSDS)  
**Exterior appearance:** M111 Hetz is catalogued here as APFSDS. In a complete tank cartridge the visible shape is a tall cylindrical cartridge body with a relatively narrow, pointed projectile package at the front; the penetrator itself is a long slender dart with small stabilising fins at the rear and is carried in a larger sabot during launch. A projectile-only display can look almost spear-like, while a complete cartridge can look like a full-bore shell/case.

**What a cutaway may show:** A cutaway or exploded drawing can show the long penetrator, fin assembly, segmented sabot and the cartridge/case arrangement. Western one-piece tank cartridges and two-piece-loading systems do not display the same outer form.

**Recognition cues:** Long, slender penetrator and rear fins are the principal cues. The penetrator’s tungsten or depleted-uranium composition generally cannot be identified visually.

**ArmorLab visual guidance:** Use a separate long-rod body and fin set, and a separate sabot when modelling the launch package. Do not hard-code impact results from the label or material name.

**Caveats:** The designation covers many generations and national forms; projectile-only, complete-round and cutaway pictures should not be mixed as if they show the same assembly. Catalogue note: Israeli kinetic-energy designation documented in open sources; specific details vary by mark. Listed platform/compatibility: Israeli 105 mm tank gun family. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://en.wikipedia.org/wiki/Armour-piercing_fin-stabilized_discarding_sabot); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22M111+Hetz%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22M111+Hetz%22+ammunition+photo+cutaway).

### R071 — M322 APFSDS

**Family:** Armour-piercing fin-stabilised discarding sabot (APFSDS)  
**Exterior appearance:** M322 APFSDS is catalogued here as APFSDS. In a complete tank cartridge the visible shape is a tall cylindrical cartridge body with a relatively narrow, pointed projectile package at the front; the penetrator itself is a long slender dart with small stabilising fins at the rear and is carried in a larger sabot during launch. A projectile-only display can look almost spear-like, while a complete cartridge can look like a full-bore shell/case.

**What a cutaway may show:** A cutaway or exploded drawing can show the long penetrator, fin assembly, segmented sabot and the cartridge/case arrangement. Western one-piece tank cartridges and two-piece-loading systems do not display the same outer form.

**Recognition cues:** Long, slender penetrator and rear fins are the principal cues. The penetrator’s tungsten or depleted-uranium composition generally cannot be identified visually.

**ArmorLab visual guidance:** Use a separate long-rod body and fin set, and a separate sabot when modelling the launch package. Do not hard-code impact results from the label or material name.

**Caveats:** The designation covers many generations and national forms; projectile-only, complete-round and cutaway pictures should not be mixed as if they show the same assembly. Catalogue note: Publicly associated with Israeli 120 mm tank ammunition; no penetration values included. Listed platform/compatibility: Israeli 120 mm tank gun family. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://en.wikipedia.org/wiki/Armour-piercing_fin-stabilized_discarding_sabot); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22M322+APFSDS%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22M322+APFSDS%22+ammunition+photo+cutaway).

### R072 — M339 HE-MP-T

**Family:** High explosive (HE)  
**Exterior appearance:** M339 HE-MP-T is catalogued here as Multi-purpose HE. Usually a conventional shell body with rounded/ogival nose, cylindrical midsection and a fuze at the nose or base. The wall/body may be thick and robust; external form varies with calibre and whether the cartridge is complete, separate-loaded or a projectile on its own.

**What a cutaway may show:** A section typically reveals an explosive cavity and fuze arrangement. Some modern HE rounds have multiple-mode/programming components; that is not visible on every exterior model.

**Recognition cues:** A nose fuze is common but not universal. HE external silhouette alone is not sufficient to identify the filler or exact effect.

**ArmorLab visual guidance:** Start with a documented shell profile and distinguish projectile from complete cartridge. Use generic internal fill only in clearly labelled educational cutaway mode.

**Caveats:** “HE” describes the broad role, not a single shell shape or fuze configuration. Catalogue note: Public sources identify as a multipurpose tank round; exact behaviour is specific to fuze/design. Listed platform/compatibility: Israeli 120 mm tank gun family. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://en.wikipedia.org/wiki/120_mm_caliber); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22M339+HE-MP-T%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22M339+HE-MP-T%22+ammunition+photo+cutaway).

### R073 — K279 APFSDS

**Family:** Armour-piercing fin-stabilised discarding sabot (APFSDS)  
**Exterior appearance:** K279 APFSDS is catalogued here as APFSDS. In a complete tank cartridge the visible shape is a tall cylindrical cartridge body with a relatively narrow, pointed projectile package at the front; the penetrator itself is a long slender dart with small stabilising fins at the rear and is carried in a larger sabot during launch. A projectile-only display can look almost spear-like, while a complete cartridge can look like a full-bore shell/case.

**What a cutaway may show:** A cutaway or exploded drawing can show the long penetrator, fin assembly, segmented sabot and the cartridge/case arrangement. Western one-piece tank cartridges and two-piece-loading systems do not display the same outer form.

**Recognition cues:** Long, slender penetrator and rear fins are the principal cues. The penetrator’s tungsten or depleted-uranium composition generally cannot be identified visually.

**ArmorLab visual guidance:** Use a separate long-rod body and fin set, and a separate sabot when modelling the launch package. Do not hard-code impact results from the label or material name.

**Caveats:** The designation covers many generations and national forms; projectile-only, complete-round and cutaway pictures should not be mixed as if they show the same assembly. Catalogue note: Open designation family; verify exact mark and platform before parameters. Listed platform/compatibility: Korean 120 mm tank gun family. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://en.wikipedia.org/wiki/Armour-piercing_fin-stabilized_discarding_sabot); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22K279+APFSDS%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22K279+APFSDS%22+ammunition+photo+cutaway).

### R074 — K280 HEAT-MP

**Family:** HEAT multipurpose / MPAT  
**Exterior appearance:** K280 HEAT-MP is catalogued here as HEAT-MP. The outside generally resembles a conventional HEAT projectile: rounded or pointed nose, cylindrical body and a base/flight arrangement appropriate to the gun or launcher. Some multipurpose tank rounds have conspicuous nose fittings or sensor/fuze features, but there is no single shape shared by all MPAT designs.

**What a cutaway may show:** The internal view may show a shaped-charge warhead and additional fuze or sensor components. The exact presence of a proximity sensor, selectable mode or particular liner design must be checked against the named model’s datasheet.

**Recognition cues:** MP/MPAT signals multiple intended roles, not a unique external silhouette. A generic HEAT photo should not be labelled as a particular multipurpose round without evidence.

**ArmorLab visual guidance:** Represent the outer shell from the exact round photo; model programmable/proximity components only for variants with a source that documents them.

**Caveats:** HEAT-MP, MPAT and multipurpose HE are not synonyms for every manufacturer or calibre. Catalogue note: Open-source designation family; exact official material details not independently verified here. Listed platform/compatibility: Korean 120 mm tank gun family. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://en.wikipedia.org/wiki/120_mm_caliber); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22K280+HEAT-MP%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22K280+HEAT-MP%22+ammunition+photo+cutaway).

### R075 — DTC10-125

**Family:** Armour-piercing fin-stabilised discarding sabot (APFSDS)  
**Exterior appearance:** DTC10-125 is catalogued here as APFSDS (reported). In a complete tank cartridge the visible shape is a tall cylindrical cartridge body with a relatively narrow, pointed projectile package at the front; the penetrator itself is a long slender dart with small stabilising fins at the rear and is carried in a larger sabot during launch. A projectile-only display can look almost spear-like, while a complete cartridge can look like a full-bore shell/case.

**What a cutaway may show:** A cutaway or exploded drawing can show the long penetrator, fin assembly, segmented sabot and the cartridge/case arrangement. Western one-piece tank cartridges and two-piece-loading systems do not display the same outer form.

**Recognition cues:** Long, slender penetrator and rear fins are the principal cues. The penetrator’s tungsten or depleted-uranium composition generally cannot be identified visually.

**ArmorLab visual guidance:** Use a separate long-rod body and fin set, and a separate sabot when modelling the launch package. Do not hard-code impact results from the label or material name.

**Caveats:** The designation covers many generations and national forms; projectile-only, complete-round and cutaway pictures should not be mixed as if they show the same assembly. Catalogue note: Designation appears in secondary open sources; primary official public technical data limited. For these Soviet/Russian/Chinese 125 mm-family entries, the catalogue designation may refer to the projectile/shot rather than a Western-style single-piece cartridge. Many 125 mm systems use separate-loading components; a photo may show the projectile by itself or a distinct propellant charge. Do not automatically give it a Western one-piece brass case. The source dataset itself flags designation/variant uncertainty. Treat this entry as a family/alias-level record until the exact mark is confirmed by a primary reference. Listed platform/compatibility: 125 mm tank gun family. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://en.wikipedia.org/wiki/125_mm_smoothbore_ammunition); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22DTC10-125%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22DTC10-125%22+ammunition+photo+cutaway).

### R076 — PG-7V

**Family:** Man-portable anti-armour rocket / recoilless projectile  
**Exterior appearance:** PG-7V is catalogued here as RPG-shaped charge. The projectile/rocket often consists of a large warhead section with rounded or ogival nose, a narrower cylindrical rear body and tail stabilisers/fins or an attached motor/boom. Some weapons are issued as a complete disposable launcher tube, so photos may show the entire launcher instead of a separable round.

**What a cutaway may show:** A cutaway can reveal a warhead section and motor/stabilisation parts; the exact arrangement differs across rocket, recoilless and rifle-grenade systems. An external tube must not be mistaken for the projectile itself.

**Recognition cues:** The relative size of the warhead and narrower tail is a broad visual clue, but there are important exceptions.

**ArmorLab visual guidance:** Create separate assets for projectile, launcher/launch tube, and any disposable container. Use the correct configuration for the specific named system.

**Caveats:** This category intentionally spans distinct launch methods; it should not be a single shared physical template. Catalogue note: Representative RPG-7 ammunition designation; broad family only. Photographs often show the launcher or complete launcher/projectile assembly. Keep launcher, launch tube and munition as separate asset types in your catalogue; an externally visible tube is not necessarily part of the projectile in flight. Listed platform/compatibility: RPG-7 family. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://en.wikipedia.org/wiki/RPG-7); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22PG-7V%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22PG-7V%22+ammunition+photo+cutaway).

### R077 — PG-7VL

**Family:** Man-portable anti-armour rocket / recoilless projectile  
**Exterior appearance:** PG-7VL is catalogued here as RPG-shaped charge. The projectile/rocket often consists of a large warhead section with rounded or ogival nose, a narrower cylindrical rear body and tail stabilisers/fins or an attached motor/boom. Some weapons are issued as a complete disposable launcher tube, so photos may show the entire launcher instead of a separable round.

**What a cutaway may show:** A cutaway can reveal a warhead section and motor/stabilisation parts; the exact arrangement differs across rocket, recoilless and rifle-grenade systems. An external tube must not be mistaken for the projectile itself.

**Recognition cues:** The relative size of the warhead and narrower tail is a broad visual clue, but there are important exceptions.

**ArmorLab visual guidance:** Create separate assets for projectile, launcher/launch tube, and any disposable container. Use the correct configuration for the specific named system.

**Caveats:** This category intentionally spans distinct launch methods; it should not be a single shared physical template. Catalogue note: Variant designation; exact defeat details omitted. Photographs often show the launcher or complete launcher/projectile assembly. Keep launcher, launch tube and munition as separate asset types in your catalogue; an externally visible tube is not necessarily part of the projectile in flight. Listed platform/compatibility: RPG-7 family. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://en.wikipedia.org/wiki/RPG-7); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22PG-7VL%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22PG-7VL%22+ammunition+photo+cutaway).

### R078 — PG-7VR

**Family:** Tandem HEAT  
**Exterior appearance:** PG-7VR is catalogued here as Tandem HEAT. A tandem-warhead missile or rocket may have a long nose section or probe ahead of the main warhead body, but other designs keep the forward section integrated into a smooth nose. The full item often reads visually as an elongated missile/rocket with a nose assembly, cylindrical body and rear flight surfaces.

**What a cutaway may show:** A cutaway identifies two axially arranged charge sections within a shared warhead assembly. The small forward section may be concealed externally; it should not be inferred from an ordinary side photograph.

**Recognition cues:** Tandem is an internal warhead arrangement, not a dependable external shape classification. Probes and noses vary by weapon.

**ArmorLab visual guidance:** Use an exact named-weapon external reference for the silhouette. In educational cutaways, label the forward and main sections schematically without inventing dimensions.

**Caveats:** Not all tandem systems look alike, and a visible nose probe does not by itself prove a tandem warhead. Catalogue note: Open sources identify as a tandem-charge grenade variant; exact effects depend on module and geometry. Photographs often show the launcher or complete launcher/projectile assembly. Keep launcher, launch tube and munition as separate asset types in your catalogue; an externally visible tube is not necessarily part of the projectile in flight. Listed platform/compatibility: RPG-7 family. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://en.wikipedia.org/wiki/RPG-7); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22PG-7VR%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22PG-7VR%22+ammunition+photo+cutaway).

### R079 — PG-29V

**Family:** Man-portable anti-armour rocket / recoilless projectile  
**Exterior appearance:** PG-29V is catalogued here as RPG-shaped charge. The projectile/rocket often consists of a large warhead section with rounded or ogival nose, a narrower cylindrical rear body and tail stabilisers/fins or an attached motor/boom. Some weapons are issued as a complete disposable launcher tube, so photos may show the entire launcher instead of a separable round.

**What a cutaway may show:** A cutaway can reveal a warhead section and motor/stabilisation parts; the exact arrangement differs across rocket, recoilless and rifle-grenade systems. An external tube must not be mistaken for the projectile itself.

**Recognition cues:** The relative size of the warhead and narrower tail is a broad visual clue, but there are important exceptions.

**ArmorLab visual guidance:** Create separate assets for projectile, launcher/launch tube, and any disposable container. Use the correct configuration for the specific named system.

**Caveats:** This category intentionally spans distinct launch methods; it should not be a single shared physical template. Catalogue note: RPG-29 projectile designation; detailed terminal values omitted. Photographs often show the launcher or complete launcher/projectile assembly. Keep launcher, launch tube and munition as separate asset types in your catalogue; an externally visible tube is not necessarily part of the projectile in flight. Listed platform/compatibility: RPG-29 family. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://en.wikipedia.org/wiki/RPG-29); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22PG-29V%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22PG-29V%22+ammunition+photo+cutaway).

### R080 — Panzerfaust 60

**Family:** Man-portable anti-armour rocket / recoilless projectile  
**Exterior appearance:** Panzerfaust 60 is catalogued here as HEAT. The projectile/rocket often consists of a large warhead section with rounded or ogival nose, a narrower cylindrical rear body and tail stabilisers/fins or an attached motor/boom. Some weapons are issued as a complete disposable launcher tube, so photos may show the entire launcher instead of a separable round.

**What a cutaway may show:** A cutaway can reveal a warhead section and motor/stabilisation parts; the exact arrangement differs across rocket, recoilless and rifle-grenade systems. An external tube must not be mistaken for the projectile itself.

**Recognition cues:** The relative size of the warhead and narrower tail is a broad visual clue, but there are important exceptions.

**ArmorLab visual guidance:** Create separate assets for projectile, launcher/launch tube, and any disposable container. Use the correct configuration for the specific named system.

**Caveats:** This category intentionally spans distinct launch methods; it should not be a single shared physical template. Catalogue note: Representative German WWII infantry anti-tank weapon round. Photographs often show the launcher or complete launcher/projectile assembly. Keep launcher, launch tube and munition as separate asset types in your catalogue; an externally visible tube is not necessarily part of the projectile in flight. Listed platform/compatibility: Panzerfaust launcher family. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://www.nam.ac.uk/explore/attack-tanks); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22Panzerfaust+60%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22Panzerfaust+60%22+ammunition+photo+cutaway).

### R081 — Panzerfaust 100

**Family:** Man-portable anti-armour rocket / recoilless projectile  
**Exterior appearance:** Panzerfaust 100 is catalogued here as HEAT. The projectile/rocket often consists of a large warhead section with rounded or ogival nose, a narrower cylindrical rear body and tail stabilisers/fins or an attached motor/boom. Some weapons are issued as a complete disposable launcher tube, so photos may show the entire launcher instead of a separable round.

**What a cutaway may show:** A cutaway can reveal a warhead section and motor/stabilisation parts; the exact arrangement differs across rocket, recoilless and rifle-grenade systems. An external tube must not be mistaken for the projectile itself.

**Recognition cues:** The relative size of the warhead and narrower tail is a broad visual clue, but there are important exceptions.

**ArmorLab visual guidance:** Create separate assets for projectile, launcher/launch tube, and any disposable container. Use the correct configuration for the specific named system.

**Caveats:** This category intentionally spans distinct launch methods; it should not be a single shared physical template. Catalogue note: Later Panzerfaust family variant. Photographs often show the launcher or complete launcher/projectile assembly. Keep launcher, launch tube and munition as separate asset types in your catalogue; an externally visible tube is not necessarily part of the projectile in flight. Listed platform/compatibility: Panzerfaust launcher family. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://en.wikipedia.org/wiki/Panzerfaust); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22Panzerfaust+100%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22Panzerfaust+100%22+ammunition+photo+cutaway).

### R082 — Panzerschreck RPzB.Gr. 4322

**Family:** Man-portable anti-armour rocket / recoilless projectile  
**Exterior appearance:** Panzerschreck RPzB.Gr. 4322 is catalogued here as HEAT. The projectile/rocket often consists of a large warhead section with rounded or ogival nose, a narrower cylindrical rear body and tail stabilisers/fins or an attached motor/boom. Some weapons are issued as a complete disposable launcher tube, so photos may show the entire launcher instead of a separable round.

**What a cutaway may show:** A cutaway can reveal a warhead section and motor/stabilisation parts; the exact arrangement differs across rocket, recoilless and rifle-grenade systems. An external tube must not be mistaken for the projectile itself.

**Recognition cues:** The relative size of the warhead and narrower tail is a broad visual clue, but there are important exceptions.

**ArmorLab visual guidance:** Create separate assets for projectile, launcher/launch tube, and any disposable container. Use the correct configuration for the specific named system.

**Caveats:** This category intentionally spans distinct launch methods; it should not be a single shared physical template. Catalogue note: Representative German WWII rocket-propelled anti-tank round designation. Photographs often show the launcher or complete launcher/projectile assembly. Keep launcher, launch tube and munition as separate asset types in your catalogue; an externally visible tube is not necessarily part of the projectile in flight. Listed platform/compatibility: Panzerschreck launcher. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://en.wikipedia.org/wiki/Panzerschreck); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22Panzerschreck+RPzB.Gr.+4322%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22Panzerschreck+RPzB.Gr.+4322%22+ammunition+photo+cutaway).

### R083 — PIAT bomb

**Family:** Man-portable anti-armour rocket / recoilless projectile  
**Exterior appearance:** PIAT bomb is catalogued here as HEAT / shaped charge. The projectile/rocket often consists of a large warhead section with rounded or ogival nose, a narrower cylindrical rear body and tail stabilisers/fins or an attached motor/boom. Some weapons are issued as a complete disposable launcher tube, so photos may show the entire launcher instead of a separable round.

**What a cutaway may show:** A cutaway can reveal a warhead section and motor/stabilisation parts; the exact arrangement differs across rocket, recoilless and rifle-grenade systems. An external tube must not be mistaken for the projectile itself.

**Recognition cues:** The relative size of the warhead and narrower tail is a broad visual clue, but there are important exceptions.

**ArmorLab visual guidance:** Create separate assets for projectile, launcher/launch tube, and any disposable container. Use the correct configuration for the specific named system.

**Caveats:** This category intentionally spans distinct launch methods; it should not be a single shared physical template. Catalogue note: British infantry anti-tank projectile family; terminology commonly says bomb. Photographs often show the launcher or complete launcher/projectile assembly. Keep launcher, launch tube and munition as separate asset types in your catalogue; an externally visible tube is not necessarily part of the projectile in flight. Listed platform/compatibility: PIAT launcher. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://en.wikipedia.org/wiki/PIAT); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22PIAT+bomb%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22PIAT+bomb%22+ammunition+photo+cutaway).

### R084 — Bazooka M6A1 / M6 family

**Family:** Man-portable anti-armour rocket / recoilless projectile  
**Exterior appearance:** Bazooka M6A1 / M6 family is catalogued here as HEAT. The projectile/rocket often consists of a large warhead section with rounded or ogival nose, a narrower cylindrical rear body and tail stabilisers/fins or an attached motor/boom. Some weapons are issued as a complete disposable launcher tube, so photos may show the entire launcher instead of a separable round.

**What a cutaway may show:** A cutaway can reveal a warhead section and motor/stabilisation parts; the exact arrangement differs across rocket, recoilless and rifle-grenade systems. An external tube must not be mistaken for the projectile itself.

**Recognition cues:** The relative size of the warhead and narrower tail is a broad visual clue, but there are important exceptions.

**ArmorLab visual guidance:** Create separate assets for projectile, launcher/launch tube, and any disposable container. Use the correct configuration for the specific named system.

**Caveats:** This category intentionally spans distinct launch methods; it should not be a single shared physical template. Catalogue note: Representative early US bazooka anti-tank rocket family. Photographs often show the launcher or complete launcher/projectile assembly. Keep launcher, launch tube and munition as separate asset types in your catalogue; an externally visible tube is not necessarily part of the projectile in flight. Listed platform/compatibility: M1/M1A1 bazooka family. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://en.wikipedia.org/wiki/Bazooka); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22Bazooka+M6A1++M6+family%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22Bazooka+M6A1++M6+family%22+ammunition+photo+cutaway).

### R085 — No. 68 Anti-Tank Rifle Grenade

**Family:** Man-portable anti-armour rocket / recoilless projectile  
**Exterior appearance:** No. 68 Anti-Tank Rifle Grenade is catalogued here as HEAT / shaped charge. The projectile/rocket often consists of a large warhead section with rounded or ogival nose, a narrower cylindrical rear body and tail stabilisers/fins or an attached motor/boom. Some weapons are issued as a complete disposable launcher tube, so photos may show the entire launcher instead of a separable round.

**What a cutaway may show:** A cutaway can reveal a warhead section and motor/stabilisation parts; the exact arrangement differs across rocket, recoilless and rifle-grenade systems. An external tube must not be mistaken for the projectile itself.

**Recognition cues:** The relative size of the warhead and narrower tail is a broad visual clue, but there are important exceptions.

**ArmorLab visual guidance:** Create separate assets for projectile, launcher/launch tube, and any disposable container. Use the correct configuration for the specific named system.

**Caveats:** This category intentionally spans distinct launch methods; it should not be a single shared physical template. Catalogue note: Early British shaped-charge anti-tank grenade example cited by the Canadian Tank Museum. Photographs often show the launcher or complete launcher/projectile assembly. Keep launcher, launch tube and munition as separate asset types in your catalogue; an externally visible tube is not necessarily part of the projectile in flight. Listed platform/compatibility: Rifle-grenade launcher. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://www.tankmuseum.ca/blog-post/modern-anti-tank-ammunition/); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22No.+68+Anti-Tank+Rifle+Grenade%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22No.+68+Anti-Tank+Rifle+Grenade%22+ammunition+photo+cutaway).

### R086 — M72 LAW HEAT rocket

**Family:** Man-portable anti-armour rocket / recoilless projectile  
**Exterior appearance:** M72 LAW HEAT rocket is catalogued here as HEAT. The projectile/rocket often consists of a large warhead section with rounded or ogival nose, a narrower cylindrical rear body and tail stabilisers/fins or an attached motor/boom. Some weapons are issued as a complete disposable launcher tube, so photos may show the entire launcher instead of a separable round.

**What a cutaway may show:** A cutaway can reveal a warhead section and motor/stabilisation parts; the exact arrangement differs across rocket, recoilless and rifle-grenade systems. An external tube must not be mistaken for the projectile itself.

**Recognition cues:** The relative size of the warhead and narrower tail is a broad visual clue, but there are important exceptions.

**ArmorLab visual guidance:** Create separate assets for projectile, launcher/launch tube, and any disposable container. Use the correct configuration for the specific named system.

**Caveats:** This category intentionally spans distinct launch methods; it should not be a single shared physical template. Catalogue note: Representative lightweight anti-tank rocket family; variants differ. Photographs often show the launcher or complete launcher/projectile assembly. Keep launcher, launch tube and munition as separate asset types in your catalogue; an externally visible tube is not necessarily part of the projectile in flight. Listed platform/compatibility: M72 LAW family. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://en.wikipedia.org/wiki/M72_LAW); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22M72+LAW+HEAT+rocket%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22M72+LAW+HEAT+rocket%22+ammunition+photo+cutaway).

### R087 — AT4 HEAT / HEDP family

**Family:** Man-portable anti-armour rocket / recoilless projectile  
**Exterior appearance:** AT4 HEAT / HEDP family is catalogued here as HEAT/HEDP variants. The projectile/rocket often consists of a large warhead section with rounded or ogival nose, a narrower cylindrical rear body and tail stabilisers/fins or an attached motor/boom. Some weapons are issued as a complete disposable launcher tube, so photos may show the entire launcher instead of a separable round.

**What a cutaway may show:** A cutaway can reveal a warhead section and motor/stabilisation parts; the exact arrangement differs across rocket, recoilless and rifle-grenade systems. An external tube must not be mistaken for the projectile itself.

**Recognition cues:** The relative size of the warhead and narrower tail is a broad visual clue, but there are important exceptions.

**ArmorLab visual guidance:** Create separate assets for projectile, launcher/launch tube, and any disposable container. Use the correct configuration for the specific named system.

**Caveats:** This category intentionally spans distinct launch methods; it should not be a single shared physical template. Catalogue note: Anti-armour/anti-structure rocket family with several variants; don't assign one model to all. Photographs often show the launcher or complete launcher/projectile assembly. Keep launcher, launch tube and munition as separate asset types in your catalogue; an externally visible tube is not necessarily part of the projectile in flight. Listed platform/compatibility: AT4 family. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://en.wikipedia.org/wiki/AT4); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22AT4+HEAT++HEDP+family%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22AT4+HEAT++HEDP+family%22+ammunition+photo+cutaway).

### R088 — Carl Gustaf HEAT 551

**Family:** Man-portable anti-armour rocket / recoilless projectile  
**Exterior appearance:** Carl Gustaf HEAT 551 is catalogued here as HEAT. The projectile/rocket often consists of a large warhead section with rounded or ogival nose, a narrower cylindrical rear body and tail stabilisers/fins or an attached motor/boom. Some weapons are issued as a complete disposable launcher tube, so photos may show the entire launcher instead of a separable round.

**What a cutaway may show:** A cutaway can reveal a warhead section and motor/stabilisation parts; the exact arrangement differs across rocket, recoilless and rifle-grenade systems. An external tube must not be mistaken for the projectile itself.

**Recognition cues:** The relative size of the warhead and narrower tail is a broad visual clue, but there are important exceptions.

**ArmorLab visual guidance:** Create separate assets for projectile, launcher/launch tube, and any disposable container. Use the correct configuration for the specific named system.

**Caveats:** This category intentionally spans distinct launch methods; it should not be a single shared physical template. Catalogue note: Representative HEAT family for a recoilless weapon, not tank-gun ammunition. Photographs often show the launcher or complete launcher/projectile assembly. Keep launcher, launch tube and munition as separate asset types in your catalogue; an externally visible tube is not necessarily part of the projectile in flight. Listed platform/compatibility: Carl-Gustaf recoilless rifle family. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://en.wikipedia.org/wiki/Carl-Gustaf_recoilless_rifle); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22Carl+Gustaf+HEAT+551%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22Carl+Gustaf+HEAT+551%22+ammunition+photo+cutaway).

### R089 — BGM-71 TOW / TOW-2A

**Family:** Direct-attack anti-tank guided missile  
**Exterior appearance:** BGM-71 TOW / TOW-2A is catalogued here as Guided ATGM, HEAT family. Generally a long cylindrical missile with a rounded/ogival nose, small wings or fins, body bands/seams and a tail/motor section. A full system photograph may show the launch container, guidance unit, tripod or vehicle launcher as well as the missile.

**What a cutaway may show:** A cutaway can show seeker/fuze, warhead, motor and control sections. Public museum displays such as the ENTAC cutaway provide an example of how these assemblies can be presented, but one missile’s interior is not a template for another.

**Recognition cues:** The exact external profile, fin arrangement and nose materials are family-specific. Paint and stencilling are often display- or operator-dependent.

**ArmorLab visual guidance:** Select an exact missile silhouette and distinguish in-flight missile from its sealed canister. Add control surfaces only where supported by photographs.

**Caveats:** The catalogue uses “ATGM” across several generations, guidance types and warhead families; appearance must follow the selected designation. Catalogue note: Major ATGM family; variants differ in guidance and warhead design. This is a guided missile system, not a tank-gun cartridge. Reference images may show (a) missile only, (b) missile in a launch canister/tube, or (c) the complete launcher/sight. Label which one your picture represents. Listed platform/compatibility: TOW launcher family. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://www.ausa.org/publications/ode-sagger-drill-addressing-modern-anti-tank-guided-missile-problem-set); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22BGM-71+TOW++TOW-2A%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22BGM-71+TOW++TOW-2A%22+ammunition+photo+cutaway).

### R090 — BGM-71 TOW-2B

**Family:** Top-attack anti-tank guided missile  
**Exterior appearance:** BGM-71 TOW-2B is catalogued here as Guided ATGM / top-attack profile. Typically an elongated missile or sealed launch container. The missile has a nose section that may contain a seeker or fuze, a cylindrical midbody, and stabilising/control surfaces toward the rear or midbody. Some portable systems are best photographed as a complete launch tube rather than as the exposed missile.

**What a cutaway may show:** Warhead and guidance details require a system-specific cutaway. The chosen top-attack mode generally is not something you can determine from the external shape alone.

**Recognition cues:** The missile body is the object; the launch unit, sight, tripod or canister can be much larger. Do not accidentally catalogue the whole launcher as the projectile.

**ArmorLab visual guidance:** Separate the missile, transport/launch tube and sighting unit in visual assets. Keep flight profile/mode as simulation state, not a visual effect hard-coded to a silhouette.

**Caveats:** Top-attack is an attack profile and is not synonymous with one specific warhead construction. Catalogue note: Top-attack variant commonly described in public references; no exact performance values included. This is a guided missile system, not a tank-gun cartridge. Reference images may show (a) missile only, (b) missile in a launch canister/tube, or (c) the complete launcher/sight. Label which one your picture represents. Listed platform/compatibility: TOW launcher family. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://www.ausa.org/publications/ode-sagger-drill-addressing-modern-anti-tank-guided-missile-problem-set); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22BGM-71+TOW-2B%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22BGM-71+TOW-2B%22+ammunition+photo+cutaway).

### R091 — FGM-148 Javelin

**Family:** Top-attack anti-tank guided missile  
**Exterior appearance:** FGM-148 Javelin is catalogued here as Guided ATGM / top-attack capability. Typically an elongated missile or sealed launch container. The missile has a nose section that may contain a seeker or fuze, a cylindrical midbody, and stabilising/control surfaces toward the rear or midbody. Some portable systems are best photographed as a complete launch tube rather than as the exposed missile.

**What a cutaway may show:** Warhead and guidance details require a system-specific cutaway. The chosen top-attack mode generally is not something you can determine from the external shape alone.

**Recognition cues:** The missile body is the object; the launch unit, sight, tripod or canister can be much larger. Do not accidentally catalogue the whole launcher as the projectile.

**ArmorLab visual guidance:** Separate the missile, transport/launch tube and sighting unit in visual assets. Keep flight profile/mode as simulation state, not a visual effect hard-coded to a silhouette.

**Caveats:** Top-attack is an attack profile and is not synonymous with one specific warhead construction. Catalogue note: Widely documented modern anti-armour missile; real trajectory/warhead modelling needs its own subsystem. This is a guided missile system, not a tank-gun cartridge. Reference images may show (a) missile only, (b) missile in a launch canister/tube, or (c) the complete launcher/sight. Label which one your picture represents. Listed platform/compatibility: Man-portable missile system. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://www.ausa.org/publications/ode-sagger-drill-addressing-modern-anti-tank-guided-missile-problem-set); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22FGM-148+Javelin%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22FGM-148+Javelin%22+ammunition+photo+cutaway).

### R092 — Spike MR / LR / LR2 / ER / NLOS family

**Family:** Top-attack anti-tank guided missile  
**Exterior appearance:** Spike MR / LR / LR2 / ER / NLOS family is catalogued here as Guided ATGM family. Typically an elongated missile or sealed launch container. The missile has a nose section that may contain a seeker or fuze, a cylindrical midbody, and stabilising/control surfaces toward the rear or midbody. Some portable systems are best photographed as a complete launch tube rather than as the exposed missile.

**What a cutaway may show:** Warhead and guidance details require a system-specific cutaway. The chosen top-attack mode generally is not something you can determine from the external shape alone.

**Recognition cues:** The missile body is the object; the launch unit, sight, tripod or canister can be much larger. Do not accidentally catalogue the whole launcher as the projectile.

**ArmorLab visual guidance:** Separate the missile, transport/launch tube and sighting unit in visual assets. Keep flight profile/mode as simulation state, not a visual effect hard-coded to a silhouette.

**Caveats:** Top-attack is an attack profile and is not synonymous with one specific warhead construction. Catalogue note: Family contains numerous versions and warhead/trajectory differences; do not merge all variants into one profile. This is a guided missile system, not a tank-gun cartridge. Reference images may show (a) missile only, (b) missile in a launch canister/tube, or (c) the complete launcher/sight. Label which one your picture represents. Listed platform/compatibility: Multiple launch platforms by variant. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://www.ausa.org/publications/ode-sagger-drill-addressing-modern-anti-tank-guided-missile-problem-set); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22Spike+MR++LR++LR2++ER++NLOS+family%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22Spike+MR++LR++LR2++ER++NLOS+family%22+ammunition+photo+cutaway).

### R093 — MILAN 1 / 2 family

**Family:** Direct-attack anti-tank guided missile  
**Exterior appearance:** MILAN 1 / 2 family is catalogued here as Guided ATGM. Generally a long cylindrical missile with a rounded/ogival nose, small wings or fins, body bands/seams and a tail/motor section. A full system photograph may show the launch container, guidance unit, tripod or vehicle launcher as well as the missile.

**What a cutaway may show:** A cutaway can show seeker/fuze, warhead, motor and control sections. Public museum displays such as the ENTAC cutaway provide an example of how these assemblies can be presented, but one missile’s interior is not a template for another.

**Recognition cues:** The exact external profile, fin arrangement and nose materials are family-specific. Paint and stencilling are often display- or operator-dependent.

**ArmorLab visual guidance:** Select an exact missile silhouette and distinguish in-flight missile from its sealed canister. Add control surfaces only where supported by photographs.

**Caveats:** The catalogue uses “ATGM” across several generations, guidance types and warhead families; appearance must follow the selected designation. Catalogue note: Historically widespread missile family; multiple variants. This is a guided missile system, not a tank-gun cartridge. Reference images may show (a) missile only, (b) missile in a launch canister/tube, or (c) the complete launcher/sight. Label which one your picture represents. Listed platform/compatibility: Ground/vehicle launchers. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://en.wikipedia.org/wiki/MILAN); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22MILAN+1++2+family%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22MILAN+1++2+family%22+ammunition+photo+cutaway).

### R094 — HOT-1 / HOT-2 / HOT-3 family

**Family:** Direct-attack anti-tank guided missile  
**Exterior appearance:** HOT-1 / HOT-2 / HOT-3 family is catalogued here as Guided ATGM. Generally a long cylindrical missile with a rounded/ogival nose, small wings or fins, body bands/seams and a tail/motor section. A full system photograph may show the launch container, guidance unit, tripod or vehicle launcher as well as the missile.

**What a cutaway may show:** A cutaway can show seeker/fuze, warhead, motor and control sections. Public museum displays such as the ENTAC cutaway provide an example of how these assemblies can be presented, but one missile’s interior is not a template for another.

**Recognition cues:** The exact external profile, fin arrangement and nose materials are family-specific. Paint and stencilling are often display- or operator-dependent.

**ArmorLab visual guidance:** Select an exact missile silhouette and distinguish in-flight missile from its sealed canister. Add control surfaces only where supported by photographs.

**Caveats:** The catalogue uses “ATGM” across several generations, guidance types and warhead families; appearance must follow the selected designation. Catalogue note: Multiple variants; broad family entry rather than one ballistically identical missile. This is a guided missile system, not a tank-gun cartridge. Reference images may show (a) missile only, (b) missile in a launch canister/tube, or (c) the complete launcher/sight. Label which one your picture represents. Listed platform/compatibility: Vehicle and helicopter launchers. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://en.wikipedia.org/wiki/Euromissile_HOT); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22HOT-1++HOT-2++HOT-3+family%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22HOT-1++HOT-2++HOT-3+family%22+ammunition+photo+cutaway).

### R095 — 9M111 Fagot / AT-4 Spigot

**Family:** Direct-attack anti-tank guided missile  
**Exterior appearance:** 9M111 Fagot / AT-4 Spigot is catalogued here as Guided ATGM. Generally a long cylindrical missile with a rounded/ogival nose, small wings or fins, body bands/seams and a tail/motor section. A full system photograph may show the launch container, guidance unit, tripod or vehicle launcher as well as the missile.

**What a cutaway may show:** A cutaway can show seeker/fuze, warhead, motor and control sections. Public museum displays such as the ENTAC cutaway provide an example of how these assemblies can be presented, but one missile’s interior is not a template for another.

**Recognition cues:** The exact external profile, fin arrangement and nose materials are family-specific. Paint and stencilling are often display- or operator-dependent.

**ArmorLab visual guidance:** Select an exact missile silhouette and distinguish in-flight missile from its sealed canister. Add control surfaces only where supported by photographs.

**Caveats:** The catalogue uses “ATGM” across several generations, guidance types and warhead families; appearance must follow the selected designation. Catalogue note: Russian designation and NATO reporting name; public source lists as widely used family. This is a guided missile system, not a tank-gun cartridge. Reference images may show (a) missile only, (b) missile in a launch canister/tube, or (c) the complete launcher/sight. Label which one your picture represents. Listed platform/compatibility: Man-portable/vehicle launchers. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://www.ausa.org/publications/ode-sagger-drill-addressing-modern-anti-tank-guided-missile-problem-set); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%229M111+Fagot++AT-4+Spigot%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%229M111+Fagot++AT-4+Spigot%22+ammunition+photo+cutaway).

### R096 — 9M113 Konkurs / AT-5 Spandrel

**Family:** Direct-attack anti-tank guided missile  
**Exterior appearance:** 9M113 Konkurs / AT-5 Spandrel is catalogued here as Guided ATGM. Generally a long cylindrical missile with a rounded/ogival nose, small wings or fins, body bands/seams and a tail/motor section. A full system photograph may show the launch container, guidance unit, tripod or vehicle launcher as well as the missile.

**What a cutaway may show:** A cutaway can show seeker/fuze, warhead, motor and control sections. Public museum displays such as the ENTAC cutaway provide an example of how these assemblies can be presented, but one missile’s interior is not a template for another.

**Recognition cues:** The exact external profile, fin arrangement and nose materials are family-specific. Paint and stencilling are often display- or operator-dependent.

**ArmorLab visual guidance:** Select an exact missile silhouette and distinguish in-flight missile from its sealed canister. Add control surfaces only where supported by photographs.

**Caveats:** The catalogue uses “ATGM” across several generations, guidance types and warhead families; appearance must follow the selected designation. Catalogue note: Representative widely used Soviet/Russian ATGM family. This is a guided missile system, not a tank-gun cartridge. Reference images may show (a) missile only, (b) missile in a launch canister/tube, or (c) the complete launcher/sight. Label which one your picture represents. Listed platform/compatibility: Vehicle/portable launchers. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://www.ausa.org/publications/ode-sagger-drill-addressing-modern-anti-tank-guided-missile-problem-set); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%229M113+Konkurs++AT-5+Spandrel%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%229M113+Konkurs++AT-5+Spandrel%22+ammunition+photo+cutaway).

### R097 — 9M133 Kornet / AT-14 Spriggan

**Family:** Direct-attack anti-tank guided missile  
**Exterior appearance:** 9M133 Kornet / AT-14 Spriggan is catalogued here as Guided ATGM. Generally a long cylindrical missile with a rounded/ogival nose, small wings or fins, body bands/seams and a tail/motor section. A full system photograph may show the launch container, guidance unit, tripod or vehicle launcher as well as the missile.

**What a cutaway may show:** A cutaway can show seeker/fuze, warhead, motor and control sections. Public museum displays such as the ENTAC cutaway provide an example of how these assemblies can be presented, but one missile’s interior is not a template for another.

**Recognition cues:** The exact external profile, fin arrangement and nose materials are family-specific. Paint and stencilling are often display- or operator-dependent.

**ArmorLab visual guidance:** Select an exact missile silhouette and distinguish in-flight missile from its sealed canister. Add control surfaces only where supported by photographs.

**Caveats:** The catalogue uses “ATGM” across several generations, guidance types and warhead families; appearance must follow the selected designation. Catalogue note: Open-source public designation; several variants exist. This is a guided missile system, not a tank-gun cartridge. Reference images may show (a) missile only, (b) missile in a launch canister/tube, or (c) the complete launcher/sight. Label which one your picture represents. Listed platform/compatibility: Portable/vehicle launchers. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://www.ausa.org/publications/ode-sagger-drill-addressing-modern-anti-tank-guided-missile-problem-set); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%229M133+Kornet++AT-14+Spriggan%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%229M133+Kornet++AT-14+Spriggan%22+ammunition+photo+cutaway).

### R098 — 9M123 Khrizantema

**Family:** Direct-attack anti-tank guided missile  
**Exterior appearance:** 9M123 Khrizantema is catalogued here as Guided ATGM. Generally a long cylindrical missile with a rounded/ogival nose, small wings or fins, body bands/seams and a tail/motor section. A full system photograph may show the launch container, guidance unit, tripod or vehicle launcher as well as the missile.

**What a cutaway may show:** A cutaway can show seeker/fuze, warhead, motor and control sections. Public museum displays such as the ENTAC cutaway provide an example of how these assemblies can be presented, but one missile’s interior is not a template for another.

**Recognition cues:** The exact external profile, fin arrangement and nose materials are family-specific. Paint and stencilling are often display- or operator-dependent.

**ArmorLab visual guidance:** Select an exact missile silhouette and distinguish in-flight missile from its sealed canister. Add control surfaces only where supported by photographs.

**Caveats:** The catalogue uses “ATGM” across several generations, guidance types and warhead families; appearance must follow the selected designation. Catalogue note: Anti-armour missile family; the vehicle, guidance and warhead all matter to simulation. This is a guided missile system, not a tank-gun cartridge. Reference images may show (a) missile only, (b) missile in a launch canister/tube, or (c) the complete launcher/sight. Label which one your picture represents. Listed platform/compatibility: Vehicle launcher. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://en.wikipedia.org/wiki/9M123_Khrizantema); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%229M123+Khrizantema%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%229M123+Khrizantema%22+ammunition+photo+cutaway).

### R099 — 9M14 Malyutka / AT-3 Sagger

**Family:** Direct-attack anti-tank guided missile  
**Exterior appearance:** 9M14 Malyutka / AT-3 Sagger is catalogued here as Guided ATGM. Generally a long cylindrical missile with a rounded/ogival nose, small wings or fins, body bands/seams and a tail/motor section. A full system photograph may show the launch container, guidance unit, tripod or vehicle launcher as well as the missile.

**What a cutaway may show:** A cutaway can show seeker/fuze, warhead, motor and control sections. Public museum displays such as the ENTAC cutaway provide an example of how these assemblies can be presented, but one missile’s interior is not a template for another.

**Recognition cues:** The exact external profile, fin arrangement and nose materials are family-specific. Paint and stencilling are often display- or operator-dependent.

**ArmorLab visual guidance:** Select an exact missile silhouette and distinguish in-flight missile from its sealed canister. Add control surfaces only where supported by photographs.

**Caveats:** The catalogue uses “ATGM” across several generations, guidance types and warhead families; appearance must follow the selected designation. Catalogue note: Early widely exported anti-tank missile family; numerous variants exist. This is a guided missile system, not a tank-gun cartridge. Reference images may show (a) missile only, (b) missile in a launch canister/tube, or (c) the complete launcher/sight. Label which one your picture represents. Listed platform/compatibility: Portable/vehicle launchers. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://www.ausa.org/publications/ode-sagger-drill-addressing-modern-anti-tank-guided-missile-problem-set); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%229M14+Malyutka++AT-3+Sagger%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%229M14+Malyutka++AT-3+Sagger%22+ammunition+photo+cutaway).

### R100 — NLAW

**Family:** Top-attack anti-tank guided missile  
**Exterior appearance:** NLAW is catalogued here as Short-range anti-armour guided/line-of-sight weapon. Typically an elongated missile or sealed launch container. The missile has a nose section that may contain a seeker or fuze, a cylindrical midbody, and stabilising/control surfaces toward the rear or midbody. Some portable systems are best photographed as a complete launch tube rather than as the exposed missile.

**What a cutaway may show:** Warhead and guidance details require a system-specific cutaway. The chosen top-attack mode generally is not something you can determine from the external shape alone.

**Recognition cues:** The missile body is the object; the launch unit, sight, tripod or canister can be much larger. Do not accidentally catalogue the whole launcher as the projectile.

**ArmorLab visual guidance:** Separate the missile, transport/launch tube and sighting unit in visual assets. Keep flight profile/mode as simulation state, not a visual effect hard-coded to a silhouette.

**Caveats:** Top-attack is an attack profile and is not synonymous with one specific warhead construction. Catalogue note: Modern shoulder-fired anti-armour weapon; guidance and attack mode need a distinct model, not conventional tank-round physics. This is a guided missile system, not a tank-gun cartridge. Reference images may show (a) missile only, (b) missile in a launch canister/tube, or (c) the complete launcher/sight. Label which one your picture represents. Listed platform/compatibility: Man-portable. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://en.wikipedia.org/wiki/Next_generation_Light_Anti-tank_Weapon); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22NLAW%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22NLAW%22+ammunition+photo+cutaway).

### R101 — AGM-114 Hellfire

**Family:** Direct-attack anti-tank guided missile  
**Exterior appearance:** AGM-114 Hellfire is catalogued here as Guided missile / anti-armour variants. Generally a long cylindrical missile with a rounded/ogival nose, small wings or fins, body bands/seams and a tail/motor section. A full system photograph may show the launch container, guidance unit, tripod or vehicle launcher as well as the missile.

**What a cutaway may show:** A cutaway can show seeker/fuze, warhead, motor and control sections. Public museum displays such as the ENTAC cutaway provide an example of how these assemblies can be presented, but one missile’s interior is not a template for another.

**Recognition cues:** The exact external profile, fin arrangement and nose materials are family-specific. Paint and stencilling are often display- or operator-dependent.

**ArmorLab visual guidance:** Select an exact missile silhouette and distinguish in-flight missile from its sealed canister. Add control surfaces only where supported by photographs.

**Caveats:** The catalogue uses “ATGM” across several generations, guidance types and warhead families; appearance must follow the selected designation. Catalogue note: Multi-variant missile family, not tank cannon ammunition. This is a guided missile system, not a tank-gun cartridge. Reference images may show (a) missile only, (b) missile in a launch canister/tube, or (c) the complete launcher/sight. Label which one your picture represents. Listed platform/compatibility: Aircraft/vehicle launch platforms. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://en.wikipedia.org/wiki/AGM-114_Hellfire); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22AGM-114+Hellfire%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22AGM-114+Hellfire%22+ammunition+photo+cutaway).

### R102 — Brimstone

**Family:** Direct-attack anti-tank guided missile  
**Exterior appearance:** Brimstone is catalogued here as Guided anti-armour missile. Generally a long cylindrical missile with a rounded/ogival nose, small wings or fins, body bands/seams and a tail/motor section. A full system photograph may show the launch container, guidance unit, tripod or vehicle launcher as well as the missile.

**What a cutaway may show:** A cutaway can show seeker/fuze, warhead, motor and control sections. Public museum displays such as the ENTAC cutaway provide an example of how these assemblies can be presented, but one missile’s interior is not a template for another.

**Recognition cues:** The exact external profile, fin arrangement and nose materials are family-specific. Paint and stencilling are often display- or operator-dependent.

**ArmorLab visual guidance:** Select an exact missile silhouette and distinguish in-flight missile from its sealed canister. Add control surfaces only where supported by photographs.

**Caveats:** The catalogue uses “ATGM” across several generations, guidance types and warhead families; appearance must follow the selected designation. Catalogue note: Multi-variant family; sensor/guidance and warhead are separate systems. This is a guided missile system, not a tank-gun cartridge. Reference images may show (a) missile only, (b) missile in a launch canister/tube, or (c) the complete launcher/sight. Label which one your picture represents. Listed platform/compatibility: Air/ground launch variants. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://en.wikipedia.org/wiki/Brimstone_(missile)); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22Brimstone%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22Brimstone%22+ammunition+photo+cutaway).

### R103 — Akeron MP

**Family:** Direct-attack anti-tank guided missile  
**Exterior appearance:** Akeron MP is catalogued here as Guided ATGM. Generally a long cylindrical missile with a rounded/ogival nose, small wings or fins, body bands/seams and a tail/motor section. A full system photograph may show the launch container, guidance unit, tripod or vehicle launcher as well as the missile.

**What a cutaway may show:** A cutaway can show seeker/fuze, warhead, motor and control sections. Public museum displays such as the ENTAC cutaway provide an example of how these assemblies can be presented, but one missile’s interior is not a template for another.

**Recognition cues:** The exact external profile, fin arrangement and nose materials are family-specific. Paint and stencilling are often display- or operator-dependent.

**ArmorLab visual guidance:** Select an exact missile silhouette and distinguish in-flight missile from its sealed canister. Add control surfaces only where supported by photographs.

**Caveats:** The catalogue uses “ATGM” across several generations, guidance types and warhead families; appearance must follow the selected designation. Catalogue note: French modern anti-tank missile family; exact terminal performance omitted. This is a guided missile system, not a tank-gun cartridge. Reference images may show (a) missile only, (b) missile in a launch canister/tube, or (c) the complete launcher/sight. Label which one your picture represents. Listed platform/compatibility: Man-portable/vehicle launchers. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://en.wikipedia.org/wiki/Akeron_MP); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22Akeron+MP%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22Akeron+MP%22+ammunition+photo+cutaway).

### R104 — Pzgr. 39 (Panzergranate 39)

**Family:** Armour-piercing capped, ballistic-capped (APCBC)  
**Exterior appearance:** Pzgr. 39 (Panzergranate 39) is catalogued here as APCBC / APHE family. Usually an ogival shell with a relatively blunt or rounded nose treatment under a more tapered outer ballistic windshield. The projectile has a full-calibre cylindrical body and typically looks like a conventional tank/gun shell, not an arrow-like modern penetrator.

**What a cutaway may show:** Reference cutaways may show a harder penetration cap and a distinct outer aerodynamic cap. Some variants also contain an explosive cavity and base fuze, but that must be confirmed for the designation.

**Recognition cues:** The nose may look long and sleek even though the underlying penetrator is capped and full calibre. The letters APCBC do not guarantee a particular visible paint scheme.

**ArmorLab visual guidance:** Use a full-calibre projectile mesh with layered nose-cap regions only where the exact example supports them. Keep case/cartridge form separate from the projectile model.

**Caveats:** APCBC projectile-only photos and complete-cartridge photos can look substantially different; the round may be shown with its case or as a loose shell. Catalogue note: Designation used across multiple calibres; note the calibre/weapon variant for accurate simulation. Listed platform/compatibility: German tank and anti-tank guns by calibre. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://en.wikipedia.org/wiki/Panzergranate_39); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22Pzgr.+39+%28Panzergranate+39%29%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22Pzgr.+39+%28Panzergranate+39%29%22+ammunition+photo+cutaway).

### R105 — Pzgr. 40 (Panzergranate 40)

**Family:** Armour-piercing composite rigid (APCR)  
**Exterior appearance:** Pzgr. 40 (Panzergranate 40) is catalogued here as APCR/HVAP-like sub-calibre family. Typically a full-calibre projectile with a relatively compact body surrounding a denser, smaller core. To the eye, the projectile generally remains a short shell-like shape with a pointed or capped front; it is not the extremely long, slender dart associated with modern APFSDS.

**What a cutaway may show:** A cutaway may show the dense core nested inside a lighter body/sleeve. The core is not reliably identifiable in an intact projectile, and colour is not a safe indicator of core material.

**Recognition cues:** The key contrast is a sub-calibre dense core inside a full-calibre carrier/body, rather than a long rod carried in a discarding sabot.

**ArmorLab visual guidance:** Represent the core and surrounding body as separate material regions only with a relevant cutaway; use a compact full-calibre exterior, not an APFSDS silhouette.

**Caveats:** APCR and HVAP are related historical concepts, but national usage and construction differ. Catalogue note: Designation used for several tungsten-core ammunition types; exact construction varies by calibre. Listed platform/compatibility: German tank/anti-tank guns by calibre. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://en.wikipedia.org/wiki/Panzergranate_40); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22Pzgr.+40+%28Panzergranate+40%29%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22Pzgr.+40+%28Panzergranate+40%29%22+ammunition+photo+cutaway).

### R106 — Gr. 38 HL series

**Family:** High-explosive anti-tank (HEAT)  
**Exterior appearance:** Gr. 38 HL series is catalogued here as HEAT. A conventional HEAT projectile usually has a cylindrical metal body with a rounded or ogival nose region and a fuze at or near the front; rocket or recoilless versions may be a large warhead mounted ahead of a narrower motor/fin section. From the outside it can resemble an ordinary shell or rocket, so the shaped-charge effect is not obvious.

**What a cutaway may show:** A sectioned specimen typically reveals a hollow conical/cup-shaped liner within the warhead, with explosive surrounding it and a fuze arrangement. A visible cone in a cutaway is a key recognition feature, but exact geometry is model-specific.

**Recognition cues:** The external body does not have to be sharply pointed. Nose probes, fuze caps, finned tails and paint differ by system/era.

**ArmorLab visual guidance:** For the visual library, show a plausible external casing plus an optional clearly labelled cutaway illustration; do not draw the internal liner on the exterior or treat the warhead as a kinetic long rod.

**Caveats:** A HEAT label says something about the effect mechanism, not one universal external shape. Catalogue note: German shaped-charge ammunition series; exact suffix/calibre needs to be specified. Listed platform/compatibility: German tank/anti-tank guns by calibre. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://en.wikipedia.org/wiki/High-explosive_anti-tank); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22Gr.+38+HL+series%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22Gr.+38+HL+series%22+ammunition+photo+cutaway).

### R108 — Leopard 1 105 mm APDS family (DM13/related marks)

**Family:** Armour-piercing discarding sabot (APDS)  
**Exterior appearance:** Leopard 1 105 mm APDS family (DM13/related marks) is catalogued here as APDS. A complete cartridge often presents as a large gun cartridge with a smaller-calibre pointed projectile nested in a segmented or otherwise discardable sabot assembly. A display of the projectile alone may show the compact penetrator surrounded by petals/segments; a post-launch projectile is much narrower than the bore-calibre round.

**What a cutaway may show:** Cutaways or exploded displays can reveal the sub-calibre shot and surrounding sabot. Some designs have a pointed projectile-only nose and a short rear section; dimensions and petal shape vary by model.

**Recognition cues:** The sabot is the distinctive visual idea. Do not depict APDS as a long modern finned dart by default, and do not assume the spent sabot remains attached in flight.

**ArmorLab visual guidance:** For a complete cartridge view, show the case and sabot-supported projectile; for a flight/impact view, show only the projectile after discard unless modelling the short discard phase explicitly.

**Caveats:** Period APDS rounds vary substantially. Do not use a modern round’s long-rod silhouette for WWII APDS. Catalogue note: Family record for cross-checking calibre and mark before applying material data. The source dataset itself flags designation/variant uncertainty. Treat this entry as a family/alias-level record until the exact mark is confirmed by a primary reference. Listed platform/compatibility: 105 mm L7 family guns. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://www.tankmuseum.ca/blog-post/modern-anti-tank-ammunition/); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22Leopard+1+105+mm+APDS+family+%28DM13+related+marks%29%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22Leopard+1+105+mm+APDS+family+%28DM13+related+marks%29%22+ammunition+photo+cutaway).

### R109 — Modern 120 mm APFSDS training family (TPFSDS)

**Family:** Training / drill / practice round  
**Exterior appearance:** Modern 120 mm APFSDS training family (TPFSDS) is catalogued here as Practice kinetic-energy. Training ammunition often mimics the tactical round’s overall profile but may have a solid inert nose, different mass-distribution features, tracking/tracer hardware or conspicuous identification colours. It can also be a dummy/drill cartridge with no live functional payload. Color conventions are specific to the service, date and item.

**What a cutaway may show:** A cutaway shows how the trainer omits or replaces tactical components; however “practice” can still mean several different constructions, including target-practice projectiles that approximate external ballistics.

**Recognition cues:** Look for a designation and official colour/marking standard. Never use one generic blue/black/orange texture rule for all countries and periods.

**ArmorLab visual guidance:** Treat `training_status`, `inert_status`, and `ballistic_similarity` as separate metadata. Build the exact visual profile of the named trainer and do not give it tactical material/fuze behaviour by default.

**Caveats:** Training, drill, target-practice, TPFSDS, TPMP and inert are not exact synonyms. Catalogue note: KNDS lists a TPFSDS family; not a live anti-armour projectile model by default. Training colour and marking rules are nation-, era- and designation-specific. Do not rely on a generic blue/black/orange material to identify every practice or inert round; use the documented item caption. Listed platform/compatibility: NATO 120 mm smoothbore tank guns. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://knds.com/en/products/ammunition/120-mm); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22Modern+120+mm+APFSDS+training+family+%28TPFSDS%29%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22Modern+120+mm+APFSDS+training+family+%28TPFSDS%29%22+ammunition+photo+cutaway).

### R110 — Modern 120 mm HEAT-TP

**Family:** Training / drill / practice round  
**Exterior appearance:** Modern 120 mm HEAT-TP is catalogued here as Practice / inert training. Training ammunition often mimics the tactical round’s overall profile but may have a solid inert nose, different mass-distribution features, tracking/tracer hardware or conspicuous identification colours. It can also be a dummy/drill cartridge with no live functional payload. Color conventions are specific to the service, date and item.

**What a cutaway may show:** A cutaway shows how the trainer omits or replaces tactical components; however “practice” can still mean several different constructions, including target-practice projectiles that approximate external ballistics.

**Recognition cues:** Look for a designation and official colour/marking standard. Never use one generic blue/black/orange texture rule for all countries and periods.

**ArmorLab visual guidance:** Treat `training_status`, `inert_status`, and `ballistic_similarity` as separate metadata. Build the exact visual profile of the named trainer and do not give it tactical material/fuze behaviour by default.

**Caveats:** Training, drill, target-practice, TPFSDS, TPMP and inert are not exact synonyms. Catalogue note: Training round family; treat effect according to inert construction. Training colour and marking rules are nation-, era- and designation-specific. Do not rely on a generic blue/black/orange material to identify every practice or inert round; use the documented item caption. Listed platform/compatibility: NATO 120 mm smoothbore tank guns. Treat this as contextual catalogue information; it does not by itself verify the exact appearance of every mark or the current service status.

**References:** [source record](https://knds.com/en/products/ammunition/120-mm); [exact-designation image search](https://www.google.com/search?tbm=isch&q=%22Modern+120+mm+HEAT-TP%22+ammunition+photo+cutaway); [Bing image search](https://www.bing.com/images/search?q=%22Modern+120+mm+HEAT-TP%22+ammunition+photo+cutaway).


## Final modelling rule for ArmorLab

A visual catalogue should store **designation, ammunition family, object being pictured, exact model reference, source confidence and licence/source metadata** separately. Do not transform a visual description into a physics rule. For example, an APFSDS-style silhouette does not establish tungsten/DU composition; a HEAT family label does not produce a single universal nose model; “top attack” is a behaviour/profile label, not an external geometry. If the exact model cannot be established, label the art as a generic family illustration or a low-confidence prototype concept.

This reference set is research material only. It does not calibrate armour penetration, mass, muzzle velocity, fuze behaviour or other simulation parameters. Those require traceable model-specific technical sources and validation against measured data.
