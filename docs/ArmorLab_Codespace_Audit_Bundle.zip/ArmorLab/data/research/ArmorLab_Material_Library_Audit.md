# ArmorLab Material Library — audit and corrections

## Scope and verdict

Audited the 100-row CSV for internal consistency, plausibility of listed room-temperature physical properties, traceable sources, and readiness for an impact solver. The original table is generally plausible as a **reference-property catalogue**, but it is **not 1:1 realistic and is not a complete impact-material model**. All original source IDs S1–S11 remain in place, but the CSV contains no key linking them to bibliographic records; most original row values therefore cannot be independently traced from the provided file alone.

A true high-rate impact material model needs at least a defined stress–strain/flow law, yield and hardening behaviour, failure/fracture parameters, pressure/deviatoric response where appropriate, and strain-rate/temperature dependence when those matter. Density + Young’s modulus + thermal scalars alone cannot predict realistic ballistic-like deformation or penetration. The added mechanical columns are blank where a traceable grade-matched value was not established; blank means unknown/not supplied, not zero.

## Changes made

- Clarified `aluminum` as **Aluminium (pure-element reference)** because its 660 °C melting point and 237 W/m·K thermal conductivity correspond to near-pure elemental aluminium, not a particular wrought 1xxx commercial alloy.

- Corrected `alumina_96` to match CoorsTek nominal 96% alumina: density 3720 kg/m³ (was 3750), Young’s modulus 303 GPa (was 300), conductivity 24.7 W/m·K (was 25), and CTE 8.2 µm/m·K (was 7.5). Added flexural/compressive strength, Poisson ratio and fracture-toughness reference values, keeping flexural strength distinct from tensile strength.

- Corrected `alumina_995` CTE from 8.0 to 8.2 µm/m·K against the same CoorsTek manufacturer table; added its listed grade-level Poisson ratio, compressive/flexural strength and fracture-toughness references.

- Corrected `zirconia_ytzp` Young’s modulus from 210 to 200 GPa and specific heat from 450 to 400 J/kg·K against a KYOCERA Y-TZP datasheet. Flagged that its 2.5 W/m·K thermal conductivity is reported at 100 °C, so it is not a clean 20 °C value.

- Populated the previously empty melt fields for HDPE, UHMWPE, LDPE, polypropylene, PTFE, PEEK, nylon 6 and nylon 66 from the approximate transitions already described in the input notes, adding traceable family/grade references where available. These values remain grade-dependent, not universal constants.

- Added glass-transition temperatures for polycarbonate, PMMA, ABS and PEEK where the material is amorphous or has a glass transition; added family-level softening points for soda-lime and borosilicate glass. Their `melting_low_C` / `melting_high_C` fields remain blank because a single sharp melting point is the wrong representation.

- Added additional mechanical fields and filled only examples that could be tied to a specific reference or published engineering table: selected carbon/alloy steel rows, 6061-T6, 7075-T6, 7050-T7451, 304 stainless steel, alumina grades, Y-TZP, and one representative polycarbonate sheet record. Data are typical reference values, not guaranteed properties of every product sold under that grade name.

- Added `source_urls`, `audit_status`, `audit_notes`, and `impact_simulation_readiness` columns so later code can distinguish source-backed entries from provisional references. Original source IDs and original data are retained wherever not explicitly corrected.

## Important unresolved issues

1. **No ballistic/high-rate material laws:** there are no complete stress–strain curves, strain-rate parameters, damage-evolution law, failure strain calibration, or pressure-dependent response. Do not use this CSV alone to claim realistic impact predictions.

2. **Condition matters:** steel and aluminium strength can change substantially with temper, heat treatment, cold work, grain structure and product thickness. Some strength values added from tables are indicative, and must be paired with an explicit chosen material condition before simulation.

3. **Thermal values lack per-property reference temperatures:** most rows imply room temperature, but the cited Y-TZP thermal-conductivity value is at 100 °C; thermal conductivity and heat capacity change with temperature.

4. **Fibre rows are not composite armour:** aramid and E-glass fibre are anisotropic filament properties. A woven/laminated composite needs its matrix, fibre volume fraction, orientation, interface/delamination, and directional failure parameters.

5. **Alloy melting values:** some input rows have an identical low/high value for a multi-component alloy. That is not a measured solidus–liquidus interval. Those entries have an audit warning and should not be treated as an exact melting range until a grade- and chemistry-specific source is selected.

6. **Source traceability remains incomplete:** the CSV only provided S1–S11 codes and no reference list. A URL is supplied for the audited/corrected entries; other rows retain provisional status and need the missing bibliography or exact grade datasheets.

## Selected sources

- [EngiRef material-property sheet (selected steel values; reference values, not certified minima)](https://engiref.app/charts/material-properties/)

- [MatWeb / ASM: Aluminium 6061-T6/T651](https://asm.matweb.com/search/SpecificMaterial.asp?bassnum=MA6061T6)

- [MatWeb / ASM: Aluminium 7075-T6/T651](https://asm.matweb.com/search/SpecificMaterial.asp?bassnum=MA7075T6&lang=en)

- [MatWeb / ASM: Aluminium 7050-T7451](https://asm.matweb.com/search/SpecificMaterial.asp?bassnum=MA7050T745)

- [MatWeb: 304 stainless steel](https://matweb.com/search/DataSheet.aspx?MatGUID=abc4415b0f8b490387e3c922237098da)

- [CoorsTek: alumina grade table](https://www.coorstek.com/en/materials/alumina/)

- [KYOCERA: Y-TZP technical sheet](https://shop.kyocera-solutions.de/storage/downloads/kyocera-fzmk-y-tzp-englisch.pdf)

- [SABIC: LEXAN polycarbonate sheet thermal/mechanical properties](https://www.sabic.com/en/Images/LEXAN%E2%84%A2%20THERMOCLEAR%E2%84%A2%20Technical%20Manual%20-%20AME%20-%20EN_tcm1010-5028.pdf)

- [Victrex: PEEK product properties guide](https://www.victrex.com/-/media/downloads/technical-guides/victrex-product-guide-victrex-peek-properties-en-09-2018.pdf)

- [KERN: PTFE technical data](https://www.kern.de/de/technical-datasheet/polytetrafluoroethylene-ptfe?n=1601_2)

- [Asahi Kasei: SUNFINE UHMWPE grades and melting points](https://www.asahi-kasei.co.jp/sunfine/en/)

- [MatWeb: polypropylene homopolymer datasheet](https://apm.matweb.com/search/datasheet.aspx?MatGUID=42e239d060264e9d93c5be977833fca3&ckck=1)

- [Polyamide 6 data sheet](https://polysynthesis.au/wp-content/uploads/2024/10/TDS-Polyamide-6-PA6-Nylon-6.pdf)

- [Plastribution: PE family property guide](https://www.plb.ltd/sus-data-sheet/pe/)

- [DWK: borosilicate and soda-lime glass properties](https://www.dwk.com/na/technical/glass-types-properties)

- [Advanced Optics: soda-lime glass technical sheet](https://www.advancedoptics.com/SodaLimeGlassTechnicalDataSheet.pdf)

- [Colan: fibre-property comparison chart](https://www.colan.com.au/compositereinforcement/resources/fibre-information/fibre-comparison-charts)

- [MatWeb: boron carbide](https://www.matweb.com/search/datasheet.aspx?MatGUID=45fd34d496fe48e3ab513bcbc4079430&ckck=1)


## Use recommendation

Use this file as a **provisional materials reference** and keep the blanks as blanks. Before claiming physically accurate projectile/armour results, define the specific projectile/plate alloys and conditions, then calibrate and validate the solver against benchmark experiments. Do not fill missing strengths or failure data with guesses simply to make every row appear complete.
