# ArmorLab Deep Research Atlas: Armour Systems, Tank Families, and Anti-Armour Ammunition

**Prepared:** 23 October 2026  
**Use case:** technical planning for a small, offline, 2D material-physics simulator  
**Evidence boundary:** curated open-source survey, not a claim to enumerate every tank, every round, or every experimental design ever made.

## Executive summary

A realism-oriented armour simulator should not be built from a table of “armour thickness” and a single “penetration value.” Real protective systems combine material properties, geometry, construction, interfaces, supports, reactive or active components, and behind-armour effects. The National Academies’ review describes vehicle protection as a system-level problem constrained by weight and threat requirements, and identifies metallic, spaced, layered and transparent protection approaches; some detailed requirements and designs are not public [S01–S02]. Historical museum references cover the evolution from face-hardened plate and rolled homogeneous armour through sloped, spaced, composite and add-on protection [S03, S18].

The research atlas contains:

- **70 armour architecture and survivability-layout entries** (including physical armour, add-on systems, signature-management/countermeasure concepts, spall protection and internal survivability features).
- **35 material candidates/forms** (metals, ceramics, transparent materials, polymers, fibres, cellular structures and interface materials).
- **32 named armour/protection systems or packages** (passive composite families, reactive armour, active protection, countermeasures and vehicle-level suites).
- **35 ammunition mechanism families** (historic kinetic shot, sub-calibre and long-rod rounds, shaped-charge families, HESH/HEP, multipurpose/programmable, guided weapons and training/special-purpose rounds).
- **109 selected named ammunition or missile examples** from different eras and countries.
- **140 selected service vehicles, prototypes, testbeds and concepts**.
- A qualitative **armour × ammunition interaction matrix**, a simulation implementation checklist, and a sources register.

These are index counts, not counts of independently measured items. Evidence quality is uneven: some names are official and well documented; some prototype status or detailed construction is known only from secondary history; many modern protection recipes and performance data are deliberately unavailable in public records.

## 1. How to interpret the evidence

### Evidence classes

1. **Official government / military sources** are preferred for programme status, public designation, operator, and stated role.
2. **Manufacturer data** are useful for current product names and advertised material categories, but a manufacturer claim is not independent ballistic validation.
3. **Institutional technical reviews and research papers** are strongest for general material mechanics and the distinction between material properties and complete protection systems.
4. **Museum references** are valuable for historical development and surviving prototypes.
5. **Secondary indexes** are used as signposts for a wide historical catalogue, but should not be the sole basis for an exact physical parameter.

Each workbook row has a URL where available and an evidence/confidence note. **Confidence means confidence in the public identification/category, not confidence in a penetration result.**

### What “realistic” means for ArmorLab

A simulation can be visually persuasive yet physically wrong. For a meaningful model, track and validate:
- geometry and physical units;
- mass, momentum and contact;
- a material-specific constitutive response (elastic, plastic, brittle, ductile, or other supported behaviour);
- irreversible damage and fracture;
- fragment motion after separation;
- interfaces and contact between layers;
- energy accounting for the terms actually represented;
- numerical convergence as timestep and spatial resolution change;
- experimental comparison, where public test data exist.

The first target should be narrow: one clearly specified steel reference material, one alternative projectile material, a fixed geometry, and benchmark tests. Do not load hundreds of material names into a solver that has not yet validated its basic contact, failure and energy behaviour.

## 2. Armour: major families and concepts

The workbook’s **Armour Systems** tab has 70 entries and the **Materials** tab has 35 candidates. The following is the technical map.

### A. Metallic armour
- **Face-hardened / carburised plate:** hard outer case and tougher core; historically important in early armour. It must not be treated as equivalent to modern rolled homogeneous armour.
- **Rolled homogeneous armour (RHA):** reference family of rolled armour steel. RHA is a broad material class, not one universal chemistry, hardness or heat treatment.
- **High-hardness armour steel (HHA):** hardness is increased relative to lower-hardness plate, but toughness, weld zones, thickness and heat treatment remain important.
- **Cast armour steel:** shape is produced by casting; properties and local thickness vary by grade and production.
- **Welded plate and weld/heat-affected zones:** local properties at weldments can differ from parent plate.
- **Light-alloy armour:** aluminium alloys such as 5083-H131 and 7039-T64 have been used in armoured vehicles; they are not mechanically interchangeable with steel.
- **Titanium and dense-metal components:** appear in selected specialised applications and ammunition construction, but mass, cost, manufacturability and role differ.
- **Sloping, curved and compound-curved plates:** geometry is part of the protection system; obliquity changes path length, contact conditions and failure behaviour. Do not fake angle by increasing a scalar thickness.

### B. Passive composite and layered armour
- **Composite armour:** generic umbrella term for combinations of materials with different mechanical response.
- **Ceramic strike face + backing:** common design pattern in protective systems. Alumina, silicon carbide and boron carbide are important ceramic families; backing may include metal, polymer, fibre laminate or combinations.
- **Laminated / multi-material arrays:** multiple layers with interfaces, gaps, adhesives, backing and restraint. Layer order and boundary conditions matter.
- **Spaced armour / air gaps:** two or more separated plates or layers. The gap is geometry, not a new solid material.
- **Stand-off or sacrificial add-on panels:** change where/how an interaction occurs; exact effectiveness is configuration- and threat-dependent.
- **Transparent armour:** glass, glass-ceramic, polymer interlayers and polymer backing can form a multi-layer transparent system. ALON, spinel and sapphire are transparent-ceramic families, but availability and vehicle use vary.
- **Spall liners / back-face fragments control:** behind-armour survivability component; must be modelled behind the main structural plate rather than counted as additional RHA thickness.
- **Cellular / honeycomb / foam / crushable structure:** may manage deformation or blast loading; requires crush and densification laws rather than a generic rigid solid.
- **Adhesives, interlayers and joints:** interfaces can be as important as the bulk material; separation, debonding and shear transfer require explicit representation if fidelity is the goal.

### C. Reactive armour, active protection and countermeasures
These are **not simply material cards**.
- **Explosive reactive armour (ERA):** a module/system whose response includes an energetic event and moving plates; a passive solid-only collision model cannot reproduce it.
- **Non-explosive reactive armour (NERA):** layered systems that can respond through movement/deformation of layers; exact architectures vary and are often not public.
- **Named ERA families/packages:** examples indexed in the workbook include Kontakt-1, Kontakt-5, Relikt, Malachit, Kaktus, ERAWA, ARAT, Dyna and CLARA. These names indicate families or packages, not public, interchangeable material recipes.
- **Active protection systems (APS):** Trophy, Iron Fist, Arena, Drozd, Afghanit, Quick Kill and other programmes are represented as system-level countermeasures. A simulator needs an explicit detection/engagement/interception event to represent APS; a plate material alone cannot model it.
- **Soft-kill / electro-optical / signature-management systems:** Shtora-1, MUSS, ROSY and Barracuda-like signature-management references do not function as armour materials. Their effect belongs in a higher-level sensor/countermeasure model.
- **Urban / field add-on kits and modular vehicle suites:** TUSK/ARAT and comparable packages alter a specific vehicle configuration. Keep base armour, add-on module, spall liner and APS separate.

### D. Named passive-composite families and confidentiality
Chobham, Burlington, Dorchester and Epsom are important UK-associated names; MEXAS and AMAP are associated with German armour-system development. Public sources describe programme lineage and broad construction concepts, but **do not give sufficient open, vehicle-specific recipes to build an exact private armour stack**. Challenger 2’s public description uses the name Dorchester, while Challenger 3’s public programme information describes a new modular armour suite; the exact composition and performance are not published as a complete open specification [S14–S16]. The Chieftain 900 illustrates why prototype claims must be handled carefully: museum material describes it as an independent development using an intended Chobham armour package, rather than a fielded standard tank [S17].

## 3. Material library: use properties correctly

The **Materials** tab contains 35 candidate families/forms. They represent possible calibration targets; they are not all ready-to-use solver presets.

| Material family | Examples in the index | Important physics beyond density |
|---|---|---|
| Steel | RHA, HHA, cast steel, heat-treated plate, weld/HAZ | yield/plasticity, strain rate, ductile failure, shear, spall, temperature |
| Light metallic alloys | 5083-H131 / 7039-T64 aluminium; titanium families | alloy and temper, anisotropy, plasticity, local fracture |
| Dense metals | tungsten alloy, depleted uranium (where legally/contextually appropriate) | density alone is not sufficient; projectile structure and constitutive response matter |
| Ceramics | alumina, SiC, B4C, Si3N4, TiB2 | brittle damage, tensile failure, fragmentation, backing/interfacial support |
| Transparent ceramics | ALON, spinel, sapphire | transparency does not imply identical mechanical response; grade and form matter |
| Glass / glass-ceramic | laminated glass, glass-ceramic | brittle cracking, layer adhesion, fragments, interlayers |
| Polymers | UHMWPE, HDPE, LDPE, PP, PTFE, PEEK, nylon, polycarbonate, PVB, polyurethane | temperature/rate dependence, viscoelasticity, yield and failure, transition behaviour |
| Fibres / laminates | aramid, E-glass, CFRP | directionality, lamina/interface failure, delamination, resin behaviour |
| Cellular structures | aluminium foam, honeycomb, crushable core | compaction, densification, strain localisation |
| Support and interface materials | rubber, adhesives, backing, weld zones | contact, adhesion/debonding, local material change |

### Required per-material metadata
For a solver-ready material record, require:
- exact composition / alloy grade / temper / heat treatment;
- test temperature and direction;
- density and elastic constants;
- yield / flow curve or suitable strength model;
- strain-rate law if dynamic behaviour is modelled;
- failure/fracture parameters and calibration method;
- thermal properties only if heat is implemented;
- source citation for each value and whether it is measured, manufacturer-published or estimated.

A blank value is safer than a made-up parameter. A public room-temperature data sheet is not enough to calibrate high-rate penetration or dynamic fracture.

## 4. Anti-armour ammunition: mechanism families

The **Ammo Taxonomy** tab contains 35 mechanism families; **Named Ammunition** contains selected designations. Do not collapse these into one “penetration” variable.

### A. Kinetic-energy projectiles
- **AP (armour-piercing solid shot):** historic solid projectile family.
- **APC / APBC / APCBC:** capped forms and ballistic-cap arrangements that developed to manage impact and flight behaviour. Exact nomenclature varied by country and period.
- **APHE and APHEBC/APHECBC:** kinetic projectiles with explosive filling/fuze systems; terminal effect is not described by solid penetration alone.
- **APCR / HVAP:** sub-calibre designs with a dense core and lighter body/sabot-like structure; they are not equivalent to modern long-rod rounds.
- **APDS / APDS-T:** discarding-sabot projectiles; the sabot and penetrator have separate roles.
- **APFS / APFSDS / APFSDS-T:** fin-stabilised sub-calibre long-rod family and variants; model penetrator material, geometry, orientation, erosion/breakup where supported and contact against the target.
- **Target-practice / reduced-effect / inert variants:** similar designation does not guarantee live terminal behaviour.

### B. Chemical-energy and blast-effect families
- **HEAT / shaped charge:** uses a shaped-charge effect; it is not adequately modelled by treating the projectile as an ordinary solid punch.
- **HEAT-MP / MPAT / multipurpose families:** added target-effect roles vary with design; family names alone do not prove equivalent performance.
- **Tandem HEAT:** multi-stage charge arrangement intended to interact with layered reactive protection; represent as a sequence/system interaction, not a thicker monolithic projectile.
- **HESH / HEP:** squash-head / plastic explosive target-effect family; effects are strongly coupled to target material and configuration and should not be approximated as an AP rod.
- **EFP / formed-projectile systems:** explosive-formed projectile mechanism, distinct from a conventional shaped-charge jet.
- **HE / HE-FRAG / multipurpose HE:** blast/fragment and fuze functions; outcomes require a separate blast/fragment model.
- **STAFF / smart top-attack / EFP-related programme concepts:** programme-specific systems with public information that may be incomplete; keep them as concepts or historical designations unless supported by a primary source.
- **Canister, obstacle-reduction, smoke/obscurant, illumination and training:** included because a tank-ammunition inventory is not synonymous with anti-armour-only ammunition.

### C. Guided anti-tank weapons
ATGM designations and launch platforms are not interchangeable. The workbook indexes families such as TOW, Javelin, Spike, MILAN, HOT, Fagot, Konkurs, Kornet, Malyutka, NLAW, Hellfire, Brimstone and Akeron. Public descriptions differ in guidance, flight profile, launcher, warhead family, generation and service status [S13]. For ArmorLab, begin by representing the **warhead and impact interaction category**, and only later add flight guidance as a separate dynamics system.

## 5. Selected named rounds and programmes

The Named Ammunition tab includes public designation examples from historical, Cold War and current catalogues. Families represented include:
- British 2-pdr / 17-pdr / 20-pdr and later L-series tank ammunition examples;
- US M61, M62, M93, M392, M456, M735, M774, M833, M900 and M829-family designations, plus M830 / M830A1 / M908 / M1028 / XM1147 and historical experimental programme designations;
- German DM-series kinetic, HEAT and multipurpose families;
- French OFL-series and other 120 mm catalogue families;
- Soviet/Russian 3BM, 3BK and 3OF designations plus gun-launched guided missile families;
- Japanese Type 10 APFSDS, JM12A1 and Type-00 training examples;
- Israeli, South Korean and Chinese public or reported designation examples, with lower evidence flags where public confirmation is less robust;
- historic anti-tank rifles/launchers and shaped-charge rocket families (e.g., Panzerfaust, Panzerschreck, PIAT, Bazooka, RPG-family examples);
- modern shoulder-launched and guided weapon families.

This list is intentionally a **designation index**, not a performance ranking. Several export variants, local-language designations, ammunition generations, manufacturer labels, and platform-specific marks are not one-to-one equivalents. In particular, modern kinetic-round material details and exact performance may be unavailable or subject to test-condition differences.

### Ammunition example quality control
Before any named round enters the simulation configuration, verify:
1. the designation and exact variant;
2. the weapon/launcher compatibility;
3. live vs training / inert status;
4. projectile or warhead family;
5. exact material grade only if public and traceable;
6. test condition for any numeric claims.

If the evidence only establishes the name/type, use it as a research example but not as a calibrated performance preset.

## 6. Tank and armoured vehicle families

The Tank Prototype Index includes 140 selected entries across historical vehicles, service tanks, prototypes, technology demonstrators and publicly discussed concepts. It is intentionally broader than main battle tanks because anti-armour protection has been studied on light tanks, assault guns, tank destroyers, infantry support tanks, amphibious/airborne vehicles, wheeled gun systems and specialist engineer vehicles.

### Historical and early experimental development
Examples include Little Willie, early Mark-series British tanks, Whippet, A7V, Schneider CA1, Saint-Chamond, Renault FT, Char 2C, TOG I/II, Black Prince, Matilda II and Churchill variants. These represent very different construction eras; early riveted plate and historic face-hardened armour should not be assigned modern RHA parameters simply because both are “steel armour.” Museum coverage also highlights that a proposal, test hull and completed vehicle are distinct evidence states [S10, S18, S25].

### Cold War prototypes and technology testbeds
Selected entries include MBT-70, VT1-1 / VT1-2, Leopard 2AV, US T28/T95 and T29/T30/T32/T34 development vehicles, M6, XM1 competition vehicles, XM803, M1 TTB/CATTB, Soviet Object 279/770/187/292/477/Molot/195 and Object 640, Swedish Emil/KRV/UDES and Strv 2000, British FV4211 and MBT-80, French FCM F1 / AMX-50 / AMX-32 / AMX-40, and other trial projects. These entries vary from completed test vehicles to proposals whose exact status or details are debated; the workbook’s status and confidence columns must be read with the name.

### Modern fielded tanks and programmes
Examples include Leopard 1/2 variants, Challenger 1/2/3, Abrams variants, Leclerc, Merkava, T-64/T-72/T-80/T-90 families, Type 90/Type 10, K1/K2, Arjun, Altay development vehicles, Type 96/99 families, and other widely documented national designs. Modern names often refer to a family, not a single unchanging armour configuration. Upgrades, export variants, add-on armour and active protection can radically change the vehicle’s protection suite.

### Current and recently developed programmes
Challenger 3 is a useful current example of the difficulty of public modelling: official material describes a new 120 mm smoothbore and modular armour, but a public programme description is not a complete armour stack or independently validated ballistic data [S15–S16]. The same limitation applies to contemporary vehicles with undisclosed composite packages. A program status may also change; the workbook’s status wording is a point-in-time summary rather than a live operational database.

## 7. Armour × ammunition: how to use the qualitative matrix

The matrix does **not** say that a round defeats a material. It maps a round mechanism to the physical model components that need representation.

- **Monolithic and sloped steel:** contact, obliquity, material flow/failure, projectile deformation, possible ricochet or fragmentation.
- **Spaced plates:** multiple sequential impacts and the effect of the gap; each layer must remain separate in geometry.
- **Ceramic composite:** brittle strike-face damage plus backing response and interface separation.
- **NERA / reactive laminate:** layer kinematics and interaction, not a static “bonus thickness.”
- **ERA:** event-driven module interaction; do not emulate it as a constant material multiplier.
- **Spall liner:** separate behind-armour fragment capture/interaction.
- **APS:** a pre-impact detection/interception subsystem; if it is not implemented, do not pretend the material solver models it.
- **HESH/HEP and blast:** need target deformation / shock / spall approximations that differ from the kinetic projectile model.
- **HEAT, tandem and EFP:** need their own effect models; a generic solid-element projectile is not enough.
- **Training and canister:** may have multiple pellets or inert construction and must not inherit live warhead effects by name.

## 8. Recommended simulator fidelity roadmap

### Stage 0 — data integrity
- Use SI internally (metres, kilograms, seconds, pascals, joules), with millimetres only for UI entry.
- Store source URL, material grade, test temperature, strain rate, calibration state and confidence with every parameter.
- Keep `unknown` distinct from `0`.
- Version the material card and preserve the parameter set for each run.

### Stage 1 — validated simple contact
- Use one steel plate and one projectile.
- Verify equal-and-opposite contact impulses for an isolated pair.
- Verify a stable timestep and convergence under timestep refinement.
- Check mass and momentum conservation where the boundary conditions allow it.
- Account for contact potential energy and bond energy consistently; do not count the same energy twice.
- Keep energy ledger terms explicit (kinetic, elastic/bond, plastic dissipation, fracture dissipation, contact potential, externally supplied work, and numerical residual).

### Stage 2 — constitutive response and failure
- Implement one documented material model completely rather than many incomplete “material names.”
- Specify elastic law, yield/flow law, failure threshold and fracture energy.
- For a bonded-particle model, establish how bond softening/failure and any hard-core contact coexist so a broken bond cannot suddenly inject unaccounted energy.
- Check whether deformation localises or fragments are dependent on particle spacing; resolution is part of the physical model.

### Stage 3 — layered targets
- Represent actual geometric layers, interfaces, gaps, fasteners/support conditions and back-face liner as separate domains.
- Do not convert an angled plate to a fake effective thickness; rotate the actual geometry.
- Verify that a “100 mm” entry means 100 mm measured perpendicular to the plate.
- Keep vehicle armour package, add-on panels and active protection separate in the data model.

### Stage 4 — additional mechanisms only after validation
- Add thermal coupling only after mechanical energy accounting is stable.
- Add high-rate projectile erosion/fracture only with a defined model and validation data.
- Add chemical-energy warheads as separate physics approximations with clear limitations, not as tuned kinetic projectiles.
- Add blast, fire, APS, sensor/countermeasure and crew survivability as separate system models.
- Do not claim 1:1 engineering prediction until benchmark data and error bounds support that claim.

## 9. Graph / dashboard interpretation

The workbook Dashboard graphs show **how broad the reference atlas is**, not performance:
- count of indexed armour architecture families;
- count of named ammunition examples by broad category;
- count of vehicle entries grouped by status.

These visual counts are useful for navigation and coverage balance only. They should never be read as showing how common, effective or realistic a particular armour/round family is.

## 10. Sources and further reading

The **Sources** tab contains all 33 URLs and a use/limitations note for each. Priority references include:

- [S01] National Academies Press, *Opportunities in Protection Materials Science and Technology for Future Army Applications*, Chapter 2 — broad armour system architecture, materials and public-disclosure limits.
- [S02] National Academies Press, Chapter 5 — armour ceramics and material families.
- [S03] Norfolk Tank Museum, *Types of Armour* — historic and broad armour types.
- [S04] Canadian Tank Museum, *Modern Anti-Tank Ammunition* — mechanism-level ammunition overview.
- [S05] US Army JPEO Armaments & Ammunition, *MAS Handbook 2025* — public ammunition nomenclature reference.
- [S06] US Army, XM1147 AMP public test account.
- [S07] KNDS, 120 mm ammunition catalogue — manufacturer-published round families.
- [S08] Japan Ministry of Defense equipment documentation — Type 10 ammunition examples.
- [S11] US Army, 1997 Weapons Systems Handbook — historical US tank gun ammunition and programme designations.
- [S13] AUSA, guided anti-tank missile overview.
- [S14–S16] British Army / UK Government, Challenger 2 and Challenger 3 programme information.
- [S17–S18] The Tank Museum, Chieftain / Chieftain 900 and experimental tank history.
- [S19–S20] Secondary prototype indexes for discovery only; verify status before use.
- [S22] Elbit Systems, Iron Fist active protection programme announcement.
- [S30] Rafael, Trophy APS product information.
- [S32] National Academies review on ballistic armour materials.

## Appendix A. Indexed armour-system names

The complete row-level descriptions, family, model guidance, status/caveat and source URL are in the Armour Systems tab. The indexed names are:

- Face-hardened / carburized plate — Monolithic metallic
- Rolled homogeneous armour (RHA) — Monolithic metallic
- High-hardness armour steel (HHA) — Monolithic metallic
- Dual-hardness / through-thickness graded steel — Monolithic / graded
- Cast homogeneous armour — Monolithic metallic
- Welded plate armour — Monolithic / structure
- Sloped armour — Geometric arrangement
- Curved / compound-curved armour — Geometry
- Spaced armour (air gap) — Passive multi-layer
- Multi-plate spaced array — Passive multi-layer
- Perforated / hole-pattern armour — Passive add-on
- Bar / slat armour — Stand-off add-on
- Cage / mesh / wire armour — Stand-off add-on
- Appliqué armour — Add-on
- Modular / bolt-on armour — Add-on modular
- Composite armour (generic) — Passive multi-material
- Ceramic-faced composite — Ceramic / backing
- Ceramic-metal laminate — Multi-material laminate
- Ceramic-polymer/fibre laminate — Multi-material laminate
- Metal-polymer-metal sandwich — Layered sandwich
- Chobham armour (designation/family) — Named composite family
- Burlington armour — Named composite family
- Dorchester armour / Dorchester Level 2 — Named classified composite suite
- Stillbrew armour — Named appliqué suite
- BDD / Soviet add-on armour — Named add-on family
- Non-explosive reactive armour (NERA) — Reactive/passive laminate
- Non-energetic / non-explosive reactive armour variants (NxRA) — Reactive/passive laminate
- Explosive reactive armour (ERA), first generation — Energetic add-on
- Heavy / kinetic-energy reactive armour — Energetic reactive add-on
- Multi-layer / tandem-resistant ERA family — Energetic reactive add-on
- Kontakt-1 — Named ERA family
- Kontakt-5 — Named heavy ERA family
- Relikt — Named ERA family
- Malachit — Named ERA family
- Kaktus — Experimental reactive protection
- ERAWA — Named Polish ERA family
- Dyna / DYNA family — Named ERA family
- ARAT / ARAT-1 / ARAT-2 — Named ERA family
- CLARA — Named non-explosive reactive family
- MEXAS — Modular composite armour family
- AMAP — Advanced modular armour protection family
- Depleted-uranium composite inserts — Dense-metal composite
- Aluminium armour alloy plate — Monolithic/lightweight metallic
- Titanium alloy armour / structural panels — Metallic/lightweight
- Transparent laminated glass/polycarbonate armour — Transparent laminate
- Transparent ceramic armour: ALON — Transparent ceramic
- Transparent ceramic armour: spinel — Transparent ceramic
- Transparent ceramic armour: sapphire — Transparent ceramic
- Spall liner — Behind-armour liner
- Fragment / debris catcher backing — Backing layer
- Mine-resistant V-hull — Blast geometry / structure
- Double-floor / layered belly protection — Blast structure
- Suspended / energy-attenuating crew seats — Occupant protection (not armour)
- Active protection system (hard-kill) — Active protection (not passive armour)
- Soft-kill protection suite — Countermeasure / electronic protection
- Electromagnetic / electric armour (research) — Energetic / experimental
- Smart / adaptive armour (research umbrella) — Experimental / adaptive
- Active camouflage / multispectral signature management — Signature protection (not armour)
- Smoke obscurant / multispectral smoke — Countermeasure (not armour)
- Sacrificial external panel / bumper armour — Stand-off / sacrificial
- Honeycomb / cellular sandwich protection — Cellular structure
- Elastomer-interlayer reactive array — Reactive laminate
- Composite armour with textile/fibre layers — Composite laminate
- Rubber / steel sandwich add-on (BDD-style concept) — Layered add-on
- Perforated steel + backing package — Composite add-on
- Modular side skirts — Add-on side protection
- Track-link / improvised add-on protection — Field expedient
- Anti-drone cage / roof lattice — Stand-off / top-attack mitigation
- Roof / top-attack armour package — Directional composite/add-on
- Ammunition compartment blow-off panels / isolation — Internal survivability layout

## Appendix B. Indexed named ammunition and missile examples

The full 109-row index, including country/developer/operator, type, era/status, platform compatibility, notes, confidence and source URL is in the Named Ammunition tab. Names/designations are transcribed as selected public examples; variants must be checked before calibrating physics.

- **2-pdr AP shot** — United Kingdom; AP solid shot; WWII historical.
- **6-pdr APCBC** — United Kingdom; APCBC; WWII historical.
- **17-pdr APDS** — United Kingdom; APDS; WWII late-war.
- **20-pdr APDS** — United Kingdom; APDS; Early Cold War.
- **L15-series APDS** — United Kingdom; APDS; Cold War.
- **L31 HESH** — United Kingdom; HESH/HEP; Cold War.
- **L23A1 APFSDS** — United Kingdom; APFSDS; Cold War / modernised.
- **L26A1 CHARM 1** — United Kingdom; APFSDS; Cold War / service round.
- **L27A1 CHARM 3** — United Kingdom; APFSDS; 1990s onward.
- **L29A1 C3TR** — United Kingdom; Target-practice / training; Cold War / training.
- **M61 APC** — United States; APC; WWII / legacy.
- **M62 APCBC** — United States; APCBC; WWII / legacy.
- **M93 HVAP** — United States; HVAP/APCR family; WWII.
- **M392 APDS** — United States / UK-linked family; APDS; Cold War.
- **M456 HEAT-T** — United States; HEAT; Cold War.
- **M735 APFSDS** — United States; APFSDS; Cold War.
- **M774 APFSDS** — United States; APFSDS; Cold War.
- **M833 APFSDS** — United States; APFSDS; Late Cold War.
- **M900 APFSDS** — United States; APFSDS; Late Cold War.
- **M829** — United States; APFSDS-T; Cold War / service family.
- **M829A1** — United States; APFSDS-T; Cold War / service family.
- **M829A2** — United States; APFSDS-T; 1990s.
- **M829A3** — United States; APFSDS-T; 2000s.
- **M829A4** — United States; APFSDS-T; Modern service/portfolio.
- **M830 HEAT-MP-T** — United States; HEAT-MP-T; Cold War / service family.
- **M830A1 HEAT-MP-T / MPAT** — United States; Multipurpose anti-tank; 1990s onward.
- **M908 obstacle-reduction round** — United States; Obstacle reduction / multipurpose; Modern service family.
- **M1028 Canister** — United States; Canister; Modern service family.
- **M865 TPCSDS-T** — United States; Target-practice APDS-like; Training.
- **M1002 TPMP** — United States; Target-practice multipurpose; Training.
- **XM943 STAFF** — United States; Smart top-attack/EFP concept; Development programme (historical).
- **XM1007 TERM-KE** — United States; Guided kinetic-energy concept; Development programme (historical).
- **XM1147 AMP** — United States; Advanced multi-purpose programmable; Modern programme / service introduction path.
- **DM12 HEAT-FS** — Germany; HEAT; Cold War.
- **DM13 APDS-T** — Germany; APDS-T; Cold War.
- **DM23 APFSDS** — Germany; APFSDS; Cold War.
- **DM33 APFSDS** — Germany; APFSDS; Cold War.
- **DM43 APFSDS** — Germany / France-linked programme; APFSDS; Cold War / modernisation.
- **DM53 APFSDS** — Germany; APFSDS; Modern.
- **DM63 APFSDS** — Germany; APFSDS; Modern.
- **DM73 APFSDS** — Germany; APFSDS; Recent/modern.
- **DM11 programmable HE** — Germany; Programmable multi-purpose HE; Modern.
- **OFL 105 F1** — France; APFSDS-T; Cold War.
- **OFL 120 F1** — France; APFSDS; Cold War / modernisation.
- **OFL 120 F2** — France; APFSDS; Modern.
- **SHARD 120 mm** — France / KNDS; APFSDS; Modern manufacturer product.
- **120 mm HE F1** — France / KNDS; HE; Modern manufacturer product.
- **120 mm CAN** — France / KNDS; Canister; Modern manufacturer product.
- **120 mm HEAT-TP F1A** — France / KNDS; Training HEAT-type; Training.
- **3BM15** — USSR / Russia; APFSDS; Cold War.
- **3BM22** — USSR / Russia; APFSDS; Cold War.
- **3BM26** — USSR / Russia; APFSDS; Cold War.
- **3BM29 Nadezhda** — USSR / Russia; APFSDS; Cold War.
- **3BM32 Vant** — USSR / Russia; APFSDS; Late Cold War.
- **3BM42 Mango** — USSR / Russia; APFSDS; Late Cold War onward.
- **3BM46 Svinets-1** — Russia; APFSDS; Post-Soviet.
- **3BM59 Svinets-2** — Russia; APFSDS; Modern.
- **3BM60 Svinets-2 (designation usage varies by source)** — Russia; APFSDS; Modern / designation caution.
- **3BK14M shaped-charge round** — USSR / Russia; HEAT; Cold War.
- **3BK18M shaped-charge round** — USSR / Russia; HEAT; Cold War.
- **3BK21B shaped-charge round** — USSR / Russia; HEAT; Late Cold War.
- **3OF26** — USSR / Russia; HE-FRAG; Cold War onward.
- **9M112 Kobra** — USSR / Russia; Gun-launched ATGM; Cold War.
- **9M119 Refleks / Svir family** — USSR / Russia; Gun-launched ATGM; Late Cold War onward.
- **9M119M Invar** — Russia; Gun-launched ATGM; Modern.
- **JM33 APFSDS** — Japan; APFSDS; Modern.
- **Type 10 APFSDS round** — Japan; APFSDS; Modern.
- **JM12A1 HEAT-MP** — Japan; HEAT-MP; Modern.
- **Type-00 training shell** — Japan; Training; Modern training.
- **M111 Hetz** — Israel; APFSDS; Cold War / modernisation.
- **M322 APFSDS** — Israel; APFSDS; Modern.
- **M339 HE-MP-T** — Israel; Multi-purpose HE; Modern.
- **K279 APFSDS** — South Korea; APFSDS; Modern.
- **K280 HEAT-MP** — South Korea; HEAT-MP; Modern.
- **DTC10-125** — China; APFSDS (reported); Modern / open-source designation.
- **PG-7V** — USSR / Russia; RPG-shaped charge; Cold War.
- **PG-7VL** — USSR / Russia; RPG-shaped charge; Cold War / later.
- **PG-7VR** — USSR / Russia; Tandem HEAT; Late Cold War onward.
- **PG-29V** — Russia; RPG-shaped charge; Modern.
- **Panzerfaust 60** — Germany; HEAT; WWII.
- **Panzerfaust 100** — Germany; HEAT; WWII.
- **Panzerschreck RPzB.Gr. 4322** — Germany; HEAT; WWII.
- **PIAT bomb** — United Kingdom; HEAT / shaped charge; WWII.
- **Bazooka M6A1 / M6 family** — United States; HEAT; WWII.
- **No. 68 Anti-Tank Rifle Grenade** — United Kingdom; HEAT / shaped charge; 1940 onward.
- **M72 LAW HEAT rocket** — United States; HEAT; Cold War onward.
- **AT4 HEAT / HEDP family** — Sweden / US users; HEAT/HEDP variants; Cold War onward.
- **Carl Gustaf HEAT 551** — Sweden; HEAT; Modern.
- **BGM-71 TOW / TOW-2A** — United States; Guided ATGM, HEAT family; Cold War onward.
- **BGM-71 TOW-2B** — United States; Guided ATGM / top-attack profile; Modern variant.
- **FGM-148 Javelin** — United States; Guided ATGM / top-attack capability; Modern.
- **Spike MR / LR / LR2 / ER / NLOS family** — Israel; Guided ATGM family; Modern.
- **MILAN 1 / 2 family** — France / Germany / multinational; Guided ATGM; Cold War onward.
- **HOT-1 / HOT-2 / HOT-3 family** — France / Germany; Guided ATGM; Cold War onward.
- **9M111 Fagot / AT-4 Spigot** — USSR / Russia; Guided ATGM; Cold War onward.
- **9M113 Konkurs / AT-5 Spandrel** — USSR / Russia; Guided ATGM; Cold War onward.
- **9M133 Kornet / AT-14 Spriggan** — Russia; Guided ATGM; Modern.
- **9M123 Khrizantema** — Russia; Guided ATGM; Modern.
- **9M14 Malyutka / AT-3 Sagger** — USSR / Russia; Guided ATGM; Cold War onward.
- **NLAW** — Sweden / United Kingdom; Short-range anti-armour guided/line-of-sight weapon; Modern.
- **AGM-114 Hellfire** — United States; Guided missile / anti-armour variants; Modern.
- **Brimstone** — United Kingdom; Guided anti-armour missile; Modern.
- **Akeron MP** — France; Guided ATGM; Modern.
- **Pzgr. 39 (Panzergranate 39)** — Germany; APCBC / APHE family; WWII.
- **Pzgr. 40 (Panzergranate 40)** — Germany; APCR/HVAP-like sub-calibre family; WWII.
- **Gr. 38 HL series** — Germany; HEAT; WWII.
- **Leopard 1 105 mm APDS family (DM13/related marks)** — Germany / NATO users; APDS; Cold War.
- **Modern 120 mm APFSDS training family (TPFSDS)** — France / KNDS; Practice kinetic-energy; Modern training.
- **Modern 120 mm HEAT-TP** — International / KNDS listing; Practice / inert training; Modern training.

## Appendix C. Indexed tank, AFV, prototype and concept names

The full 140-row index is in Tank Prototype Index. It carries period, class, status, design/protection notes, source URL and confidence. A name’s inclusion is not an assertion that its full production configuration or armour data is publicly known.

- **Little Willie** (United Kingdom, 1915) — Prototype.
- **Pedrail Landship** (United Kingdom, 1915–1919) — Concept / test machines.
- **Mark I** (United Kingdom, 1916) — Fielded.
- **Mark IV** (United Kingdom, 1917) — Fielded.
- **Whippet (Medium Mark A)** (United Kingdom, 1917–1918) — Fielded.
- **A7V** (Germany, 1917–1918) — Fielded in small numbers.
- **Schneider CA1** (France, 1916–1918) — Fielded.
- **Saint-Chamond** (France, 1917) — Fielded.
- **Renault FT** (France, 1917) — Fielded.
- **Char 2C** (France, 1920s) — Fielded in very small numbers.
- **TOG 1** (United Kingdom, 1940) — Prototype.
- **TOG II*** (United Kingdom, 1941–1943) — Prototype.
- **A43 Black Prince** (United Kingdom, 1943–1945) — 6 prototypes.
- **Matilda II** (United Kingdom, 1937–1940s) — Fielded.
- **Churchill Mk VII** (United Kingdom, 1944) — Fielded.
- **Centurion A41 prototype** (United Kingdom, 1945) — Prototype.
- **Chieftain Mk 5/3(P) / Chieftain 900** (United Kingdom, 1970s–1986) — 2 vehicles; cancelled.
- **FV4211 'Aluminium Chieftain'** (United Kingdom, 1970s) — Prototype / test rig.
- **MBT-80** (United Kingdom, 1970s–1980s) — Prototype / cancelled.
- **Vickers MBT Mk 7** (United Kingdom / Germany, 1980s) — Prototype / limited production history.
- **Challenger 1** (United Kingdom, 1980s) — Fielded.
- **Challenger 2** (United Kingdom, 1990s) — Fielded.
- **Challenger 2 CLIP demonstrator** (United Kingdom, 2000s) — Demonstrator.
- **Challenger 3 demonstrator/prototypes** (United Kingdom, 2024 onward) — Prototype/trials programme.
- **Panzer I** (Germany, 1930s) — Fielded.
- **Panzer III** (Germany, 1939–1940s) — Fielded.
- **Panzer IV** (Germany, 1930s–1945) — Fielded.
- **Panther II** (Germany, 1943–1945) — Prototype / incomplete.
- **Tiger I** (Germany, 1942) — Fielded.
- **Tiger II** (Germany, 1944) — Fielded.
- **Maus (Panzer VIII)** (Germany, 1944–1945) — 2 prototypes; incomplete testing.
- **E-100** (Germany, 1940s) — Prototype hull / incomplete.
- **Neubaufahrzeug** (Germany, 1930s) — Small prototype series.
- **VK 45.01 (P)** (Germany, 1942) — Prototype; lost competition.
- **Kampfpanzer 70 / MBT-70** (United States / West Germany, 1960s–1970s) — Prototypes; cancelled.
- **VT1-1 / VT1-2** (West Germany, 1970s) — Prototype demonstrators.
- **Leopard 2AV** (West Germany, 1970s) — Prototype / US evaluation.
- **Leopard 2 PSO** (Germany, 2000s) — Demonstrator / upgrade.
- **KF51 Panther** (Germany, 2022 onward) — Industry demonstrator / development.
- **FCM F1** (France, 1930s–1940) — Cancelled concept.
- **AMX-50** (France, 1950s) — Prototype family; cancelled.
- **AMX-32** (France, 1970s–1980s) — Prototype / no major production.
- **AMX-40** (France, 1980s) — Prototype / cancelled for export.
- **Leclerc prototype programme** (France, 1980s–1990s) — Prototypes then production.
- **ELC EVEN** (France, 1950s–1960s) — Prototype / cancelled.
- **M2 Light Tank** (United States, 1930s) — Fielded.
- **M3 Stuart** (United States, 1941) — Fielded.
- **M4 Sherman** (United States, 1942) — Fielded.
- **M26 Pershing** (United States, 1945) — Fielded in limited WWII service.
- **M6 Heavy Tank** (United States, 1940s) — Small production/test programme.
- **T28 / T95 Super Heavy Tank** (United States, 1940s) — 2 prototypes.
- **T29 Heavy Tank** (United States, 1944–1947) — Prototype series.
- **T30 Heavy Tank** (United States, 1940s) — Prototype series.
- **T32 Heavy Tank** (United States, 1945–1946) — Prototype series.
- **T34 Heavy Tank** (United States, 1945–1948) — Prototype series.
- **XM1 prototypes** (United States, 1970s) — Prototype competition vehicles.
- **M1 Abrams** (United States, 1980s onward) — Fielded.
- **M1 TTB (Tank Test Bed)** (United States, 1980s) — Prototype / demonstrator.
- **CATTB (Component Advanced Technology Test Bed)** (United States, 1980s–1990s) — Prototype / technology testbed.
- **XM803** (United States, 1970s) — Prototype / cancelled.
- **RDF/LT (Rapid Deployment Force Light Tank)** (United States, 1980s) — Prototype / cancelled.
- **M8 Armored Gun System** (United States, 1980s–1990s) — Prototype, later revived proposals.
- **Expeditionary Tank / MPF demonstrators** (United States, 2000s–2020s) — Demonstrators; programme outcome varies.
- **T-34/76** (USSR, 1940) — Fielded.
- **KV-1** (USSR, 1939) — Fielded.
- **IS-3** (USSR, 1945) — Fielded.
- **IS-7 / Object 260** (USSR, 1940s) — Prototype series; not fielded.
- **Object 277** (USSR, 1950s) — Prototype.
- **Object 279** (USSR, 1950s) — Prototype.
- **Object 770** (USSR, 1950s) — Prototype.
- **T-54 / T-55** (USSR, 1940s–1950s) — Fielded.
- **T-62** (USSR, 1960s) — Fielded.
- **T-64 / Object 432** (USSR, 1960s) — Prototype then fielded.
- **T-72** (USSR, 1970s) — Fielded.
- **T-80** (USSR, 1970s) — Fielded.
- **T-90 / T-90M** (Russia, 1990s onward) — Fielded.
- **Object 187** (USSR, 1980s–1990s) — Prototype family.
- **Object 292** (USSR, 1980s–1990s) — Prototype.
- **Object 477 Molot / Boxer** (USSR / Ukraine, 1980s–1990s) — Prototype / cancelled.
- **Object 195 / T-95** (Russia, 1990s–2010s) — Prototype / cancelled.
- **Object 640 / Black Eagle** (Russia, 1990s–2000s) — Prototype / cancelled.
- **T-14 Armata** (Russia, 2010s onward) — Prototype / limited public production claims; status uncertain.
- **T-80BVM** (Russia, 2010s onward) — Fielded upgrade.
- **Stridsvagn 103 (S-tank)** (Sweden, 1960s) — Fielded.
- **Emil / KRV heavy tank project** (Sweden, 1950s) — Project / prototypes.
- **UDES XX 20** (Sweden, 1970s) — Prototype testbed.
- **Strv 2000** (Sweden, 1980s–1990s) — Concept / cancelled.
- **OF-40** (Italy, 1970s–1980s) — Limited production.
- **C1 Ariete** (Italy, 1990s) — Fielded.
- **PT-91 Twardy** (Poland, 1990s) — Fielded.
- **PT-16 / PT-17** (Poland, 2010s) — Demonstrators / proposals.
- **PL-01** (Poland, 2013) — Concept demonstrator.
- **T-84 Oplot** (Ukraine, 1990s onward) — Fielded in small numbers/export.
- **T-84-120 Yatagan** (Ukraine, 1990s) — Prototype / demonstrator.
- **South African TTD demonstrator** (South Africa, 1980s–1990s) — Prototype.
- **Olifant Mk 2** (South Africa, 2000s onward) — Fielded upgrade.
- **EE-T1 Osório** (Brazil, 1980s) — Prototype family; no production order.
- **Merkava Mk 1** (Israel, 1970s–1980s) — Fielded.
- **Merkava Mk 3** (Israel, 1990s) — Fielded.
- **Merkava Mk 4M with Trophy** (Israel, 2000s onward) — Fielded.
- **Merkava Barak / Mk 4 Barak programme** (Israel, 2020s) — Fielding status and naming varies by source.
- **Altay prototypes** (Turkey, 2000s–2020s) — Prototype / trials and early delivery stages vary by date.
- **K2 Black Panther / XK2 prototypes** (South Korea, 2000s onward) — Prototype then fielded.
- **K3 next-generation tank concept** (South Korea, 2020s) — Concept / research.
- **STB-1** (Japan, 1960s) — Prototype.
- **Type 90 / TK-X development vehicles** (Japan, 1980s–1990s) — Prototypes then fielded.
- **TK-X / Type 10 prototypes** (Japan, 2000s–2010) — Prototype then fielded.
- **Type 10** (Japan, 2010 onward) — Fielded.
- **Type 15 / ZTQ-15** (China, 2010s onward) — Fielded.
- **Type 96 / ZTZ-96** (China, 1990s onward) — Fielded.
- **Type 99 / ZTZ-99** (China, 2000s onward) — Fielded.
- **Type 99A** (China, 2010s onward) — Fielded.
- **Type 100 / next-generation Chinese tank system** (China, Publicly shown 2025) — Publicly shown prototype / details limited.
- **Arjun Mk 1** (India, 2000s onward) — Fielded.
- **Arjun Mk 1A / Mk 2 programme** (India, 2010s onward) — Development and fielding transition.
- **Future Main Battle Tank (FMBT) concept** (India, 2000s–2020s) — Concept / programme not fielded.
- **Zorawar light tank** (India, 2020s) — Prototype/trials.
- **T-34-85** (USSR, 1944 onward) — Fielded.
- **Leopard 1** (West Germany, 1960s onward) — Fielded.
- **Leopard 2A4** (Germany, 1980s) — Fielded.
- **Leopard 2A6/A7/A8 family** (Germany / operators, 2000s onward) — Fielded / variant-dependent.
- **T-72B3** (Russia, 2010s onward) — Fielded upgrade.
- **T-90M Proryv** (Russia, 2010s onward) — Fielded upgrade.
- **M1A2 SEP v2/v3/v4 development** (United States, 2000s–2020s) — Fielded / prototype upgrades.
- **M10 Booker** (United States, 2020s) — Fielded programme / current status varies.
- **Type 5 Chi-Ri** (Japan, 1940s) — Prototype.
- **O-I super-heavy tank project** (Japan, 1940s) — Concept / partial prototype evidence disputed.
- **B1 / B1 bis** (France, 1930s–1940) — Fielded.
- **T-26** (USSR, 1930s) — Fielded.
- **Bob Semple tank** (New Zealand, 1940) — Prototype / non-standard.
- **A-20 / A-32 prototypes** (USSR, 1939) — Prototype family.
- **IS-4** (USSR, 1940s) — Limited production.
- **IS-6 (Object 252/253)** (USSR, 1940s) — Prototype.
- **Object 430** (USSR, 1950s–1960s) — Prototype family.
- **Object 140** (USSR, 1950s) — Prototype.
- **Object 775** (USSR, 1960s) — Prototype.
- **Object 120 / SU-152 Taran** (USSR, 1950s–1960s) — Prototype.
- **T-14 with Afghanit APS** (Russia, 2010s onward) — Prototype / limited public status.
- **Marder / Leopard-derived MEXAS vehicles** (Germany / operators, 1990s onward) — Fielded variants.
- **Centauro II / modern wheeled gun system** (Italy, 2010s onward) — Fielded/ordered programme.

## Appendix D. Source register

- **S01 — National Academies Press (2011), Fundamentals of Lightweight Armor Systems.** [Technical review](https://www.nationalacademies.org/read/13157/chapter/4) — Primary institutional review; distinguishes metal, spaced, layered and transparent armor; notes classified gaps.
- **S02 — National Academies Press (2011), Lightweight Protective Materials.** [Technical review](https://www.nationalacademies.org/read/13157/chapter/7) — Technical review of armor ceramics and protective materials.
- **S03 — Norfolk Tank Museum, Types of Armour.** [Museum explainer](https://norfolktankmuseum.co.uk/types-of-armour/) — Museum overview of early plate, RHA, sloped, spaced, composite and bar/slat armour.
- **S04 — Canadian Tank Museum, Modern Anti-Tank Ammunition.** [Museum explainer](https://tankmuseum.ca/blog-post/modern-anti-tank-ammunition/) — Overview of kinetic and chemical anti-tank ammunition, HEAT, HESH/HEP, APFSDS and protection families.
- **S05 — US Army JPEO Armaments & Ammunition, MAS Handbook 2025.** [Official handbook](https://jpeoaa.army.mil/Portals/94/MAS/Documents/MASHandbook_2025.pdf) — Official publicly released large-calibre ammunition descriptions; specific rounds and intended roles.
- **S06 — US Army, XM1147 Advanced Multi-Purpose Round trial.** [Official news](https://www.army.mil/article/251668/soldiers_make_history_firing_experimental_tank_round_15_years_in_the_making) — Official public record of XM1147 trials and intended replacement roles.
- **S07 — KNDS, 120 mm tank ammunition.** [Manufacturer catalogue](https://knds.com/en/products/ammunition/120-mm) — Official manufacturer information for SHARD APFSDS and 120-mm ammo family.
- **S08 — Japan Ministry of Defense, Equipment introduction.** [Official government PDF](https://www.mod.go.jp/j/approach/hyouka/yosan_shikko/2018/04.pdf) — Official public references to Type 10 APFSDS, JM12A1 HEAT-MP and training ammunition.
- **S09 — Australian Defence, types of unexploded ordnance.** [Official government source](https://www.defence.gov.au/about/locations-property/unexploded-ordnance-australia/types-unexploded-ordnance) — Official source with public information on anti-tank ordnance categories; not a complete ammunition catalogue.
- **S10 — National Army Museum, Attack of the Tanks.** [Museum history](https://www.nam.ac.uk/explore/attack-tanks) — Early anti-tank weapon history and context.
- **S11 — US Army, Tank Main Gun Ammunition (1997 Weapons Systems Handbook).** [Official historical handbook](https://asc.army.mil/docs/wsh2/1997-wsh.pdf) — Historical public descriptions of M829, M830, M830A1, STAFF and TERM-KE programs.
- **S12 — US Army, M830A1 portfolio description.** [Official portfolio PDF](https://jpeoaa.army.mil/Portals/94/Documents/JPEOAAPortfolioBook_2025.pdf) — Official public description of the 120-mm M830A1 cartridge.
- **S13 — AUSA, Anti-Tank Guided Missile problem set.** [Professional association analysis](https://www.ausa.org/publications/ode-sagger-drill-addressing-modern-anti-tank-guided-missile-problem-set) — Open-source overview of widely used ATGM families.
- **S14 — British Army, Challenger 2.** [Official government source](https://www.army.mod.uk/learn-and-explore/equipment/combat-vehicles/challenger-2/) — Official public description including Dorchester armour designation and service history.
- **S15 — British Army, Challenger 3.** [Official government source](https://www.army.mod.uk/learn-and-explore/equipment/combat-vehicles/challenger-3) — Official current public description of prototype programme, modular armour and APS.
- **S16 — UK Ministry of Defence, Challenger 3 production milestone.** [Official government news](https://www.gov.uk/government/news/uks-most-lethal-tank-rolls-off-the-production-lines) — Official 2024 announcement confirming prototype vehicles.
- **S17 — The Tank Museum, Chieftain and Chieftain 900.** [Museum collection](https://tankmuseum.org/tank-nuts/tank-collection/chieftain/) — Public museum history for Stillbrew, Chieftain 900 and Chieftain variants.
- **S18 — The Tank Museum, Experimental WWI Tanks.** [Museum history](https://tankmuseum.org/article/experimental-tanks-part-one/) — Museum article explaining the ambiguity of experimental/proposed tank designations.
- **S19 — Military Factory, Experimental Tanks & Fighting Vehicles.** [Secondary reference catalogue](https://www.militaryfactory.com/armor/x-tanks-prototype-vehicles.php) — Broad starting index of prototype and experimental AFVs; individual entries need cross-checking.
- **S20 — GlobalSecurity, Object 195 / T-95.** [Secondary reference](https://www.globalsecurity.org/military/world/russia/object-195.htm) — Open-source overview of Object 195; some details remain uncertain.
- **S21 — Australian Armour & Artillery Museum, Exhibits.** [Museum collection](https://www.ausarmour.com/exhibits/) — Vehicle collection examples and categories.
- **S22 — Elbit Systems, Iron Fist APS announcement.** [Manufacturer release](https://www.elbitsystems.com/news/elbit-systems-awarded-228-million-follow-contract-provide-iron-fist-aps-us-army-bradley-ifv) — Manufacturer describes Iron Fist as hard-kill active protection.
- **S23 — Frontiers, Depleted uranium munitions and Ukraine war.** [Peer-reviewed commentary/review](https://www.frontiersin.org/journals/political-science/articles/10.3389/fpos.2024.1387183/full) — Secondary academic review naming several tank ammunition series; cross-check designations.
- **S24 — Royal Armouries / general tank history.** [Reference collection](https://www.royalarmouries.org/) — Institutional collection portal; use for contextual object verification.
- **S25 — Tank Museum, Churchill / Black Prince collection.** [Museum collection](https://tankmuseum.org/tank-nuts/tank-collection/churchill-iv/?country=all&era=WW2&tname=&tpage=2) — Museum page documents Black Prince prototypes and Churchill variants.
- **S26 — UK Desider, May 2024 Challenger 3 update.** [Official defence publication](https://assets.publishing.service.gov.uk/media/665ddb527b792ffff71a866e/desider_issue_188__May_2024.pdf) — Official report of prototype completion and trial programmes.
- **S27 — US Army, M3 37-mm anti-tank gun.** [Official Army history](https://www.army.mil/article-amp/220948/ria_self_guided_tour_m3a1_3mm_anti_tank_gun) — Official historical source on early US anti-tank gun service.
- **S28 — Forecast International, Tank Gun Ammunition acronym list.** [Industry reference](https://www.forecastinternational.com/archive/disp_pdf.cfm?DACH_RECNO=1609) — Acronym definitions including APDS, APFSDS, HEAT, HEP, MPAT and training types.
- **S29 — Rheinmetall, ammunition portfolio.** [Manufacturer site](https://www.rheinmetall.com/en/products/weapon-ammunition) — Manufacturer portal for publicly disclosed German/NATO ammunition families.
- **S30 — Rafael, Trophy Active Protection System.** [Manufacturer site](https://www.rafael.co.il/system/trophy-aps/) — Manufacturer portal for Trophy APS; exact performance details intentionally not reproduced.
- **S31 — US Army eARMOR, Abrams lethality and ammunition.** [Official professional journal](https://www.benning.army.mil/armor/eARMOR/content/issues/2014/JAN_FEB/Brown.html) — Open professional discussion of M829A4 and AMP programme.
- **S32 — US National Academies, ballistic armour materials review.** [Technical review](https://www.nationalacademies.org/read/12837) — Technical discussion of ceramic/fibre/metal backing as a combined system.
- **S33 — Wikipedia, armour and tank project reference pages.** [Secondary encyclopedic index](https://en.wikipedia.org/) — Used only as an entry point for open designations where official information is absent; not sufficient for engineering calibration.