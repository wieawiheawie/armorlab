# Test report (environment: Node v22, Linux, JS engine; Chromium/Playwright 1.56 headless swiftshader)

## `npm test` (node --test tests/physics.test.js): 15 / 15 PASS
GEO-01..04 (thickness, slope conventions, LOS 101.25 / 233.36 mm, rotated-body perpendicular thickness exact, horizontal path within 6 %), PROJ-01..03 / PAIR-01, RESET-01 (bit-identical rebuild), NUM-01 (momentum 1e-10; isolated contact KE within 1 %), NUM-02 (net force ≈ 0), NUM-03/04 (ledger terms sum; max residual jump <1 %/sample; residual shrinks with dt), FRA-01/02, OUT-01 (source scan + state-only classify), support-condition comparison, Rust/JS preset consistency, BUILD-01 (assets embedded, no external refs; **WASM not embedded**).
A first run failed NUM-01 due to a test bug (particle rebounding into the plate); test fixed, not the solver. The energy-ledger bug (≈9 % gain) was a real solver bookkeeping fault, fixed.
`cargo test`: NOT RUN.

## BUILD-02 smoke (file://, all network requests intercepted): PASS — 0 requests, 0 page errors, WebGL render, fire runs, ledger residual ~0.3 %. Screenshots verified discrete discs at high zoom, merged dots when zoomed out.
UI-01: physics is time-sliced (12 ms budget/frame) on the main thread; no worker; responsiveness only observed in headless run at 18k, not measured formally.

## Convergence (600 µs, clamped ends, kinetic-only, idealised muzzle-speed impact) — docs/results/convergence.json
Tiger I: n=2.4k/5.1k/10.2k/18.2k → projectile centroid vx 413/423/444/441 m/s; depth 276/300/307/315 mm; plastic fraction 0.48/0.47/0.45/0.44; residual 0.5–0.8 %; fragment count 38/66/75/173 (NOT converged). Velocity & energy split roughly converge (~1 % 10k→18k); depth still drifting ~2.5 %. 
Tiger II: 4.9k/10.2k/17.9k → vx 220/222/226 m/s, projectile mass behind rear face ~5.5 %, depth 205/209/216 mm; fragments 157/332/484 (not converged).
Resulting outcomes (Tiger I: perforation; Tiger II: partial perforation) come from untuned-to-data provisional materials; NOT validated against historical results. 100k+ tiers not run to completion (cost), so convergence beyond 18k is untested.

## Benchmark (JS engine, 1 thread, first 5–200 steps; 5k/18k contended by a concurrent job) — docs/results/benchmark.json
| particles | bonds | build s | ms/step | dt ns | wall s per sim µs | RSS MB |
|---|---|---|---|---|---|---|
| 5,078 | 19.6k | 0.1 | 4.9 | 197 | 0.025 | 56 |
| 18,232 | 71.6k | 0.15 | 15.0 | 104 | 0.144 | 79 |
| 100,502 | 399k | 0.8 | 77.7 | 44 | 1.75 | 137 |
| 251,104 | 999k | 1.6 | 183 | 28 | 6.5 | 304 |
| 499,944 | 1.99M | 2.2 | 382 | 20 | 19.2 | 309 |
| 998,956 | 3.99M | 4.1 | 744 | 14 | 52.9 | 556 |
No allocation failures; but 1M is not interactive and was not run through an impact.
