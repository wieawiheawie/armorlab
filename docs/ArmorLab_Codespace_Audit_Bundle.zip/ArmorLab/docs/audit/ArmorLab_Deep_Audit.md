# ArmorLab — Deep Source Audit

**Audited artifact:** `ArmorLab_Optimized.zip`  
**Audit date:** 24 October 2026  
**Scope:** source, tests, WASM adapter, worker/runner, build/release pipeline, benchmark evidence, memory/performance and physical-model validity.  
**Integrity note:** the uploaded ZIP was extracted to a temporary audit folder; the original uploaded ZIP and its source contents were not modified.

## Executive assessment

This is a meaningful optimization checkpoint: the delivered HTML embeds a Rust/WebAssembly payload, simulation work runs through a worker-based design by default, the code uses typed arrays and an optimized WebGL renderer, and the included JavaScript tests exercise several real numerical invariants. `npm test` passes 25 tests and skips one source-WASM parity test because the raw compiled `.wasm` file is not included in the archive. The embedded-WASM worker smoke passes in Node.

It is **not yet release-safe or proven to run well on low-end devices**. The most serious issue is the build fallback: a normal build in an environment without Cargo overwrites the working embedded-WASM HTML with a JavaScript-only file. There are also adapter correctness issues (expensive `time` getter, missing `steps`, signed hash reconstruction), an overly large dense grid memory ceiling, incomplete browser testing, weak test assertions, and documentation contradictions.

The reported optimization benchmark shows about **1.98× solver-only speedup at ~1 million particles**, but this remains about **105 ms per step** at median on the report single-core test host. With the reported ~14.05 ns timestep, a 600 µs simulated impact implies approximately 42,700 steps or around 75 minutes of solver time at the median step cost, excluding full runner/UI costs. Therefore “one million particles” currently means a buildable experimental tier, not an interactive tier. These are extrapolations from the included benchmark, not a full measured one-million-particle run.

### Overall status

- **Build integrity:** Needs fix before safe release.
- **Optimization direction:** Promising and mostly sensible.
- **WASM execution:** Embedded binary works in the Node worker harness; fresh source build could not be reproduced in this audit container because Cargo is absent.
- **Testing:** 25 pass, 0 fail, 1 skip; browser test script fails in this environment due a hard-coded Playwright path.
- **Performance:** Measurable improvement in the included benchmark, but million-element impacts remain impractical.
- **Physical accuracy:** Exploratory qualitative 2D model; not validated as a 1:1 historical ballistic simulator.

## What I ran

From the extracted project root:

1. `npm test` — **26 total; 25 passed, 0 failed, 1 skipped**. `OPT-11` was skipped because `target/wasm32-unknown-unknown/release/armorlab_core.wasm` is absent from the ZIP.
2. `npm run smoke` — **passed**. Output identifies the embedded backend as WASM and shows `ready`, `built`, snapshots, stats and `done` messages in a Node worker-thread harness.
3. `npm run build:release` — **failed in this environment** with `BUILD FAILED: cargo not found`. The archive does include a prebuilt WASM embedded in `dist/ArmorLab.html`, but it does not include the corresponding raw target artifact or a local Cargo installation.
4. `node scripts/smoke.js` — **failed before launch** because the script requires `/home/claude/.npm-global/lib/node_modules/playwright`, which is not available here and is not declared in `package.json`.
5. Reproduced the default-build downgrade in a disposable scratch copy: before build, HTML banner was `Rust/WASM (64 KiB) + labelled JS fallback`; after `node scripts/build.js` without Cargo, it became `JS-ONLY (compatibility build; no WASM)` and the embedded WASM payload was absent. The original extracted source used for the audit was not overwritten by this reproduction.
6. Inspected the source-level benchmark report and raw results supplied in the ZIP. The benchmark numbers below are **reported in the ZIP, not independently rerun by this audit**.
7. A real browser `file://` + WebGL test remains **unverified**. The Node worker smoke verifies bundled JS/WASM worker protocol, but not browser WebGL, pointer input, browser-specific Blob Worker behavior or context loss.

## Performance numbers in the included optimization report

Values below are copied from `docs/OPTIMIZATION_REPORT.md`. Trials were on a shared one-core Intel Xeon 2.1 GHz / 3.9 GB environment with Node v22.22.2 and Rust 1.75.0 in the original report. The report explicitly notes a 10–40% run-to-run spread, so compare only variants from the same run and avoid treating them as portable device guarantees.

| Actual particles | Engine | Median ms/step | Reported speedup vs baseline | Peak RSS | Reported timestep | Estimated 600 µs solver time |
|---:|---|---:|---:|---:|---:|---:|
| 5,078 | baseline JS | 1.639 | 1.00× | 58 MB | 197 ns | ~5.0 s |
| 5,078 | Rust/WASM | 0.643 | 2.55× | 63 MB | 197 ns | ~2.0 s |
| 18,232 | baseline JS | 3.885 | 1.00× | 79 MB | 104 ns | ~22 s |
| 18,232 | Rust/WASM | 2.307 | 1.68× | 65 MB | 104 ns | ~13 s |
| 100,502 | baseline JS | 21.922 | 1.00× | 144 MB | 44 ns | ~5.0 min |
| 100,502 | Rust/WASM | 9.121 | 2.40× | 94 MB | 44 ns | ~2.7 min |
| 251,104 | baseline JS | 58.798 | 1.00× | 226 MB | 28 ns | ~20.6 min |
| 251,104 | Rust/WASM | 25.160 | 2.34× | 153 MB | 28 ns | ~8.8 min |
| 998,956 | baseline JS | 208.399 | 1.00× | 522 MB | 14.05 ns | ~2.48 h |
| 998,956 | Rust/WASM | 105.137 | 1.98× | 446 MB | 14.05 ns | ~74.6 min |

Estimated runtime is `600 µs / timestep × median ms per step` and is solver-only. It does not include full runner time getters, snapshot copies, browser rendering, transfer overhead or slower/limited hardware. The included report original older measurements differ from the newer run, which further reinforces the need for paired, reproducible benchmark conditions.

## High-priority findings

### P0 — Protect release build integrity

`scripts/build.js` removes the existing target `.wasm` before checking whether Cargo exists (`:14`). If Cargo is missing and `--require-wasm` is not used, the script continues in JS-only fallback mode (`:15-21`) and overwrites `dist/ArmorLab.html` (`:33`). This exact downgrade was reproduced in a scratch copy. The safe behavior is: never remove the currently valid payload before a new build succeeds, make release builds require WASM, and write to a temporary output before atomically replacing the artifact. JS-only mode should be an explicit development command only.

### P1 — Fix WASM adapter contracts

- `web/engine_wasm.js:15` implements `time` by calling `stats(0)`. In `src/sim.rs:702-710`, `stats_level(0)` still scans every element for kinetic energy/max speed; then `:737-755` scan plate and projectile observables. Runner `web/runner.js:63,87,90` reads `s.time` from snapshot/tick/completion paths. This can inject multiple O(N) scans into the hot loop and makes solver-only benchmark figures optimistic for end-to-end use. Add `al_time()` and `al_steps()` scalar exports.
- `web/engine_wasm.js` has no `steps` getter, although `web/runner.js:63` reads `s.steps`; snapshots can report undefined step counts in WASM mode.
- `web/engine_wasm.js:30` joins 32-bit hash halves via `BigInt` without unsigned normalization. Normalize each half with `>>> 0` before converting to `BigInt`; test high-bit-set halves explicitly.

### P1 — Bound grid memory and fail safely

`src/sim.rs:320-324` allocates two dense `u32` arrays based on the full rectangular grid. At the `64M`-cell limit (`:348`), those arrays alone can consume around 512 MiB; more state arrays, particles, allocator overhead and browser memory are additional. A small number of fragments far from the main target can expand the bounding box into a sparse rectangle. Replace or supplement this with a sparse/tiled hash grid or a strict byte budget derived from actual device tier. Return a controlled error rather than panic/trap.

### P1 — Repair false-green test coverage

`tests/optimization.test.js:26` includes `assert.ok(Math.abs(s.fx[b]) < 1e-9 || true)`, which always passes. Remove the tautology and assert a specific physics invariant. `OPT-11` is skipped when the compiled WASM target is absent, meaning the ordinary `npm test` result does not validate source-compiled WASM. Add a release verification path that compiles Rust, runs `cargo test`, checks the adapter contract, and executes parity against the freshly built `.wasm`.

### P1 — Make browser smoke portable and real

`npm run smoke` is a Node worker-thread test, not a browser test. The separate `scripts/smoke.js` fails here because it requires a hard-coded Playwright installation path. Add a reproducible local browser test dependency (or make the script resolve a declared dependency via `require.resolve`), then test actual `file://` loading, Blob Worker startup, WASM activation, WebGL drawing, fire/reset, resizing and input. Until then browser rendering is not verified.

### P1 — Fix stale / contradictory status documentation

`README.md` and `docs/TEST_REPORT.md` still claim that Rust was never compiled, that the shipped HTML has no WASM, and that the JS engine runs the delivered artifact. The included `docs/OPTIMIZATION_REPORT.md` and embedded HTML describe a later WASM build. This is dangerous for future work. Regenerate the verification report from one source of truth and include artifact hash, WASM size, toolchain version, build ID, tests and actual browser-test status.

### P1 — Do not overstate million-particle support

The included result reports median WASM solver time around 105 ms per step at 998,956 particles, with ~446 MB peak RSS and a timestep of 14.05 ns. A 600 µs simulation is about 42,700 steps and ~75 minutes of solver-only time. This is a valid offline research tier, but not real-time or “runs on anything”. Define a small default quality tier and disclose the measured simulation estimate.

## Medium-priority findings

- **Telemetry is still O(N).** Level-zero stats avoids the bond scan and connected-components calculation, but still traverses particle velocities and target/projectile state. Do not call it constant time; combine with scalar getters and less frequent sampled stats.
- **Energy ledger freshness is ambiguous.** Current kinetic energy is combined with cached elastic/contact terms and plastic/fracture work. The UI needs to show the time/step of each cached full ledger. Conservation checks should compare coherent snapshots and account for external work/dissipation.
- **Benchmarks omit end-to-end work.** The benchmark reports `run(k)` step time and CPU render-fill time. It does not include the full Runner time getter, snapshot array copies, worker messages, GPU upload/draw, or browser main-thread long tasks. Add separate solver-only and end-to-end rows.
- **Benchmark reproducibility is limited.** The report notes 10–40% run-to-run spread and a large difference from the older baseline. Preserve raw samples and paired-run metadata; report median and quantiles on the same host.
- **Render snapshots can still cost memory bandwidth.** WASM data lives in linear memory; the runner copies positions/damage/speed into transferable arrays. The copies may be necessary at the worker boundary, but pool and minimize them; benchmark in a browser.
- **Worker RPC can hang after boot.** `web/host.js:18-25,33-38` has a boot timeout but `_rpc` has no timeout/reject path after boot. An init error can leave startup unresolved. Revoke the Blob URL and reject all pending requests on worker error/termination.
- **Outcome labels are heuristics.** Raw mass behind a rear-plane calculation in `src/sim.rs:742-755` is useful telemetry, but a threshold-based “perforation” label is not an experimentally validated ballistic result. Display raw observables and ambiguity; validate against matched experiments.
- **Contact model needs patch tests.** If contact repulsion acts on bonded neighbours at the same time as bond forces, their compressive responses may be double-counted unless the model intentionally combines them. Add controlled force-displacement and energy tests for bonded compression, separated contact and broken-bond overlap.
- **WASM/JS parity gate is narrow.** `web/runner.js:42-48` checks a 2,000-particle Tiger I case for 60 steps, counts and six scalar stats at `1e-6` relative tolerance. It doesn't cover late fracture, all presets, all state arrays, hash, escaped fragments, or long runs. Keep the cheap startup probe, but add broader offline regression cases.
- **Point rendering has device-specific semantics.** WebGL point size is limited by GPU caps; a minimum size clamp can make low-zoom circles appear too large and shapes may differ by driver. Query limits once, test representative devices, and supply an instanced-quad fallback if required.
- **Artifact provenance is weak.** The generated HTML embeds WASM, but the package does not provide a verified artifact hash/manifest tied to build inputs. Store the WASM SHA-256, output hash, rustc version, target, build date and tested command in release metadata.

## Physical accuracy: do not confuse numerical parity with validation

The project’s 2D bond/lattice solver can be valuable for visual and qualitative material experimentation, but the audit found no evidence that its Tiger I/Tiger II and PzGr combinations have been calibrated and independently validated against matching historical ballistic experiments. A JS-to-WASM parity test says two implementations produce similar numbers; it does **not** prove those numbers describe real armour.

The present formulation uses a discrete bond/lattice representation and provisional material parameters. This class of model has constitutive limitations; published work on bond-based peridynamics discusses Poisson-ratio restrictions and model formulation choices (see Guan & Guo, 2024, https://doi.org/10.1016/j.apm.2024.01.015). Do not assert that ArmorLab is a full peridynamic implementation unless its exact equations and assumptions support that name. Label historical outcomes as model predictions / reconstructions until validated against relevant experiments.

## Recommended order of fixes

1. **P0:** make `npm run build` unable to destroy a valid WASM artifact; require WASM for release builds.
2. **P1:** add O(1) time/step accessors, fix unsigned hash halves, add adapter contract tests.
3. **P1:** replace the tautological test and require raw-WASM test execution in the release workflow.
4. **P1:** add robust grid-memory budgeting / sparse grid fallback and graceful simulation errors.
5. **P1:** make browser `file://` smoke reproducible and validate actual UI/WebGL.
6. **P1:** reconcile README / TEST_REPORT / optimization report and add build provenance.
7. **P2:** benchmark whole runner + browser render path; optimize the measured hot path rather than only `run(k)`.
8. **P2:** add energy-ledger freshness, contact patch tests, long-run and all-preset parity tests.
9. **P3:** profile point-size and lower-end GPU behavior, then consider a rendering fallback.
10. **Separate science pass:** create a validation dataset and calibrate/validate physics independently of performance optimization.

## External engineering references

- MDN, WebGL best practices: https://developer.mozilla.org/en-US/docs/Web/API/WebGL_API/WebGL_best_practices — batching, reusable state, memory/VRAM budgets, device limits, and avoiding blocking GPU calls.
- MDN, Using Web Workers: https://developer.mozilla.org/en-US/docs/Web/API/Web_Workers_API/Using_web_workers — moving expensive computation off the main thread and transferable buffers.
- MDN, Transferable objects: https://developer.mozilla.org/en-US/docs/Web/API/Web_Workers_API/Transferable_objects — ownership transfer can avoid copying large ArrayBuffers across worker boundaries.
- Guan & Guo (2024), *A unified bond-based peridynamic model without limitation of Poisson's ratio*: https://doi.org/10.1016/j.apm.2024.01.015 — formulation-specific limitations/research in bond-based models.

## Bottom line

This ZIP represents real progress: worker execution, a bundled WASM artifact, typed-array state, better contact/render paths and useful regression tests. The most urgent issue is release build integrity, followed by the WASM adapter’s O(N) time getter / missing step getter and hash signedness. The optimization report benchmark supports roughly 2× solver speedup at one million particles on its test host, but not practical real-time one-million-particle operation. Fix the release pipeline and adapter contract first, then repeat end-to-end benchmarks and browser verification before expanding features.
