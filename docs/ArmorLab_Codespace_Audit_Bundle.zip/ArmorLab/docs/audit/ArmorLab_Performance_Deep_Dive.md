# ArmorLab Performance Deep Dive — Source Audit and Optimization Plan

**Audited:** 24 October 2026  
**Source examined:** uploaded `ArmorLab (1).zip` (41 archive entries; project folder `ArmorLab/`)  
**Purpose:** determine why the current 2D particle-impact simulator does not scale to low-end devices and define a practical, testable path to make it broadly usable without secretly changing the physics.

## Executive conclusion

ArmorLab already has a sensible prototype foundation: a compact numerical engine, typed arrays in the JavaScript reference implementation, a uniform spatial grid for contact, a WebGL point renderer, a Rust core intended to mirror the JavaScript code, a standalone HTML bundler, and 15 passing JavaScript physics tests.

But the current version is **not yet a “runs on anything” simulator**. Its largest obstacle is not the UI theme or a missing compiler flag. It is the cost of a uniform, explicit, high-stiffness particle lattice: every timestep processes millions of bonds, the stable timestep becomes smaller as spatial resolution increases, expensive diagnostics rescan the full state, and the UI runs synchronous simulation work on the main thread.

The uploaded ZIP's existing report estimates a one-million-particle run at about 0.74 seconds per timestep. My fresh Node measurements of the same source showed about 0.342 seconds per timestep for 998,956 particles. Both values imply hours for a 600-microsecond simulated impact; the discrepancy also demonstrates that the present benchmark is not yet repeatable enough to support fine-grained speed claims. The current code must be optimized at several levels, not just compiled to WASM.

**Recommendation:** implement a staged, data-driven performance plan. First remove avoidable CPU, allocation, rendering, and UI costs; then measure the Rust/WASM engine on a real toolchain; finally add selectable resolution tiers and a carefully validated coarse/fine simulation strategy around the impact zone. Do not promise one million *fully physical* particles at interactive speed on low-end devices until that exact configuration has been benchmarked on those devices.

---

## 1. What is in the uploaded ZIP

| Area | Current implementation | Notes |
|---|---|---|
| `src/sim.rs` | Rust explicit 2D bonded-particle/spring-lattice solver | 645 lines. Rust code in this ZIP has not been compiled or tested in the current audit environment because `cargo` and `rustc` are absent. |
| `src/lib.rs` | Hand-written C ABI exports for one global `Sim` | Avoids `wasm-bindgen`; exposes state/render buffers through pointers. Must be validated after the first actual WASM build. |
| `web/engine_js.js` | JavaScript mirror/reference solver using typed arrays | This is the active runtime in the checked-in HTML because no WASM binary is present. All JS tests target this engine. |
| `web/engine_wasm.js` | Thin adapter for the Rust/WASM exports | Unverified in this environment. |
| `web/render.js` | WebGL point-sprite renderer | One point per solver particle; uploads four attribute arrays each render. |
| `web/app.js` | Main-thread UI, stepping loop, stats panel, selection and camera | Physics and expensive stats are synchronous on the UI thread. |
| `scripts/build.js` | Inlines HTML/CSS/JS/presets and embeds WASM if available | Silently falls back to JS-only output if the Rust toolchain/build is missing. It prints a warning but still produces `dist/ArmorLab.html`. |
| `tests/physics.test.js` | JavaScript physics and packaging tests | 15 tests passed in this audit. They do not prove Rust/JS numerical parity, and they do not prove the WASM build compiles. |
| `tests/physics.rs` | Rust tests | Not run: no Rust toolchain in audit environment. |
| `scripts/bench.js` | JS benchmark tiers through one million particles | Uses `Date.now()` and only 5 timed steps at the largest tier. This produces noisy estimates. |
| `docs/results/` | Historical benchmark and convergence records | Useful evidence, but the performance observations vary across runs and need a repeatable harness. |
| `dist/ArmorLab.html` | 42 KiB standalone HTML | Rebuilt during audit as JS-only because `cargo` is unavailable. `ARMORLAB_WASM_B64=null` is embedded; this file is not a Rust/WASM performance build. |

### Environment and tests actually executed

- Node.js `v22.16.0`; npm `10.9.2`.
- `npm test`: **15 passed, 0 failed**.
- `npm run build`: completed, but warned that no WASM was produced and generated a **JS-only** HTML.
- `cargo` / `rustc`: unavailable, so neither `cargo test` nor `cargo build --target wasm32-unknown-unknown` could be verified.
- Browser smoke testing was not re-run in this audit environment because the project's smoke script expects Playwright at an absolute path that is not installed here. The ZIP's `TEST_REPORT.md` claims an earlier `file://` smoke test passed, but that is a supplied prior result, not a fresh independent verification.

---

## 2. How much work the solver really does

### The main step

In `web/engine_js.js`, `Sim.step()`:

1. Updates positions and half-step velocities for each free particle.
2. Calls `computeForces()`.
3. `computeForces()` clears force arrays and loops across the full bond list. It checks each intact bond, computes distance/square root, evaluates fracture/plasticity, and applies equal/opposite forces to endpoints.
4. It calls `_contact(false)`, which rebuilds the spatial grid and searches nearby cells for overlapping pairs.
5. It finishes the velocity-Verlet update and advances time.

The spatial grid avoids an all-pairs O(N²) contact search in ordinary cases, which is good. The cost still grows with the number of particles/bonds, and every explicit timestep is required to resolve the stiffest interactions. As the mesh becomes finer, timestep count also rises.

### The scaling trap

For this lattice, particle mass scales approximately with spacing squared (`m ∝ h²`) while the spring stiffness is proportional to the chosen material stiffness and out-of-plane depth. The stability formula in the current model therefore makes the allowed timestep scale approximately with particle spacing (`dt ∝ h`). For a fixed physical simulation duration:

- particle count grows approximately as `N ∝ 1/h²`;
- required timesteps grow approximately as `1/dt ∝ 1/h ∝ √N`;
- work per step is approximately O(N + B), with `B` bonds roughly proportional to N;
- total work consequently trends towards **O(N^1.5)** for a geometrically similar uniform-resolution model.

That is why reducing particles from one million to 18,000 is not a small detail setting: it cuts both bond count and the number of required timesteps.

At the recorded one-million tier there are 998,956 particles and 3,985,869 bonds. With a 14.05 ns timestep, a 600 µs run requires about 42,700 steps. At the fresh measured 341.874 ms/step, that projects to about **4.06 hours**. This is an extrapolation from a short benchmark, not a measured full-run time, but the scale of the problem is unambiguous.

---

## 3. Measurements reproduced from the current source

I ran a short warm-up and then timed eight steps for each larger tier using `process.hrtime.bigint()` in Node, outside a browser. The 5k tier comes from the current quick benchmark. These are machine/environment-specific microbenchmarks, not browser-wide guarantees. RSS below is a process snapshot, not a measured peak on all devices.

| Target tier | Actual particles | Bonds | Build time | Measured ms/step | Timestep | Estimated wall time for 600 µs simulated time | RSS snapshot |
|---:|---:|---:|---:|---:|---:|---:|---:|
| 5k | 5,078 | 19,607 | 0.08 s | 1.98 ms | 197 ns | ~6 s | ~35 MB |
| 18k | 18,232 | 71,585 | 0.168 s | 5.934 ms | 103.98 ns | ~34 s | ~50 MB |
| 100k | 100,502 | 398,852 | 0.612 s | 27.923 ms | 44.33 ns | ~6.3 min | ~139 MB |
| 250k | 251,104 | 999,428 | 1.296 s | 67.578 ms | 28.03 ns | ~24 min | ~217 MB |
| 500k | 499,944 | 1,992,735 | 2.742 s | 163.823 ms | 19.86 ns | ~1.37 h | ~215 MB |
| 1M | 998,956 | 3,985,869 | 3.773 s | 341.874 ms | 14.05 ns | ~4.06 h | ~392 MB |

**Benchmark caveats:** measurements at 250k, 500k, and 1M are short samples, with eight timed steps after two warm-up steps. The earlier JSON bundled in the ZIP reports different timings (including 743.6 ms/step at one million). `scripts/bench.js` uses millisecond-resolution `Date.now()` and only five steps at the largest sizes; timing can vary heavily with CPU contention, garbage collection, thermal state and browser engine. Do not use the numbers to claim a precise expected speedup. Replace the benchmark harness before comparing optimizations.

### Memory pressure is also real

The JS engine initially builds many arrays (`X`, `Y`, `M`, `F`, bond lists) using ordinary JavaScript arrays, then copies them into typed arrays. At high N, both the boxed-number arrays and the typed arrays can exist at once. This increases peak memory and garbage collection pressure. The 1M test has a post-construction RSS snapshot around 392 MB in the fresh process; peak memory can be higher during construction. Low-end devices can fail at construction even before they attempt a long simulation.

---

## 4. The highest-impact code-specific problems

### P0-A — The “12 ms frame budget” is not a real upper bound

`web/app.js` lines 36–51 sets a 12 ms budget, but each while-loop iteration calls `st.sim.run(k)` where `k` can be 8. The time budget is only checked after the synchronous chunk returns. At 100k+ particles, eight steps are hundreds of milliseconds; at one million, the current timing implies about 2.7 seconds per eight-step chunk. The browser cannot handle pointer input, redraw the UI, or render new frames while that JavaScript task is running. Browser guidance describes uninterrupted main-thread tasks of 50 ms or more as long tasks that harm responsiveness.

**Fix:** run the solver in a Web Worker and leave DOM controls/render orchestration on the main thread. Do not require `SharedArrayBuffer` for the basic build. A single-threaded worker still protects interaction responsiveness even if raw simulation speed is unchanged. In a fallback main-thread mode, run only very small bounded batches at very low particle counts.

### P0-B — The statistics panel repeatedly recomputes expensive global data

`app.js` calls `refresh()` roughly every 150 ms. `refresh()` calls `s.stats()`. In `engine_js.js` `stats()` scans particles and all bonds for energy, calls contact-energy computation (which rebuilds the grid and scans potential contacts), then calls `_components()`. `_components()` allocates new union-find arrays and scans every bond to reconstruct connected components/fragments.

That expensive analysis is presentation work, not the core integration step. At large N it can itself cause long stalls and compete with the solver.

**Fix:** split statistics into tiers:

- **Fast telemetry** every 100–250 ms: time, step count, already maintained counters, coarse kinetic summaries if updated incrementally.
- **Energy ledger** at a slower cadence (e.g., 1–4 Hz), on pause, or on explicit request; maintain incremental terms only when the bookkeeping is mathematically valid.
- **Fragment connected-components analysis** only after a meaningful fracture event on a controlled schedule, on pause, or at the end—not every routine UI refresh.
- Cache snapshots so UI redraws do not trigger repeated full physics scans.

### P0-C — Rust/WASM has not been proven to be the active engine

The build script correctly warns when Cargo is missing, but it still writes a file named `ArmorLab.html`. The current build says `JS-only` and contains `ARMORLAB_WASM_B64=null`. That is fine as a compatibility fallback, but users can easily mistake it for the intended optimized Rust build.

**Fix:** keep a JS fallback for compatibility, but add a strict release target such as `npm run build:wasm:required` that fails if the Rust target cannot build or the output HTML does not contain a real WASM payload. CI should install Rust, add `wasm32-unknown-unknown`, compile, run `cargo test`, and compare a small set of deterministic solver fixtures between Rust and JS. Never silently mark a JS-only build as a performance build.

### P0-D — Broken bonds are checked forever

The force loop skips a broken bond with `if (bbroken[b]) continue`, but every broken bond remains in the full list and is inspected on every future timestep. In the supplied convergence report, around 14–23% of bonds are broken by the end of runs; that fraction still costs a loop check indefinitely.

**Fix:** keep stable bond IDs and a full diagnostic record, but maintain a compact active-bond index list for force integration. Remove a bond from the active list when it breaks. Do not rebuild/compact every frame; update on breakage or compact when the inactive fraction crosses a threshold. Regression-test fracture energy and all bond counters.

### P1-A — Contact broadphase is rebuilt every force evaluation

`_contact(false)` always rebuilds the full spatial grid, and `stats()` triggers another rebuild for contact energy. The current hashed/cell grid is an appropriate baseline, but rebuilding all cell memberships for every tiny explicit timestep is a major N-scale cost.

**Fix candidate:** use a Verlet-style contact candidate list with a small skin distance. Rebuild candidates only after any particle moves more than half the skin since the last rebuild. The list must use a cutoff large enough to include all contacts that can become active before the next rebuild. Test fast projectiles/fragments carefully so no collisions are missed. A second option is a faster compact-cell build with persistent scratch arrays; benchmark both.

**Important edge case:** the spatial grid domain is established from initial coordinates. `_rebuildGrid()` clamps any particle that moves outside the original grid to the boundary cells. If many escaping fragments accumulate outside the bounds, they are placed into the same edge bins and local pair loops can become very expensive and contact discovery can be wrong. Add a documented grow/rebase policy when particles approach boundaries; do not silently clamp escaped particles into edge bins.

### P1-B — Bond-list construction creates large temporary JS arrays

`_buildBonds()` pushes into seven ordinary JS arrays (`bi`, `bj`, `bk`, `bl0`, `bl`, `bm`, plus plastic/damage arrays) and then copies them into typed arrays. At ~4 million bonds this creates significant transient memory.

**Fix:** perform a two-pass build (count neighbors first, allocate exact `TypedArray`s, then fill) or use a measured capacity-growth policy. The two-pass route performs neighborhood discovery twice during construction but can substantially reduce peak heap usage and garbage collection. Apply the same idea to particle positions/material flags: pre-count or estimate exact capacity and fill typed arrays directly, duplicating only the state actually needed for reset and diagnostics.

### P1-C — Rendering copies and uploads all particle attributes every frame

`fillRender()` loops all particles every frame, copies x/y to `Float32Array`, copies material and damage values, and computes `Math.hypot(vx, vy)` for every particle even when the velocity view is not selected. `render.js` then calls `gl.bufferData()` on four separate buffers every frame. At one million particles, the four streams represent about 20 MB of attribute data per frame (8 MB positions plus three ~4 MB float arrays), or about 1.2 GB/s of raw upload payload at 60 Hz before implementation overhead.

**Fix:**

1. Store static material/fixed attributes in static GPU buffers; they do not need a per-frame upload.
2. Only compute/upload speed data when the velocity visualisation is selected.
3. Make damage data dirty only when bond-break counters change, or update it at a lower cadence.
4. Reuse GPU buffer storage and update through `bufferSubData` (or a benchmarked orphan/double-buffer strategy) instead of creating/respecifying all four streams each draw.
5. Consider one interleaved or fewer dynamic buffers to reduce API calls, then benchmark; fewer buffers are not automatically faster in every browser.
6. Keep the existing equal-size-particle rendering contract at high zoom. At low zoom, use a deliberate density/coverage representation without changing the physics state or pretending that added display points are physical particles.

MDN's WebGL guidance and Emscripten's WebGL performance notes support reducing state churn, avoiding repeated resource allocation, reusing buffers, and considering interleaved vertex data. Test on real browsers before selecting the exact buffer strategy.

### P1-D — Particle picking is O(N)

Pointer-up selection scans all particle positions to find the nearest particle. At one million particles this is another million distance calculations for a single click.

**Fix:** reuse a spatial index or build a lightweight screen-space pick grid from visible particles. Return a candidate set from the clicked cell and adjacent cells, then compute exact distances only for those candidates. Cache it until particles move enough or rebuild at a modest interval.

### P1-E — Render and diagnostic state are mixed together

`fillRender()` builds all four draw arrays even when some views do not need them. Stats and render state are requested directly from the same sim object in the same frame loop.

**Fix:** separate solver-owned state, immutable/static render attributes, dynamic render snapshot, and diagnostic snapshot. Establish clear update frequencies. Do not let a draw frame trigger a full connected-component analysis.

---

## 5. A practical optimization architecture

Think of “runs on almost anything” as the combination of a **portable baseline plus scalable fidelity**, not one million equally detailed physical elements on every device.

### Layer 1 — Portable baseline

- Keep a single-threaded scalar Rust/WASM build as the baseline engine.
- Keep the JS reference for tests and unsupported environments, but use a modest particle budget by default.
- Run physics in a worker where available; bundle the worker code into the single HTML using an inline/Blob worker strategy and test it on the target browsers. Provide a main-thread fallback for browsers where that strategy is blocked.
- Keep WebGL as the primary renderer because the current renderer already uses one draw call for all particle points. If WebGL is unavailable, offer a low-count Canvas 2D fallback or show a clear support warning.
- Do not make threading or WebGPU mandatory for the offline `file://` build.

### Layer 2 — Fast CPU/WASM loops

- Compile and measure Rust/WASM first; do not predict speedup from language choice alone.
- Keep data-oriented structure-of-arrays, which is already used in the JS engine.
- Use release optimization; the current `Cargo.toml` already specifies `opt-level=3`, LTO and one codegen unit. Further compiler flag changes should only be accepted after benchmark evidence. Rust's Cargo documentation notes that optimisation settings trade runtime, size, and compile time and that higher settings are not universally faster.
- Add precomputed constants and active-bond lists only where profiling shows benefit.
- Replace per-step contact-grid rebuild with a verified neighbor-list/skin approach if benchmarked faster.
- Add WebAssembly SIMD as an optional optimized variant where supported. Keep a scalar fallback; do not require a newer instruction set for all users. SIMD helps vectorizable numerical work but does not fix a poor O(N^1.5) total-work profile.

### Layer 3 — Multi-rate UI/rendering

- Worker owns simulation stepping and its state.
- Main thread handles controls, DOM and display.
- Prefer OffscreenCanvas/WebGL in a worker when it works in the browser; otherwise keep the existing renderer on the main thread and transfer compact snapshots.
- Never copy a million-particle full snapshot with structured cloning every frame. Use transferable buffer pools, lower-rate snapshots, delta/dirty ranges, or worker-owned rendering. Transferable `ArrayBuffer`s can move ownership without copying, but transferred buffers become detached in the sender until returned/recycled.
- Update fast UI labels at 4–10 Hz, not at every rendered frame. Compute the expensive energy ledger and fragment graph separately.

### Layer 4 — Adaptive fidelity (the change that matters most for one million particles)

Keep fixed uniform particle tiers as the near-term solution:

- **Draft / low-end:** approximately 2k–5k physical particles for quick qualitative experiments.
- **Standard:** approximately 10k–20k for current interactive development, depending on device benchmarks.
- **High detail:** tens of thousands to ~100k, with explicit “slow/long-running” labeling.
- **Extreme / research:** 250k–1M only as a deliberate long-running experiment until measured improvements exist.

These are starting targets derived from this project's measurements, not universal compatibility claims. Automatically benchmark a short warm-up on first run and suggest a tier. Do not automatically change resolution halfway through an experiment unless the user explicitly enabled adaptive resolution and the change is physically/visually reported.

The longer-term approach is **local meshless/particle refinement around the impact, deformation, and fracture region**, using coarser representation far from the impact. This concentrates the expensive detail where it changes the answer. It is a researched numerical method, but the interface between coarse and fine particles is hard: it can be unstable and can introduce energy/momentum errors if handled naively. Implement it only after adding transition-zone tests for momentum, energy, wave reflection, fracture propagation, and resolution convergence. Do not just use smaller `h` for some particles without a coupling scheme.

A second future backend may use WebGPU compute to parallelise force and particle updates on compatible devices. MDN currently labels WebGPU as limited availability and secure-context-dependent, so it must be optional with a WASM fallback. It also requires a redesigned data path: pairwise bond forces update both endpoints, which creates write conflicts if many GPU threads write forces directly. Use a tested gather/reduction scheme or staged force accumulation; do not assume GPU compute is a drop-in replacement.

---

## 6. What must not be “optimised” by making the physics wrong

Do not:

- Increase `dt` just because it makes the benchmark faster. The timestep is constrained by the fastest/stiffest interactions; stability and convergence must be measured.
- Lower density, modulus, projectile mass, or impact speed to hit a performance target.
- Skip contact pairs during a broken-bond state or between newly separated particles.
- Skip particles that are outside the camera if they still participate in physics.
- Delete far-field material to save time without changing the documented geometry/support model.
- Render fake particle clouds and label them simulated particles.
- Reduce the solver to a lookup table or hard-coded penetration/ricochet rule.
- Convert all f64 physics arrays to f32 without accuracy, stability, and convergence tests.
- Claim material or historical ballistic validation from code tests alone.

The UI may simplify rendering at a distance, but simulation fidelity must be described separately from visual detail.

---

## 7. Implementation order for Claude

### Phase A — Make the baseline measurable and safe

1. Install/use Rust in the build environment; run `cargo test` and build `wasm32-unknown-unknown`.
2. Add a strict production build which fails if WASM is missing; retain JS fallback only as a deliberate compatibility/testing mode.
3. Rewrite the benchmark harness to use `performance.now()`/`hrtime.bigint()`, warm-up, several samples, medians, and a machine/runtime record. Test a quiet no-impact system and a real impact separately.
4. Add per-phase timers: force-bond loop, contact-grid update, contact pairs, integration, render-buffer extraction, energy stats, connected components, and WebGL upload.
5. Add deterministic JS-vs-WASM comparisons for initial state and short runs.

### Phase B — Remove known avoidable costs

6. Move physics to a worker and prevent multi-step synchronous calls from freezing the UI.
7. Separate quick telemetry from full diagnostics; compute fragment connectivity only on demand/at completion.
8. Stop scanning broken bonds in the active force loop; preserve stable bond records for history/tests.
9. Reduce array-construction peak memory with typed-array preallocation/two-pass bond building.
10. Fix grid boundary handling and benchmark a skin-based contact neighbor list.
11. Rework renderer uploads: static attributes once, only changed streams per frame, speed only in speed mode, reusable GPU storage.
12. Index particle picking instead of scanning all particles on click.

### Phase C — Reach older hardware

13. Add explicit Draft/Standard/High/Extreme tiers and show the expected duration based on a calibrated quick benchmark.
14. Add scalar-WASM and optional SIMD-WASM builds; browser feature detection must fall back cleanly.
15. Test `file://` offline after bundling worker and WASM sources. WebAssembly threading must remain optional because shared-memory threading commonly requires cross-origin isolation headers that a local single HTML file cannot guarantee.
16. Only then prototype adaptive refinement near the impact zone and/or optional WebGPU compute.

---

## 8. Required success criteria

Performance changes count only if the tests still pass.

### Correctness gates

- All current 15 JS tests still pass.
- Rust tests compile and pass.
- Rust/WASM and JS produce matching initial geometry/mass/configuration and numerically comparable results at small N.
- Momentum, energy ledger, contact-after-fracture, irreversible bonds, and reset tests retain explicit tolerances.
- Resolution comparison reports changes in penetration depth, projectile velocity, fracture count, and residual energy; no “speedup” is accepted if results changed without explanation.
- Contact neighbor list never misses a collision in a high-speed fragment test.
- Grid expansion tests verify fragments leaving the initial bounds remain correctly indexed.

### Performance gates

- Benchmarks report median and spread over multiple samples.
- UI has no long tasks caused by physics/stats; target less than 50 ms uninterrupted work on the main thread, preferably much less. The solver worker may run longer chunks while keeping UI controls responsive.
- Record creation time, peak memory where the platform exposes it, ms/step, particles/s, bonds/s, simulated-µs per wall-second, render upload bytes/frame, and diagnostic cost separately.
- At least a low-end mode should finish the current 600 µs case in a few seconds on an entry-level target device, measured rather than assumed.
- Report the actual hardware/browser used and do not call a tier “interactive” unless measured.
- One-million-particle mode stays experimental until a real impact has completed and its memory, wall time, accuracy, and browser responsiveness have been measured.

---

## 9. Platform choices and portability constraints

- **Rust/WASM:** suitable for the numerical engine and should be benchmarked against the current JS implementation; it is not an automatic guarantee of a particular speedup. WebAssembly is designed for efficient low-level execution alongside JavaScript.
- **SIMD:** WebAssembly's 128-bit SIMD adds parallel numeric operations and can help vectorizable kernels. Keep a scalar fallback for older/unsupported runtimes and benchmark the actual bond/contact loops.
- **Workers:** useful immediately because they keep long computation away from the browser's UI thread. Use transferable buffers where state snapshots must cross threads, and avoid copying the full model on every message.
- **OffscreenCanvas:** can move rendering into a worker on supported browsers; feature-detect and keep a fallback.
- **Shared memory / threaded WASM:** optional only; SharedArrayBuffer availability is tied to cross-origin isolation in mainstream browsers. A direct local HTML file cannot assume the required response headers exist.
- **WebGPU:** future optional acceleration; not a baseline requirement because support remains limited and WebGPU requires a secure context in supported browsers.
- **WebGL:** retain as the portable graphics baseline and avoid unnecessary per-frame GPU resource reallocation. The current single draw call is good; the attribute-copy/upload policy is not yet efficient.

---

## 10. Research references

1. MDN, **WebAssembly overview** — https://developer.mozilla.org/en-US/docs/WebAssembly
2. WebAssembly Community Group, **SIMD proposal/explainer** — https://github.com/WebAssembly/simd/blob/main/proposals/simd/W3CTAG-SIMDExplainer.md
3. MDN, **Using Web Workers** — https://developer.mozilla.org/en-US/docs/Web/API/Web_Workers_API/Using_web_workers
4. MDN, **Transferable objects** — https://developer.mozilla.org/en-US/docs/Web/API/Web_Workers_API/Transferable_objects
5. MDN, **OffscreenCanvas** — https://developer.mozilla.org/en-US/docs/Web/API/OffscreenCanvas
6. MDN, **SharedArrayBuffer** — https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/SharedArrayBuffer
7. MDN, **WebGL best practices** — https://developer.mozilla.org/en-US/docs/Web/API/WebGL_API/WebGL_best_practices
8. Emscripten, **Optimizing WebGL** — https://emscripten.org/docs/optimizing/Optimizing-WebGL
9. MDN, **WebGPU API and availability** — https://developer.mozilla.org/en-US/docs/Web/API/WebGPU_API
10. The Cargo Book, **Profiles and optimization settings** — https://doc.rust-lang.org/cargo/reference/profiles.html
11. Chiron et al., *Analysis and improvements of Adaptive Particle Refinement (APR) through CPU time, accuracy and robustness considerations*, Journal of Computational Physics (2018), DOI: https://doi.org/10.1016/j.jcp.2017.10.041
12. *Fast neighbor lists for adaptive-resolution particle simulations*, Computer Physics Communications — https://www.sciencedirect.com/science/article/abs/pii/S0010465512000057
13. MDN, **Long tasks and JavaScript performance** — https://developer.mozilla.org/en-US/docs/Web/API/PerformanceLongTaskTiming and https://developer.mozilla.org/en-US/docs/Learn_web_development/Extensions/Performance/JavaScript

These sources support the platform and algorithmic recommendations. They do not prove a particular percentage speedup for this code; all speedups must be measured after implementation.

## Final recommendation

**Do not start by rewriting the entire solver.** First compile and benchmark the actual Rust/WASM engine, move it off the UI thread, stop doing a full fragment graph and energy scan every 150 ms, remove broken bonds from the hot active list, reduce temporary allocation, and reduce GPU buffer churn. Those are focused changes with measurable benefits and comparatively limited risk to the physics.

Then set honest default particle tiers. Use local particle refinement only as a later numerical project with its own conservation and convergence tests. That combination—portable low-cost mode, fast WASM, responsive worker architecture, efficient rendering, and higher-detail refinement where it matters—is the credible route towards an ArmorLab that works on a broad range of hardware.
