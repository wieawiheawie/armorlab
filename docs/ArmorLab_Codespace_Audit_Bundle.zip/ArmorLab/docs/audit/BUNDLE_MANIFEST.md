# ArmorLab Codespace Audit Bundle

## Source of truth
The editable application is the `ArmorLab/` project at the root of this bundle. It is extracted from the uploaded `ArmorLab_Optimized.zip`. The exact archive supplied for the audit is preserved under `docs/audit/original_upload/`.

## Contents
- `src/`, `web/`, `tests/`, `scripts/`, `presets/`, `dist/`: current app source and artefacts.
- `docs/audit/ArmorLab_Deep_Audit.md`: code audit and issue descriptions.
- `docs/audit/ArmorLab_Audit_Findings.csv`: structured audit items.
- `docs/audit/ArmorLab_Audit_Validation_Log.txt`: checks performed in the audit environment.
- `docs/audit/ArmorLab_Performance_Deep_Dive.md`: performance analysis.
- `docs/audit/ArmorLab_Optimization_Roadmap.csv` and `ArmorLab_Performance_Benchmarks.csv`: optimization priorities and recorded benchmark results.
- `data/research/`: supplementary material, ammunition, armour, and physics references. These are reference data, not a guarantee that each profile is calibrated for simulation.

## Important boundaries
- Treat the source files under `ArmorLab/` as authoritative for current implementation.
- Treat audit findings as a report to verify against current files before changing code.
- Treat benchmark numbers as historical measurements from the included report. Re-run the benchmarks in this Codespace before claiming current performance.
- Do not silently convert a missing-WASM release build into a JavaScript-only output.
- The current physics model is exploratory and not experimentally validated as a 1:1 reconstruction.

## Suggested commands in GitHub Codespaces

```bash
bash scripts/codespace_setup.sh
npm test
cargo test --release
npm run build:release
npm run smoke
npm run bench
```

Run commands from this `ArmorLab/` directory. If the browser smoke test reports a missing browser dependency, install/configure it through the project's supported setup rather than assuming the browser test passed.
