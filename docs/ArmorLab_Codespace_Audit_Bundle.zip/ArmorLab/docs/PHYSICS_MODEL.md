# ArmorLab physics model (v0.1, PROVISIONAL)

Not a claim of Armor Sandbox's internals (unpublished) and not a 1:1 ballistic reproduction.

## Representation
2D cross-section. Each particle = one numerical element (persistent index, material ID, mass, x, v, bond list, bond damage). Spacing h; mass m = rho*h^2*dz.
Out-of-plane depth dz (plane-strip convention): chosen at build so the projectile's particle mass equals the preset projectile mass exactly (dz≈64 mm); the plate strip uses the same dz. Plate = rotated lattice (spacing h, `layers = t/h` exact), so slope is real geometry. Projectile lattice is axis-aligned.

## Internal forces (bond-based spring lattice)
Bonds to neighbours within 1.5h (axial k, diagonal k/2). Isotropic 2D plane-stress lattice with nu=1/3 when k = 3·E·dz/4 [N/m]. Force on pair: F = k(r − L)·r̂, equal and opposite (pairwise balanced).
Plasticity: elastic stretch limit (σy/E + (H/E)·εp)·L0; excess moves rest length L (permanent set, irreversible), εp accumulates. Plastic work booked = |F|·|ΔL|.
Fracture: bond removed irreversibly when tensile strain (r−L0)/L0 > ε_crit, or crush strain < −0.5. Stored elastic energy ½k(r−L)² moves to the fracture term at that instant.
Contact: penalty repulsion between ALL particle pairs closer than h, independent of bonds (kc = k_axial). Spatial grid (cell 1.5h), O(N).
Integration: velocity Verlet, dt = 0.25·sqrt(m/k). No damping, no friction, no thermal model, no detonation/filler.

## Energy ledger (J)
kinetic, elastic bond, plastic work, fracture, contact potential, external constraints (0: clamped particles never move). Residual = total − initial KE; diagnostic only, never tuned.
Finding: the residual is O(dt) (0.56 % / 0.23 % / 0.10 % at dt factor 0.25/0.125/0.06; test NUM-03/04). An earlier formulation booking plastic work as the elastic-energy drop created ~9 % spurious energy (trial overshoot); replaced by work-conjugate |F|·|ΔL|.

## Outcome classification (from state only)
Projectile mass fraction past rear face plane, mass-weighted centroid velocity vs impact speed: >50 % behind → perforation; >0 → partial; centroid vx < −5 % v → rebound; |v| < 5 % v → stopped; else in progress. Thresholds are arbitrary documentation choices.

## Calibration status
| item | status |
|---|---|
| plate/projectile geometry thickness & slope | sourced (secondary refs), coupon length is ArmorLab choice |
| projectile mass, muzzle speed | sourced (secondary refs); muzzle speed is used as an IDEALISED impact speed |
| projectile length/nose shape, solid body | placeholder, not sourced |
| density, E | generic steel |
| yield stress, hardening, critical strains | TUNING GUESSES, provisional, uncalibrated, unvalidated |
| plate chemistry/heat treatment | unknown, not modelled |
Results therefore must not be read as historical penetration predictions.
